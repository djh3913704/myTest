package com.ldap;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import foundation.util.Util;

public class LDAPAuthentication {
	private final String URL = "ldap://10.11.1.33:389/";
    private final String BASEDN = "OU=SHGVP,DC=shgvp,DC=gv,DC=com";
    private final String FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
    private LdapContext ctx = null;
    private final Control[] connCtls = null;
    
    /**
     * 测试方法
     * @param args
     */
   /* public static void main(String[] args) {
    	LDAPAuthentication LdapAuthentication = new LDAPAuthentication();
    	LdapAuthentication.authenricate("zy1359", "a!@#123");
	}
    */
    /**
     * 创建ldap连接
     */
    private void LDAP_connect() {
        Hashtable<String, String> env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, FACTORY);
        env.put(Context.PROVIDER_URL, URL + BASEDN);
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        // LDAP用户名
        String root = "shgvp\\CssAdmin";// root
        env.put(Context.SECURITY_PRINCIPAL, root);
        // LDAP密码
        env.put(Context.SECURITY_CREDENTIALS, "#HKC1CCF_yj9d9bt!");
        
        // 此处若不指定用户名和密码,则自动转换为匿名登录
        try {
            ctx = new InitialLdapContext(env, connCtls);
            System.out.println("连接成功");
        } catch (javax.naming.AuthenticationException e) {
            System.out.println("连接失败：" + e.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
 
    /**
     * 查找用户
     * @param uid 用户账号
     * @return
     */
    private String getUserDN(String uid) {
        String userDN = "";
        LDAP_connect();
        try {
            SearchControls constraints = new SearchControls();
            constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
            // 查找条件sAMAccountName
            NamingEnumeration<SearchResult> en = ctx.search("", "sAMAccountName=" + uid, constraints);
            if (en == null || !en.hasMoreElements()) {
                System.out.println("未找到该用户");
                return null;
            }
            // maybe more than one element
            while (en != null && en.hasMoreElements()) {
                Object obj = en.nextElement();
                if (obj instanceof SearchResult) {
                    SearchResult si = (SearchResult) obj;
                    userDN += si.getName();
                    userDN += "," + BASEDN;
                } else {
                    System.out.println(obj);
                }
            }
        } catch (Exception e) {
            System.out.println("查找用户时产生异常。");
            e.printStackTrace();
        }
 
        return userDN;
    }
 
    /**
     * 用户验证
     * @param UID 用户名
     * @param password 密码
     * @return
     */
    public boolean authenricate(String UID, String password) {
        boolean valide = false;
        String userDN = getUserDN(UID);
        if (Util.isEmptyStr(userDN)){
        	System.out.println("该用户不存在");
        	return false;
        }
        
        if (Util.isEmptyStr(password)){
        	System.out.println("请填写密码");
        	return false;
        }
 
        try {
            ctx.addToEnvironment(Context.SECURITY_PRINCIPAL, userDN);
            ctx.addToEnvironment(Context.SECURITY_CREDENTIALS, password);
            ctx.reconnect(connCtls);
            System.out.println(userDN + " 验证通过");
            valide = true;
        } catch (AuthenticationException e) {
            System.out.println(userDN + " 验证失败");
            System.out.println(e.toString());
            valide = false;
        } catch (NamingException e) {
            System.out.println(userDN + " 验证失败");
            valide = false;
        }
 
        return valide;
    }

}
