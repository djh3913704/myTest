package foundation.encrypt;

import java.math.BigDecimal;


public class Encryptor {
	
	private static boolean test = false;

	public static void main(String[] args) {
		System.out.println(numEncrypt(2.345));
		System.out.println(numDecyrpt(numEncrypt(2.345)));
	}
	
	public static Object numEncrypt(Object num) {
		if (num == null) {
			return num;
		}
		
		Class<?> type = num.getClass();
		
		if (Double.class.equals(type)) {
			Double value = (Double)num;
			return numEncrypt(value.doubleValue());
		}
		else if (Integer.class.equals(type)) {
			Integer value = (Integer)num;
			return numEncrypt(value.intValue());
		}
		else if (BigDecimal.class.equals(type)) {
			BigDecimal value = (BigDecimal)num;
			return numEncrypt(value);
		}
		
		return num;
	}
	
	public static Object numDecyrpt(Object num) {
		if (num == null) {
			return num;
		}
		
		Class<?> type = num.getClass();
		
		if (Double.class.equals(type)) {
			Double value = (Double)num;
			return numDecyrpt(value.doubleValue());
		}
		else if (Integer.class.equals(type)) {
			Integer value = (Integer)num;
			return numDecyrpt(value.intValue());
		}
		else if (BigDecimal.class.equals(type)) {
			BigDecimal value = (BigDecimal)num;
			return numDecyrpt(value);
		}
		
		return num;
	}
	
	public static BigDecimal numEncrypt(BigDecimal num) {
		if (num == null) {
			return BigDecimal.ZERO;
		}
		
		double value = num.doubleValue();
		double result = numEncrypt(value);
		return BigDecimal.valueOf(result);
	}
	
	public static BigDecimal numDecyrpt(BigDecimal num) {
		if (num == null) {
			return BigDecimal.ZERO;
		}
		
		double value = num.doubleValue();
		double result = numDecyrpt(value);
		return BigDecimal.valueOf(result);
	}	
	
	public static int numEncrypt(int num) {
		double value = Double.valueOf(num);
		double result = numEncrypt(value);
		return (int)result;
	}
	
	public static int numDecyrpt(int num) {
		double value = Double.valueOf(num);
		double result = numDecyrpt(value);
		return (int)result;
	}
	
	public static double numEncrypt(double num) {
		if (num == 0) {
			return 0;
		}
		
		//1.
		double value = 0; String data;
		
		boolean working = false;
		StringBuilder result = new StringBuilder();
		char current, begin, end;
		int code, move, pos = 0, bit = -1, flag_begin, flag_end;
		
		data = String.valueOf(num);
				
		//2.生成收尾标识
		flag_begin = (int)(Math.random() * 10) + 48;
		flag_end = (int)(Math.random() * 10) + 48;
		
		flag_begin = flag_begin == 48 ? flag_begin = flag_begin + 3 : flag_begin;
		flag_end = flag_end == 48 ? flag_end = flag_end + 3 : flag_end;
		
		begin = (char)flag_begin;
		end = (char)flag_end;
		
		//3.加密
		for (int i = data.length() - 1; i >= 0; i--) {
			current = data.charAt(i);
		
			if (!working) {
				if ('.' == current || '0' == current) {
					continue;
				}
				
				working = true;
			}
		
			if (working) {
				if ('.' == current) {
					bit = pos;
					continue;
				}
				
				pos = pos + 1;
				
				if (test) {
					move = 1;
				}
				else {
					move = (pos + 1) * (pos + 3) + (pos + 5);
					move = move % 10;					
				}
				
				code = (int)current;
				code = code - move;
				
				if (code < 48) {
					code = code + 10;
				}
				 
				result.append((char)code);				
			}
		}
		
		result.append(end);
		result.insert(0, begin);
		
		if (bit > 0) {
			result.insert(result.length() - bit, '.');
		}
		
		value = Double.valueOf(result.toString());
		
		return value;
	}
	
	public static double numDecyrpt(double num) {
		if (num == 0) {
			return 0;
		}
		
		double value = 0; String data;
		
		StringBuilder result = new StringBuilder();
		char current;
		int code, move, min, bit = -1, pos = 0;
		
		data = String.valueOf(num);
		if (data.endsWith(".0")) {
			data = data.substring(0, data.length() - 2);
		}
		
		min = data.length() - 1;
	       
		for (int i = 1; i < min ; i++) {
			current = data.charAt(i);
			if ('.' == current) {
				bit = i;
				continue;
			}
		
			pos = pos + 1;
			
			if (test) {
				move = 1;
			}
			else {
				move = (pos + 1) * (pos + 3) + (pos + 5);
				move = move % 10;					
			}
			
			code = (int)current;
			code = code + move;
			
			if (code > 57) {
				code = code - 10;
			}
			 
			result.insert(0, (char)code);	
		}
		
		if (bit > 0) {
			result.insert(bit - 2, '.');
		}
		
		value = Double.valueOf(result.toString());
		
		return value;
	}

}
