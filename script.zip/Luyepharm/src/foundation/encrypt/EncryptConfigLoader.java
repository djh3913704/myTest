package foundation.encrypt;

import foundation.config.Preloader;
import foundation.data.Entity;
import foundation.data.EntitySet;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;

public class EncryptConfigLoader extends Preloader {

	private static EncryptConfigContainer encryptConfigContainer;
	
	static {
		encryptConfigContainer = EncryptConfigContainer.getInstance();
	}
	
	@Override
	public void load() throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance("getEncryptionList");
		EntitySet entitySet = SQLRunner.getEntitySet(namedSQL);
		
		String priorName = "", name, field; 
		EncryptConfig confg = null;
		
		for (Entity entity: entitySet) {
			name = entity.getString("tablename");
					
			if (!priorName.equals(name)) {
				confg = new EncryptConfig(name);
				encryptConfigContainer.add(name, confg);
			}
			
			field = entity.getString("fieldname");
			confg.addField(field);
		}
	}
	
}
