package foundation.encrypt;

import foundation.server.Container;

public class EncryptConfigContainer extends Container<EncryptConfig> {

	private static EncryptConfigContainer instance;
	
	public static synchronized EncryptConfigContainer getInstance() {
		if (instance == null) {
			instance = new EncryptConfigContainer();
		}
		
		return instance;
	}
}
