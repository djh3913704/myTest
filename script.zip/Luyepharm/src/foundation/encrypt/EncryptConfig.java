package foundation.encrypt;

import java.util.HashSet;
import java.util.Set;

public class EncryptConfig {

	private String name;
	private Set<String> fieldNameSet;
	
	public EncryptConfig(String name) {
		this.name = name;
		this.fieldNameSet = new HashSet<String>();
	}
	
	public void addField(String field) {
		if (field == null) {
			return;
		}
		
		field = field.toLowerCase();
		fieldNameSet.add(field);
	}
	
	public boolean contains(String field) {
		if (field == null) {
			return false;
		}
		
		field = field.toLowerCase();
		return fieldNameSet.contains(field);
	}

	public String getName() {
		return name;
	}

	public Set<String> getFieldNameSet() {
		return fieldNameSet;
	}
	
}
