package foundation.encrypt;


public class Encryption {

	/*public static void main(String[] args) {
		System.out.println(retNumber(2, "YR"));
		System.out.println(retNumber(91395.91, "YW"));
	}*/
	
	public static double retNumber(double chk_data, String chk_type) {
		double ret_var;
		String str_data, str_ret, str_temp, str_abs;
		int ln_len, ln_asc, ln_move;
		
		str_abs="N";
		
		//如果小于0，取ABS
		if (chk_data < 0) {
			str_abs = "Y";
			chk_data = Math.abs(chk_data);
		}
		
		str_data = formatString(chk_data);
		str_data = replicate("0", 9 - str_data.length()) + str_data;
		
		str_temp = str_data.substring(0, 1);
		
		if (str_temp.equals("0")) {
			str_temp = "";
		}
		
		str_data = str_data.replace(".", "");  
		str_data = str_data.substring(1, str_data.length());
		
		str_ret = "";
		
	   if (!"Y".equals(chk_type.substring(0, 1))) {
		   return chk_data;
	   }
	       
	   if ("W".equals(chk_type.substring(1, 2))) {
	       ln_len = 0;
	       
	       while (ln_len < 7) {
	           ln_move = (ln_len + 1 + 1) * (ln_len + 3 + 1) + (ln_len + 2 + 1); 
	           
	           char segment1 = str_data.charAt(ln_len);
	           int segment2 = (int)(segment1);
	           
	           ln_asc = segment2 + ln_move % 10;  
	           
	           if (ln_asc > 57) {
	        	   ln_asc = ln_asc - 10;
	           }
	           
	           char segment3 = (char)ln_asc;
	           
	           str_ret = segment3 + str_ret; 
	           ln_len = ln_len + 1;   
	       }
	       
	       str_ret = str_ret.substring(0, 5) + '.' + str_ret.substring(5, 5 + 2); 		   
	   }
	   else {
	        ln_len = 0;
	        
	        while (ln_len < 7) {
	        	ln_move = 8 - (ln_len + 1);
		    	ln_move = (ln_move + 1) * (ln_move + 3) + (ln_move + 2); 
		    	
		    	char segment1 = str_data.charAt(ln_len);
		    	int segment2 = (int)(segment1);
		    	
		    	ln_asc = segment2 - ln_move % 10; 
		    	
		    	if (ln_asc < 48) {
		    		ln_asc = ln_asc + 10;
		    	}
		    	 
		    	char segment3 = (char)ln_asc;
		    	
		    	str_ret = segment3 + str_ret;  
		    	ln_len = ln_len + 1;	        	
	        }
	       
	       str_ret = str_ret.substring(0, 5) + "." + str_ret.substring(5, 5 + 2);		   
	   }
	   
	   if ("Y".equals(str_abs)) {
		   ret_var = -1 * Double.valueOf(str_temp + str_ret);
	   }
	   else {
		   ret_var = Double.valueOf(str_temp + str_ret);
	   }
		  
	   return ret_var;
	}
	
	private static String formatString(double data) {
		long data1 = Math.round(data * 100);
		long data2 = Math.round(data) * 100;
		
		return data1 == data2 ? String.valueOf(data) + "0" : String.valueOf(data);
	}

	private static String replicate(String segment, int times) {
		String result = "";
		
		for (int i = 0; i < times; i++) {
			result = result + segment;
		}
		
		return result;
	}
}
