package foundation.variant;


public class VariantSegment extends Segment {

	protected String name;
	protected String value;
	
	
	public VariantSegment(String name) {
		this.name = name;
	}
	
	@Override
	public Segment newInstance() {
		VariantSegment result = new VariantSegment(name);
		result.value = value;
		
		return result;
	}
	
	@Override
	public String getValueString() {
		if (value == null) {
			return VariantParser.toSegmentString(name);
		}
		
		return value;
	}

	public String getName() {
		return name;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "@{" + name + "}=" + value;
	}

	public void clearValue() {
		value = null;
	}
	
	public boolean isEmpty() {
		return value == null;
	}
	
}
