package foundation.variant;

import java.util.ArrayList;
import java.util.List;


public class VariantContext implements IVariantRequestListener {

	private List<VariantContext> linkedContextList;
	
	public VariantContext() {
		linkedContextList = new ArrayList<VariantContext>();
	}
	
	public void setParametersTo(IExpression expression) throws Exception {
		doSetParametersTo(expression, null, true);
	}
	
	public void setParametersTo(IExpression expression, VariantRequestParams params) throws Exception {
		doSetParametersTo(expression, params, true);
	}
	
	protected void doSetParametersTo(IExpression expression, VariantRequestParams params, boolean queryGlabal) throws Exception {
		VariantList paramList = expression.getVariantList();
		
		//1. on local
		for (VariantSegment variant: paramList) {
			if (!variant.isEmpty()) {
				continue;
			}
			
			String name = variant.getName();
			String value = getStringValue(name, null);
			
			if (value != null) {
				if (value.startsWith("@")) {
					String upname = value.substring(1);
					variant.setName(upname);
				}
				else {
					variant.setValue(value);
				}
			}
		}
		
		//2. on linked
		for (VariantContext linked: linkedContextList) {
			linked.doSetParametersTo(expression, params, false);
		}
		
		//3.
		if (queryGlabal) {
			for (VariantSegment variant: paramList) {
				if (!variant.isEmpty()) {
					continue;
				}
				
				String name = variant.getName();
				String value = GlobalVariant.getStringValue(name, params);

				if (value != null) {
					variant.setValue(value);
				}
			}			
		}
	}

	@Override
	public List<String> getVariantNames() {
		return null;
	}

	@Override
	public String getStringValue(String name, VariantRequestParams params) throws Exception {
		return null;
	}
	
	public void linkContext(VariantContext context) {
		linkedContextList.add(context);
	}
	
}
