package foundation.variant;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

public class VariantRequestParams {
	
	private HttpServletRequest request;
	private Map<String, String> paramMap;
	
	public VariantRequestParams() {
		paramMap = new HashMap<String, String>();
	}
	
	public VariantRequestParams(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletRequest getRequest() {
		return request;
	}
	
	public void addParam(String name, String value) {
		if (name == null) {
			return;
		}
		
		name = name.toLowerCase();
		paramMap.put(name, value);
	}
	
	public String getParam(String name) {
		if (name == null) {
			return null;
		}
		
		name = name.toLowerCase();
		return paramMap.get(name);
	}
}
