package foundation.variant;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import foundation.util.Util;

public class GlobalVariant {

	protected static Logger logger;
	private static Object lock = new Object();
	private static GlobalVariant instance;
	private Map<String, IVariantRequestListener> listenerMap;
	
	static {
		logger = Logger.getLogger(GlobalVariant.class);
	}
	
	private GlobalVariant() throws VariantExistsException {
		listenerMap = new HashMap<String, IVariantRequestListener>();
	}
	
	public static GlobalVariant getInstance() {
		if (instance == null) {
			synchronized(lock) {
				try {
					if (instance == null) {
						instance = new GlobalVariant();
						GlobalVariantProvider provider = new GlobalVariantProvider();
						GlobalVariant.regist(provider);
					}
				}
				catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		return instance;
	}
	
	public static void regist(IVariantRequestListener listener) throws VariantExistsException {
		GlobalVariant service = getInstance();
		
		List<String> variantNames = listener.getVariantNames();
		
		if (variantNames == null) {
			return;
		}
		
		for (String name: variantNames) {
			if (name == null) {
				continue;
			}
			
			String lower = name.toLowerCase();
			
			if (service.listenerMap.containsKey(lower)) {
				throw new VariantExistsException(name);
			}
			
			service.listenerMap.put(lower, listener);
		}
	}
	
	public static String getStringValue(String name, VariantRequestParams params) throws Exception {
		GlobalVariant service = getInstance();
		
		if (name == null) {
			return null;
		}
		
		String lower = name.toLowerCase();
		
		IVariantRequestListener listener = service.listenerMap.get(lower);
		
		if (listener == null) {
			return null;
		}
		
		return listener.getStringValue(lower, params);
	}
	
	public static class GlobalVariantProvider implements IVariantRequestListener {
		
		private List<String> variantNames;
		
		public GlobalVariantProvider() {
			variantNames = new ArrayList<String>();
			initVariantNames();
		}
		
		@Override
		public String getStringValue(String name, VariantRequestParams params) {
			if ("guid".equals(name)) {
				return Util.newShortGUID();
			}
			else if ("newDate".equals(name)) {
				return Util.newDateStr();
			}
			else if ("newDateTime".equals(name)) {
				return Util.newDateTimeStr();
			}
			else if ("current.year".equals(name)) {
				Calendar calendar = Calendar.getInstance();
				return String.valueOf(calendar.get(Calendar.YEAR));
			}
			else if ("current.month".equals(name)) {
				Calendar calendar = Calendar.getInstance();
				return String.valueOf(calendar.get(Calendar.MONTH) + 1);
			}
			else if ("now".equals(name)) {
				String fromat = params.getParam("format");
				SimpleDateFormat format = new SimpleDateFormat(fromat);
				return format.format(new Date());
			}
			else if ("now_dd_hh_mm_ss".equals(name)) {
				SimpleDateFormat format = new SimpleDateFormat("dd_HH_mm_ss");
				return format.format(new Date());
			}
			
			return null;			
		}

		@Override
		public List<String> getVariantNames() {
			return variantNames;
		}
		
		public void initVariantNames() {
			variantNames.add("guid");
			variantNames.add("newDate");
			variantNames.add("newDateTime");
			variantNames.add("current.year");
			variantNames.add("current.month");
			variantNames.add("now_dd_HH_mm_ss");
		}
	}
}
