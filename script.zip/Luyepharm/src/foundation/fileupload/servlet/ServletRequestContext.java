package foundation.fileupload.servlet;

import java.io.InputStream;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;

import foundation.fileupload.RequestContext;

public class ServletRequestContext implements RequestContext { 

    private HttpServletRequest request;

    public ServletRequestContext(HttpServletRequest request) {
        this.request = request;
    }

    public String getCharacterEncoding() {
        return request.getCharacterEncoding();
    }

    public String getContentType() {
        return request.getContentType();
    }

    public int getContentLength() {
        return request.getContentLength();
    }

    public InputStream getInputStream() throws IOException {
        return request.getInputStream();
    }

	public String toString() {
		return "ContentLength=" + this.getContentLength() + ", ContentType=" + this.getContentType();
	}
}
