package foundation.fileupload.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import foundation.fileupload.servlet.ServletRequestContext;

import foundation.fileupload.FileItemFactory;
import foundation.fileupload.FileItemIterator;
import foundation.fileupload.FileUpload;
import foundation.fileupload.FileUploadException;


public class ServletFileUpload extends FileUpload { 

    public static final boolean isMultipartContent(HttpServletRequest request) {
        String contentType = request.getContentType();
        
        if (contentType == null) {
            return false;
        }
        else if (contentType.toLowerCase().startsWith("multipart/")) {
            return true;
        }
        
        return false;
    }

    public ServletFileUpload() {
        super();
    }

    public ServletFileUpload(FileItemFactory fileItemFactory) {
        super(fileItemFactory);
    }

    public List parseRequest(HttpServletRequest request) throws FileUploadException {
        return parseRequest(new ServletRequestContext(request));
    }

    public FileItemIterator getItemIterator(HttpServletRequest request) throws FileUploadException, IOException {
        return super.getItemIterator(new ServletRequestContext(request));
    }
}
