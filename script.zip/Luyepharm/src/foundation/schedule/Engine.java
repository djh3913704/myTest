package foundation.schedule;

import java.nio.charset.Charset;
import java.util.List;


import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import foundation.config.Configer;
import foundation.data.Entity;
import foundation.data.EntitySet;
import foundation.data.JsonBuilder;
import foundation.persist.DataHandler;
import foundation.persist.Field;
import foundation.persist.TableMeta;
import foundation.persist.TableMetaCenter;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.server.InternalServer;
import foundation.server.Progressor;
import foundation.util.Util;

public class Engine implements Runnable {

	enum State {Idle, working};
	
	private static Logger logger;
	private static Engine instance;
	private State state;
	private Object lock;
	private Progressor progressor;
	private String command;
	
	private static String URL_WebMan="";
	private static String toServerPath="";
	private static String toServerErrorPath="";

	static {
		logger = Logger.getLogger(Engine.class);
		URL_WebMan = Configer.getParam("URL_WebMan");
		toServerPath = Configer.getParam("toServerPath");
		toServerErrorPath = Configer.getParam("toServerErrorPath");
	}
	
	private Engine() throws Exception {
		lock = new Object();
		progressor = new Progressor();
		state = State.Idle;
	}
	
	public static synchronized Engine getInstance() throws Exception {
		if (instance == null) {
			instance = new Engine();
		}
		
		return instance;
	}
	
	public void exec(String command) {
		if (State.Idle == state) {
			synchronized (lock) {
				if (InternalServer.Terminate) {
					return;
				}
				
				if (State.Idle == state) {
					this.command = command;
					Thread thread = new Thread(this);
					thread.start();
				}
			}
		}
	}
	
	@Override
	public void run() {
		try {
			if ("DBToServer".equalsIgnoreCase(command)) {
				DBToServer();
			}
			else if ("serverToDB".equalsIgnoreCase(command)) {
				serverToDB();
			}
			
		}
		catch(Exception e) {
			logger.error(e);
			progressor.appendMesage("系统出错：" + e.getMessage());
		}
		finally {
			command = null;
			state = State.Idle;
		}
	}

	public Progressor getProgressor() {
		return progressor;
	}
	
	public void DBToServer() throws Exception{
		NamedSQL namedSQL = NamedSQL.getInstance("getDataSet");
		namedSQL.setParam("tablename", "table_handler");
		namedSQL.setParam("filter", "1=1");
		
		logger.debug(namedSQL.getSQL());
		EntitySet entitySet = SQLRunner.getEntitySet(namedSQL);
		
		for (Entity table_entity : entitySet) {
			String tableId = table_entity.getString("id");
			
			//1、搬运前事件
			EntitySet beginEventSet = getTableEvent(tableId, "begintocsv");
			if (!Util.isEmptyStr(beginEventSet) && beginEventSet.size() > 0) {
				for (Entity entity : beginEventSet) {
					String namedsql = entity.getString("namedsql");
					DataHandler.execSQL(namedsql);
				}
			}
			
			//2、搬运事件
			EntitySet carryEventSet = getTableEvent(tableId, "carrytocsv");
			if (!Util.isEmptyStr(carryEventSet) && carryEventSet.size() > 0) {
				for (Entity entity : carryEventSet) {
					String namedsql = entity.getString("namedsql");
					NamedSQL thisNamedSQL = NamedSQL.getInstance(namedsql);
					EntitySet thisEntitySet = SQLRunner.getEntitySet(thisNamedSQL);
					String sql = thisNamedSQL.getSQL();
					
					if (!Util.isEmptyStr(thisEntitySet) && thisEntitySet.size() > 0) {
						carryEvent(tableId, sql, "filename");
					}
				}
			}
			
			//3、搬运后事件
			EntitySet endEventSet = getTableEvent(tableId, "endtocsv");
			if (!Util.isEmptyStr(endEventSet) && endEventSet.size() > 0) {
				for (Entity entity : endEventSet) {
					String namedsql = entity.getString("namedsql");
					DataHandler.execSQL(namedsql);
				}
			}
			
		}
	}
	
	//同步服务器数据到DB
	protected void serverToDB() throws Exception{
		HttpClient httpclient = HttpClients.createDefault();
		
		String getServerPath  = toServerPath.substring(0, toServerPath.length()-2);
		HttpGet httpget = new HttpGet("http://localhost:3456/api/FileCenter/RemoteUpload?path=" + getServerPath);
		
		HttpResponse httpResponse = httpclient.execute(httpget);
		StatusLine statusLine = httpResponse.getStatusLine();
		
 		if (statusLine.getStatusCode() == HttpStatus.OK.value()) {
 			String strResult = EntityUtils.toString(httpResponse.getEntity());  
			JsonObject returnData = new JsonParser().parse(strResult).getAsJsonObject();
			JsonElement jsonElement = returnData.get("FilePath");
			String path = jsonElement.getAsString();
			String filename  = path.substring(0, path.length()-5);
			
			Entity table_detail = getTable("filename='" + filename + "'");
			String tableId = table_detail.getString("id");
			String tablename = table_detail.getString("tablename");
			String csvtempname = table_detail.getString("filename");
			String errortablename = table_detail.getString("errorfilename");
			
			//1、搬运到正式表前事件
			//添加冲突数据到csverror_表中
			EntitySet beginEventSet = getTableEvent(tableId, "begintodb");
			if (!Util.isEmptyStr(beginEventSet) && beginEventSet.size() > 0) {
				for (Entity entity : beginEventSet) {
					String namedsql = entity.getString("namedsql");
					String sqlmode = entity.getString("sqlmode");
					
					if (sqlmode.equalsIgnoreCase("sqlinsert")) {
						NamedSQL namedSQL = NamedSQL.getInstance(namedsql);
						String sql = namedSQL.getSQL();
						insertBySQL(errortablename, sql);
					}
					else if (sqlmode.equalsIgnoreCase("deleteother")) {
						toDBByDelete(tablename, csvtempname, errortablename);
					}
					else {
						DataHandler.execSQL(namedsql);
					}
				}
			}
			
			//2、搬运事件
			//a、更新不在冲突表中的原数据； b、增加新增数据
			EntitySet carryEventSet = getTableEvent(tableId, "carrytodb");
			if (!Util.isEmptyStr(carryEventSet) && carryEventSet.size() > 0) {
				for (Entity entity : carryEventSet) {
					String namedsql = entity.getString("namedsql");
					String sqlmode = entity.getString("sqlmode");
					
					if (sqlmode.equalsIgnoreCase("add")) {
						toDBByAdd(tablename, csvtempname, errortablename);
					}
					else if (sqlmode.equalsIgnoreCase("up")){
						toDBByUp(tablename, csvtempname, errortablename);
					}
					else {
						DataHandler.execSQL(namedsql);
					}
				}
			}
			
			//3、搬运后事件
			//将冲突表数据上传到服务器
			EntitySet endEventSet = getTableEvent(tableId, "endtodb");
			if (!Util.isEmptyStr(endEventSet) && endEventSet.size() > 0) {
				for (Entity entity : endEventSet) {
					String namedsql = entity.getString("namedsql");
					String sqlmode = entity.getString("sqlmode");
					String sql = null;
					EntitySet entitySet = null;
					
					if (sqlmode.equalsIgnoreCase("alltocsv")) {
						NamedSQL namedSQL = NamedSQL.getInstance("getDataSet");
						namedSQL.setParam("tablename", filename);
						namedSQL.setParam("filter", "1=1");
						entitySet = SQLRunner.getEntitySet(namedSQL);
						
						sql = namedSQL.getSQL();
					}
					else if (!Util.isEmptyStr(namedsql)) {
						NamedSQL namedSQL = NamedSQL.getInstance(namedsql);
						entitySet = SQLRunner.getEntitySet(namedSQL);
						sql = namedSQL.getSQL();
					}
					
					if (!Util.isEmptyStr(entitySet) && entitySet.size() > 0) {
						carryEvent(tableId, sql, "errorfilename");
					}
				}
			}
			
		}
	}
	
	private EntitySet getTableEvent(String tableid, String eventcode) throws Exception {
		String filter = "active='T' and eventcode='" + eventcode + "' and tableid='" + tableid + "' order by no";
		
		NamedSQL namedSQL = NamedSQL.getInstance("getDataSet");
		namedSQL.setParam("tablename", "table_handler");
		namedSQL.setParam("filter", filter);
		
		logger.debug(namedSQL.getSQL());
		return SQLRunner.getEntitySet(namedSQL);
	}
	
	private void carryEvent(String tableId, String sql, String fileName) throws Exception {
		Entity table_detail = getTable("id='" + tableId + "'");
		String tablename = table_detail.getString("tablename");
		String filename = table_detail.getString(fileName);
		boolean isparent = Util.stringToBoolean(table_detail.getString("isparent"));
		
		if (isparent && fileName.equalsIgnoreCase("filename")) {
			String tocsv_tablename = "tocsv_" + tablename;
			
			insertBySQL(tocsv_tablename, sql);
		}
		
		String file= toServerPath + filename + ".csv";
		if (fileName.equalsIgnoreCase("errorfilename")) {
			file= toServerErrorPath + filename + ".csv";
		}
		
		JsonBuilder jsonbuilder = new JsonBuilder();
		jsonbuilder.beginObject();
		jsonbuilder.addValue("file", file);
		jsonbuilder.addValue("sql", sql);
		
		jsonbuilder.endObject();
		String jsonString = jsonbuilder.ToString();
		
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httppost = new HttpPost(URL_WebMan + "RemoteDownload");
		httppost.addHeader(HTTP.CONTENT_TYPE, "application/json");
		
		JsonObject jsobj = new JsonParser().parse(jsonString).getAsJsonObject();
		StringEntity paramsEntity = new StringEntity(jsobj.toString(), Charset.forName("UTF-8"));
		paramsEntity.setContentType("text/json");
		paramsEntity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE,"application/json"));
		httppost.setEntity(paramsEntity);
		
		CloseableHttpResponse webmanResponse = httpclient.execute(httppost);
		if (webmanResponse != null && webmanResponse.getStatusLine().getStatusCode() == 200) {
 			String strResult = EntityUtils.toString(webmanResponse.getEntity());  
			JsonObject returnData = new JsonParser().parse(strResult).getAsJsonObject();
			JsonElement jsonElement = returnData.get("Success");
			boolean Success = jsonElement.getAsBoolean();
			
			if (!Success) {
				jsonElement = returnData.get("ErrorMessage");
				String ErrorMessage = jsonElement.getAsString();
				
				NamedSQL namedSQL = NamedSQL.getInstance("addErrorlog");
				
				namedSQL.setParam("tablename", tablename);
				namedSQL.setParam("errormessage", ErrorMessage);
				namedSQL.setParam("typecode", "DBToServer");
				
				SQLRunner.execSQL(namedSQL);
			}
		}
	}
	
	protected Entity getTable(String filter) throws Exception{
		NamedSQL namedSQL = NamedSQL.getInstance("getTable_detailByFilter");
		namedSQL.setParam("filter", filter);
		
		Entity entity = SQLRunner.getEntity(namedSQL);
		return entity;
	}
	
	protected void insertBySQL(String tablename, String sql) throws Exception{
		TableMeta tableMeta = TableMetaCenter.getInstance().get(tablename);
		List<Field> Fields = tableMeta.getFields();
		
		String fieldNames = "";
		for (int y = 0; y < Fields.size(); y++) {
			Field field = Fields.get(y);
			String fieldName = field.getName();
				fieldNames += fieldName + ",";
		}
		fieldNames = fieldNames.substring(0, fieldNames.length()-1);
		
		NamedSQL insertSQL = NamedSQL.getInstance("insertSQL");
		
		insertSQL.setParam("tablename", tablename);
		insertSQL.setParam("fieldNames", fieldNames);
		insertSQL.setParam("selectsql", sql);
		
		logger.debug(insertSQL.getSQL());
		SQLRunner.execSQL(insertSQL);
	}
	
	private void toDBByAdd(String tablename, String csvtempname, String errortablename) throws Exception {
		TableMeta tableMeta = TableMetaCenter.getInstance().get(tablename);
		List<Field> Fields = tableMeta.getFields();
		
		String fieldNames = "";
		for (int y = 0; y < Fields.size(); y++) {
			Field field = Fields.get(y);
			String fieldName = field.getName();
				fieldNames += fieldName + ",";
		}
		fieldNames = fieldNames.substring(0, fieldNames.length()-1);
		
		NamedSQL namedSQL = NamedSQL.getInstance("todb_table_add");
		namedSQL.setParam("fieldNames", fieldNames);
		namedSQL.setParam("tablename", tablename);
		namedSQL.setParam("csvtemp_tablename", csvtempname);
		namedSQL.setParam("csverror_tablename", errortablename);
		
		logger.debug(namedSQL.getSQL());
		SQLRunner.execSQL(namedSQL);
	}
	
	private void toDBByUp(String tablename, String csvtempname, String errortablename) throws Exception {
		TableMeta tableMeta = TableMetaCenter.getInstance().get(tablename);
		List<Field> Fields = tableMeta.getFields();
		
		String fieldmap = "";
		for (int y = 0; y < Fields.size(); y++) {
			Field field = Fields.get(y);
			String fieldName = field.getName();
			if (!fieldName.equalsIgnoreCase("id")) {
				fieldmap += tablename + "." + fieldName + "=" + csvtempname + "." + fieldName + ",";
			}
		}
		fieldmap = fieldmap.substring(0, fieldmap.length()-1);
		
		NamedSQL namedSQL = NamedSQL.getInstance("todb_table_up");
		namedSQL.setParam("fieldMap", fieldmap);
		namedSQL.setParam("tablename", tablename);
		namedSQL.setParam("csvtemp_tablename", csvtempname);
		
		logger.debug(namedSQL.getSQL());
		SQLRunner.execSQL(namedSQL);
	}
	
	private void toDBByDelete(String tablename, String csvtempname, String errortablename) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance("todb_table_delete");
		namedSQL.setParam("tablename", tablename);
		namedSQL.setParam("csvtemp_tablename", csvtempname);
		
		logger.debug(namedSQL.getSQL());
		SQLRunner.execSQL(namedSQL);
	}
	
}
