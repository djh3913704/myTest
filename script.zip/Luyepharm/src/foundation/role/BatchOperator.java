package foundation.role;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import foundation.data.Entity;
import foundation.persist.Field;
import foundation.persist.SqlSession;
import foundation.persist.TableMeta;
import foundation.persist.TableMetaCenter;
import foundation.persist.sql.IStepSavable;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.util.Util;

public class BatchOperator implements IStepSavable {
	
	private static Logger logger;
	private Connection conn;
	private String tableName;
	private HashMap<String, List<String>> datas;
	private int execcount;
	private int max = 1;
	private TableMeta tableMeta;
	 
	static {
		logger = Logger.getLogger(BatchOperator.class);
	}
	public BatchOperator(String tableName, HashMap<String, List<String>> datas) throws Exception {
		super();
		this.tableName = tableName;
		this.datas = datas;
		this.tableMeta = TableMetaCenter.getInstance().get(tableName);
	}
	
	public void saveTableData() throws Exception {
		try {
			conn = SqlSession.createConnection();
			conn.setAutoCommit(false);

			NamedSQL namedSQL = NamedSQL.getInstance("insert");
			
			String fieldNames = "";
			String fieldValues = "";
			
			
			List<Field> Fields = tableMeta.getFields();
			
			if (!datas.containsKey("id")) {
				fieldNames = "id,";
				fieldValues = "?,";
			}
			for (String key : datas.keySet()) {
				for (int y = 0; y < Fields.size(); y++) {
					Field field = Fields.get(y);
					String fieldName = field.getName();
					if (key.equalsIgnoreCase(fieldName)) {
						fieldNames += key + ",";
						fieldValues += "?,";
					}
				}
			}
			
			fieldNames = fieldNames.substring(0, fieldNames.length()-1);
			fieldValues = fieldValues.substring(0, fieldValues.length()-1);
			
			namedSQL.setParam("tablename", this.tableName);
			namedSQL.setParam("fieldNames", fieldNames);
			namedSQL.setParam("fieldValues", fieldValues);
			
			logger.debug(namedSQL.getSQL());
			SQLRunner.saveData(conn, namedSQL, this);

			conn.commit();
		} catch (Exception e) {
			logger.error(e.getMessage());
			conn.rollback();
			e.printStackTrace();
		}
		finally {
			try {
				if (conn != null) {
					conn.close();
					conn = null;
				}
				
			} catch (SQLException e) {
				logger.debug("conn is not close");
				e.printStackTrace();
			}
		}
	}
	
	@Override
	public void save(PreparedStatement stmt, Object... arg1) throws Exception {
		getLineEntity(execcount, stmt);
		execcount++;
		stmt.addBatch();
		stmt.executeBatch();
	}

	
	
	public void getLineEntity(int index, PreparedStatement stmt) throws Exception {
		List<Field> Fields = tableMeta.getFields();
		Entity entity = new Entity(tableName);
		
		entity.set("id", Util.newShortGUID());
		stmt.setString(1, Util.newShortGUID());
		int number = 2;
		for (String key : datas.keySet()) {
			for (int y = 0; y < Fields.size(); y++) {
				Field field = Fields.get(y);
				String fieldName = field.getName();
				if (key.equalsIgnoreCase(fieldName)) {
					List<String> data = datas.get(key);
					if (data.size() == 1) {
						entity.set(key, data.get(0));
						stmt.setString(number, data.get(0).toString());
					} 
					else {
						this.max = data.size();
						entity.set(key, data.get(index));
						stmt.setString(number, data.get(index).toString());
					}
					
					number++;
				}
			}
			
		}
		
	}

	@Override
	public boolean hasNextForSave() {
		return !(execcount == this.max);
	}

}
