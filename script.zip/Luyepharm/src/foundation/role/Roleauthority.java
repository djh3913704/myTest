package foundation.role;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import foundation.persist.SqlSession;
import foundation.persist.sql.IStepSavable;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.util.Util;

public class Roleauthority implements IStepSavable {
	
	private String rolecode;
	private List<String> menuids;
	private int execcount;
	private static Logger logger;
	private Connection conn;
	static {
		logger = Logger.getLogger(Roleauthority.class);
	}
	public Roleauthority(String rolecode, List<String> menuids) {
		super();
		this.rolecode = rolecode;
		this.menuids = menuids;
		this.execcount = 0;
	}
	
	public void saveMenu() throws Exception {
		try {
			conn = SqlSession.createConnection();
			conn.setAutoCommit(false);

			NamedSQL namedSQL = NamedSQL.getInstance("addRoleauthority");
			SQLRunner.saveData(conn, namedSQL, this);

			conn.commit();
		} catch (Exception e) {
			logger.error(e.getMessage());
			conn.rollback();
			e.printStackTrace();
		}
		finally {
			try {
				if (conn != null) {
					conn.close();
					conn = null;
				}
				
			} catch (SQLException e) {
				logger.debug("conn is not close");
				e.printStackTrace();
			}
		}
	}
	
	@Override
	public void save(PreparedStatement stmt, Object... arg1) throws Exception {
		String menuid = menuids.get(execcount);
		stmt.setString(1, Util.newShortGUID());
		stmt.setString(2, rolecode);
		stmt.setString(3, menuid);
		execcount++;
		stmt.addBatch();
		stmt.executeBatch();
	}

	public String getRolecode() {
		return rolecode;
	}

	public List<String> getMenuids() {
		return menuids;
	}

	@Override
	public boolean hasNextForSave() {
		return !(execcount == menuids.size());
	}
	
}
