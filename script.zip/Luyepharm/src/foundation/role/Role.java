package foundation.role;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import foundation.callable.Callable;
import foundation.data.Entity;
import foundation.data.EntitySet;
import foundation.persist.DataHandler;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.util.Util;

public class Role extends Callable {

	@Override
	protected void doReceive(String[] paths) throws Exception {
		if (paths.length == 2) {
			String operator = paths[1];
			
			if ("setRole".equalsIgnoreCase(operator)) {
				setRole();
			}
			else if ("setRole_Especial".equalsIgnoreCase(operator)) {
				setRole_Especial();
			}
			else if ("setProduct_member".equalsIgnoreCase(operator)) {
				setProduct_member();
			}
			else if ("addRole".equalsIgnoreCase(operator)) {
				addRole();
			}
			else if ("removeRole".equalsIgnoreCase(operator)) {
				removeRole();
			}
			else if ("getTabRole".equalsIgnoreCase(operator)) {
				getTabRole();
			}
			else if ("getButtonRole".equalsIgnoreCase(operator)) {
				getButtonRole();
			}
		}
		else {
			writer.ReplyError("bad data message path:" + fullPath);
		}
	}

	private void setRole() throws Exception {
		String roleid = request.getParameter("id");
		String menuids = request.getParameter("menuids");
		String title = request.getParameter("title");
		String[] menus = menuids.split(",");
		List<String> menuIdList = Arrays.asList(menus);
		
		//1.
		updaTetableRole("rolemapping", "rolecode='" + roleid + "'", "title='" + title + "'");
		
		//替换掉此角色的特殊化处理
		updaTetableRole("employee", "rolecode='" + roleid + "'", "entitle='" + title + "'");
		updaTetableRole("usr", "rolecode='" + roleid + "'", "title='" + title + "'");
		DataHandler.deleteByCriteria("roleauthority", "rolecode in (SELECT rolecode from usr where title='" + title + "') or rolecode='" + roleid + "'");
		
		//2.添加此角色的新权限
		Roleauthority roleauthority = new Roleauthority(roleid, menuIdList);
		roleauthority.saveMenu();
	}
	
	private void setRole_Especial() throws Exception {
		String employeeid = request.getParameter("id");
		String roleid_especial = employeeid;
		String menuids = request.getParameter("menuids");
		String[] menus = menuids.split(",");
		List<String> menuIdList = Arrays.asList(menus);
		
		//1.删除此角色的前特殊化权限
		DataHandler.deleteByCriteria("roleauthority", "rolecode = (SELECT rolecode from usr where id='" + employeeid + "' and not exists (SELECT 1 from rolemapping where rolemapping.rolecode = usr.rolecode))");
		
		//2.替换掉此角色的特殊化处理
		updaTetableRole("employee", "rolecode='" + roleid_especial + "'", "id='" + employeeid + "'");
		updaTetableRole("usr", "rolecode='" + roleid_especial + "'", "id='" + employeeid + "'");
		
		//3.添加此角色的新权限
		Roleauthority roleauthority = new Roleauthority(roleid_especial, menuIdList);
		roleauthority.saveMenu();
	}
	
	private void setProduct_member() throws Exception {
		String parentid = request.getParameter("id");
		List<String> arrayParentid = new ArrayList<String>();
		arrayParentid.add(parentid);
		
		String productids = request.getParameter("productids");
		String[] products = productids.split(",");
		List<String> ProductIdList = Arrays.asList(products);
		
		HashMap<String, List<String>> datas = new HashMap<String, List<String>>();
		datas.put("parentid", arrayParentid);
		datas.put("memberid", ProductIdList);
		
		//1.
		DataHandler.deleteByCriteria("product_member", "parentid ='" + parentid + "'");
		
		//2.添加此产品线产品
		BatchOperator batchOperator = new BatchOperator("product_member", datas);
		batchOperator.saveTableData();
	}
	
	private void addRole() throws Exception {
		//1. add rolemapping
		Entity rolemappingEntity = new Entity("rolemapping");
		getEntityFrowRequest(rolemappingEntity);
		
		DataHandler.saveLine(rolemappingEntity);
		
		//2. add act_id_group 工作流
		String caption = dataPool.getParameter("caption").getStringValue();
		String title = dataPool.getParameter("title").getStringValue();
		
		String fieldNames = "ID_, NAME_,REV_, TYPE_";
		String fieldValues = title + "','" + caption + "',1,'assignment";
		
		addLine("act_id_group", fieldNames, fieldValues);
	}
	
	private void removeRole() throws Exception {
		String rolecode = request.getParameter("rolecode");
		String title = request.getParameter("title");
		
		//1. remove rolemapping
		DataHandler.deleteByCriteria("rolemapping", "title='" + title + "'");
		
		//2. remove roleauthority（包含此角色的特殊化权限）
		DataHandler.deleteByCriteria("roleauthority", "rolecode in (SELECT rolecode from usr where title='" + title + "') or rolecode='" + rolecode + "'");
		
		//3. update usr/employee/act_id_membership
		String usr_entity = "title = null, rolecode = null, caption = null, type = null";
		updaTetableRole("usr", usr_entity, "title='" + title + "'");
		
		String employee_entity = "title = null, entitle = null, cntitle = null, rolecode = null";
		updaTetableRole("employee", employee_entity, "entitle='" + title + "'");
		
	//	工作流
	//	String act_id_membership_entity = "GROUP_ID_ = null";
	//	updaTetableRole("act_id_membership", act_id_membership_entity, "GROUP_ID_='" + title + "'");
		
		//4. remove act_id_group 工作流
	//	DataHandler.deleteByCriteria("act_id_group", "ID_='" + title + "'");
	}
	
	private void updaTetableRole(String tetableName, String entity, String filter) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance("updateByCriteria");
		namedSQL.setTableName(tetableName);
		namedSQL.setParam("entity", entity);
		namedSQL.setParam("filter", filter);
		
		SQLRunner.execSQL(namedSQL);
	}
	
	public static void addLine(String tableName, String fieldNames, String fieldValues) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance("insert");
		namedSQL.setParam("tableName", tableName);
		namedSQL.setParam("fieldNames", fieldNames);
		namedSQL.setParam("fieldValues", "'" + fieldValues + "'");
		
		SQLRunner.execSQL(namedSQL);
	}
	
	private void getTabRole() throws Exception {
		String pagecode = dataPool.getParameter("pagecode").getStringValue();
		String typecode = dataPool.getParameter("typecode").getStringValue();
		
		EntitySet entitySet = getRole("resource_tab", pagecode, typecode, "tab");
		
		if (entitySet.size() > 0) {
			resultPool.addValue(entitySet);
		}
		else {
			resultPool.addValue("notRole", "没有Tab权限");
		}
	}
	
	private void getButtonRole() throws Exception {
		String pagecode = dataPool.getParameter("pagecode").getStringValue();
		String typecode = "";
		
		EntitySet entitySet = getRole("resource_button", pagecode, typecode, "button");
		
		if (entitySet.size() > 0) {
			resultPool.addValue(entitySet);
		}
		else {
			resultPool.addValue("notRole", "没有按键权限");
		}
	}
	
	private EntitySet getRole(String resource_tablename, String pagecode, String typecode, String resourcetype) throws Exception {
		//按指定code获取
		if (!Util.isEmptyStr(typecode)) {
			NamedSQL namedSQL = NamedSQL.getInstance("getResourceByCode");
			namedSQL.setParam("resource_tablename", resource_tablename);
			namedSQL.setParam("resourcecode", typecode);
			namedSQL.setParam("pagecode", pagecode);
			namedSQL.setParam("typecode", resourcetype);
			EntitySet entitySet = SQLRunner.getEntitySet(namedSQL);
			
			return entitySet;
		}
		else {
			//按个性化获取
			NamedSQL namedSQL = NamedSQL.getInstance("getResourceByPersonal");
			namedSQL.setParam("resource_tablename", resource_tablename);
			namedSQL.setParam("userid", onlineUser.getId());
			namedSQL.setParam("pagecode", pagecode);
			namedSQL.setParam("typecode", resourcetype);
			EntitySet entitySet = SQLRunner.getEntitySet(namedSQL);
			
			if (entitySet.size() == 0) {
				//按角色获取
				namedSQL = NamedSQL.getInstance("getResourceByRole");
				namedSQL.setParam("resource_tablename", resource_tablename);
				namedSQL.setParam("rolecode", onlineUser.getEmp_enTitle());
				namedSQL.setParam("pagecode", pagecode);
				namedSQL.setParam("typecode", resourcetype);
				entitySet = SQLRunner.getEntitySet(namedSQL);
				
				if (entitySet.size() == 0) {
					//按下级获取
					namedSQL = NamedSQL.getInstance("getResourceBySubordinate");
					namedSQL.setParam("resource_tablename", resource_tablename);
					namedSQL.setParam("children", Util.getchildren(onlineUser));
					namedSQL.setParam("pagecode", pagecode);
					namedSQL.setParam("typecode", resourcetype);
					entitySet = SQLRunner.getEntitySet(namedSQL);
				}
			}
			
			return entitySet;
		}
	}
}
