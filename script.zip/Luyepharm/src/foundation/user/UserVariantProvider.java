package foundation.user;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import foundation.config.Preloader;
import foundation.variant.GlobalVariant;
import foundation.variant.IVariantRequestListener;
import foundation.variant.VariantExistsException;
import foundation.variant.VariantRequestParams;

public class UserVariantProvider extends Preloader implements IVariantRequestListener {

	private static UserVariantProvider instance;
	private List<String> variantNames;
	
	
	public UserVariantProvider() {
		variantNames = new ArrayList<String>();
		initVariantNames();
	}
	
	public static synchronized UserVariantProvider getInstance() throws VariantExistsException {
		if (instance == null) {
			instance = new UserVariantProvider();
		}
		
		return instance;
	}

	@Override
	public String getStringValue(String name, VariantRequestParams params) {
		if (params == null) {
			logger.error("user variant need request");
			return null;
		}
		
		HttpServletRequest request = params.getRequest();
		
		if (request == null) {
			logger.error("user variant need request");
			return null;
		}
		
		HttpSession session = request.getSession();
		OnlineUser onlineUser = (OnlineUser) session.getAttribute(OnlineUser.class.getSimpleName());
		
		if ("user.id".equals(name)) {
			return onlineUser.getId();
		}
		else if ("userid".equals(name)) {
			return onlineUser.getId();
		}
		else if ("username".equals(name)) {
			return onlineUser.getName();
		}
		else if ("user.name".equals(name)) {
			return onlineUser.getName();
		}
		else if ("user.emp_name".equals(name)) {
			return onlineUser.getEmp_name();
		}
		else if ("user.emp_department".equals(name)) {
			return onlineUser.getEmp_department();
		}
		
		return null;
	}

	@Override
	public List<String> getVariantNames() {
		return variantNames;
	}
	
	public void initVariantNames() {
		variantNames.add("user.id");
		variantNames.add("userid");
		variantNames.add("user.name");
		variantNames.add("username");		
		variantNames.add("user.emp_name");		
		variantNames.add("user.emp_department");		
	}

	@Override
	public void load() throws Exception {
		GlobalVariant.regist(instance);
	}
	
}
