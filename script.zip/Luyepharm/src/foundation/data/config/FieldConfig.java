package foundation.data.config;

import foundation.data.DataType;
import foundation.variant.VariantRequestParams;


public class FieldConfig {

	private String name;
	private DataType type;
	private FieldValueCreator valueCreator;
	
	
	public FieldConfig(String name, String type) {
		this.name = name;
		this.type = DataType.valueOfString(type);
	}

	public void setValue(String value) throws Exception {
		valueCreator = new FieldValueCreator(value, type);
	}
	
	public Object getValue(VariantRequestParams params) throws Exception {
		return valueCreator.getValue(params);
	}

	public void setValueClass(Class<?> clazz) {
		// TODO Auto-generated method stub
	}

	public String getName() {
		return name;
	}

	public DataType getType() {
		return type;
	}

	public FieldValueCreator getValueCreator() {
		return valueCreator;
	}
	

}
