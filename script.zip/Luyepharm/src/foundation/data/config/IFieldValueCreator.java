package foundation.data.config;

import foundation.variant.VariantRequestParams;

public interface IFieldValueCreator {

	Object getValue(VariantRequestParams params) throws Exception;
	
}
