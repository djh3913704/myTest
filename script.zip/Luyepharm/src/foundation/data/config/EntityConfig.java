package foundation.data.config;

import java.util.Iterator;

import foundation.data.MapList;

public class EntityConfig implements Iterable<FieldConfig> {

	private String name;
	private MapList<FieldConfig> fieldList;
	
	public EntityConfig(String name) {
		fieldList = new MapList<FieldConfig>();
		this.name = name;
	}

	public void addField(FieldConfig fieldConfig) {
		fieldList.add(fieldConfig.getName(), fieldConfig);	
	}

	@Override
	public Iterator<FieldConfig> iterator() {
		return fieldList.iterator();
	}

	public String getName() {
		return name;
	}

	public MapList<FieldConfig> getFieldList() {
		return fieldList;
	}

}
