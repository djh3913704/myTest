package foundation.data.config;

import java.math.BigDecimal;

import foundation.data.DataType;
import foundation.variant.Expression;
import foundation.variant.GlobalVariant;
import foundation.variant.VariantRequestParams;
import foundation.variant.VariantSegment;

public class FieldValueCreator extends Expression implements IFieldValueCreator {
	
	private DataType datatype;
	
	public FieldValueCreator(String value, DataType type) throws Exception {
		super(value);
	}

	@Override
	public Object getValue(VariantRequestParams params) throws Exception {
		for (VariantSegment variant: variantList) {
			String name = variant.getName();
			String value = GlobalVariant.getStringValue(name, params);
			variant.setValue(value);
		}
		
		String value = getString();
		
		if (DataType.String == datatype) {
			return value;
		}
		else if (DataType.Integer == datatype) {
			return Integer.valueOf(value);
		}
		else if (DataType.Decimal == datatype) {
			return BigDecimal.valueOf(Double.valueOf(value));
		}
		else if (DataType.Double == datatype) {
			return Double.valueOf(value);
		}
		else {
			return value;
		}
	}

}
