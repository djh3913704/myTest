package foundation.data.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.xml.sax.EntityResolver;

import foundation.config.Configer;
import foundation.server.PreloadContainer;
import foundation.util.DTDEntityResolver;
import foundation.util.Util;

public class EntityConfigContainer extends PreloadContainer<EntityConfig> {

	private static EntityConfigContainer instance;
	
	public static synchronized EntityConfigContainer getInstance() {
		if (instance == null) {
			instance = new EntityConfigContainer();
		}
		
		return instance;
	}
	
	@Override
	public void load() throws Exception {
		File root = new File(Configer.getPath_WebInfo(), "entity");
		
		if (!root.exists()) {
			return;
		}
		
		File[] files = root.listFiles();
		
		for (File config: files) {
			if (!config.isFile()) {
				continue;
			}
			
			loadOneFile(config);
		}		
	}

	private void loadOneFile(File file) {
		try {
			logger.debug("load entity file:" + file);
			InputStream inputStream = new FileInputStream(file);
			
	        try {
	    		SAXReader reader = new SAXReader();
	    		EntityResolver entityResolver = getEntityResolver();
	    		reader.setEntityResolver(entityResolver);
	    			
				Document doc = reader.read(inputStream);
				Element root = doc.getRootElement();
				
				loadEntitys(root);
					
			} catch (DocumentException e) {
				logger.error("can not load sql file: " + file);
				logger.error(e);
			} finally {
				try {
					inputStream.close();
				} catch (IOException e) {
				}
			}
		}
		catch (Exception e) {
			logger.error(e);
		}		
	}

	private void loadEntitys(Element root) throws Exception {
		Iterator<?> iterator = root.elementIterator("entity");
		
		while (iterator.hasNext()) {
			Element element = (Element) iterator.next();	
			loadOneEntity(element);
		}		
	}

	private void loadOneEntity(Element element) throws Exception {
		String name = element.attributeValue("name");	
		EntityConfig entityConfig = new EntityConfig(name);
		
		Iterator<?> iterator = element.elementIterator("field");
		
		while (iterator.hasNext()) {
			Element fieldElemnet = (Element) iterator.next();
			loadOneField(entityConfig, fieldElemnet);
		}
		
		add(name, entityConfig);
	}

	@SuppressWarnings("unchecked")
	private void loadOneField(EntityConfig entityConfig, Element fieldElemnet) throws Exception {
		String name = fieldElemnet.attributeValue("name");
		String type = fieldElemnet.attributeValue("type");
		
		FieldConfig fieldConfig = new FieldConfig(name, type);
		
		String value = fieldElemnet.attributeValue("value");
		
		if (!Util.isEmptyStr(value)) {
			fieldConfig.setValue(value);
			entityConfig.addField(fieldConfig);
			return;
		}
		
		String className = fieldElemnet.attributeValue("classname");
		
		if (!Util.isEmptyStr(className)) {
			Class<IFieldValueCreator> clazz = (Class<IFieldValueCreator>) Class.forName(className);
			fieldConfig.setValueClass(clazz);
			
			entityConfig.addField(fieldConfig);
			return;
		}
	}

	private EntityResolver getEntityResolver() throws FileNotFoundException {
		return new DTDEntityResolver(Configer.getPath_Config(), "entity.dtd");
	}

}
