package foundation.data;

import org.joda.time.DateTime;

public class JsonBuilder {
	 private StringBuilder content;
     private Boolean empty;

     public JsonBuilder() {
         content = new StringBuilder();
         empty = true;
     }

     public void beginObject() {
         if (!empty) {
             content.append(", ");
         }

         content.append("{");
         empty = true;
     }

     public void beginObject(String name) {
         if (!empty) {
             content.append(", ");
         }

         content.append("\"" + name + "\": {");
         empty = true;
     }

     public void endObject() {
         content.append("}");
         empty = false;
     }

     public void beginArray() {
         if (!empty) {
             content.append(", ");
         }

         content.append("[");
         empty = true;
     }

     public void beginArray(String name) {
         if (!empty) {
             content.append(", ");
         }

         content.append("\"" + name + "\": [");
         empty = true;
     }

     public void endArray() {
         content.append("]");
         empty = false;
     }

     public void addValue(String name, String value) {
         if (!empty) {
             content.append(", ");
         }

         content.append("\"" + name + "\": \"" + value + "\"");
         empty = false;
     }
     public void addValue(String name, int value) {
         if (!empty) {
             content.append(", ");
         }

         content.append("\"" + name + "\": " + value);
         empty = false;
     }

     public void addValue(String name, Float value) {
         if (!empty) {
             content.append(", ");
         }

         content.append("\"" + name + "\": " + value);
         empty = false;
     }

     public void addValue(String name, Boolean value) {
         if (!empty) {
             content.append(", ");
         }

         content.append("\"" + name + "\": " + (value ? "true" : "false"));
         empty = false;
     }

     public void addValue(String name, DateTime value) {
         if (!empty) {
             content.append(", ");
         }

         content.append("\"" + name + "\": \"" + value + "\"");
         empty = false;
     }

     public void addValue(String value) {
         if (!empty) {
             content.append(", ");
         }

         content.append("\"" + value + "\"");
         empty = false;
     }
     public void addValue(Integer value) {
         if (!empty) {
             content.append(", ");
         }

         content.append(value.toString());
         empty = false;
     }

     public void addValue(Float value) {
         if (!empty) {
             content.append(", ");
         }

         content.append(value.toString());
         empty = false;
     }

     public void addValue(Boolean value) {
         if (!empty) {
             content.append(", ");
         }

         content.append(value ? "true" : "false");
         empty = false;
     }

     public void addValue(DateTime value) {
         if (!empty) {
             content.append(", ");
         }

         content.append("\"" + value + "\"");
         empty = false;
     }

     public String ToString() {
         return content.toString();
     }

 }
