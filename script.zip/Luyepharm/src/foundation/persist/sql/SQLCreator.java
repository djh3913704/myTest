package foundation.persist.sql;

import org.apache.log4j.Logger;

import foundation.config.Configer;
import foundation.persist.DataBaseType;
import foundation.util.Util;
import foundation.variant.Expression;
import foundation.variant.VariantSegment;

public class SQLCreator extends Expression {
	
	protected static Logger logger;

	
	static {
		logger = Logger.getLogger(SQLCreator.class);
	}
	
	public SQLCreator(String sql) throws Exception {
		super(sql, 8);
	}

	@Override
	public void addVariant(String name) throws Exception {
		if (Util.isEmptyStr(name)) {
			return;
		}
		
		if (variantList.contains(name)) {
			VariantSegment segment = variantList.get(name);
			segments.add(segment);
		}
		else {
			SQLVariant segment = new SQLVariant(name);
			segments.add(segment);
			variantList.add(name, segment);
		}	
	}

	public static String deletePageLimit(String sql) {
		DataBaseType dbType = Configer.getDataBaseType();
		
		if (DataBaseType.MySQL == dbType) {
			return deleteMySQLPageLimit(sql);
		}
		else if (DataBaseType.Oracle == dbType) {
			return deleteOraclePageLimit(sql);
		}
		else if (DataBaseType.SQLServer == dbType) {
			return deleteSQLServerPageLimit(sql);
		}

		return null;
	}

	private static String deleteMySQLPageLimit(String sql) {
		int pos_beginno = sql.indexOf("@{beginno}");
		
		while (pos_beginno > 0) {
			int pos_pagesize = sql.indexOf("@{pagesize}", pos_beginno + 1);
			int pos_limit = sql.lastIndexOf("limit ", pos_beginno);
			
			if (pos_pagesize > 0 && pos_limit > 0) {
				sql = sql.substring(0, pos_limit) + sql.substring(pos_pagesize + "@{pagesize}".length());
			}
			
			pos_beginno = sql.indexOf("@{beginno}", pos_beginno + 1);
		}

		return sql;
	}

	private static String deleteOraclePageLimit(String sql) {
		// TODO Auto-generated method stub
		return null;
	}

	private static String deleteSQLServerPageLimit(String sql) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static void main(String[] args) {
		String sql = "select agreement.*, dealer.code, dealer.name,"
				   + "(select count(1) from agreementArea where agreementArea.parentid = agreement.id) as areaCount,"
				   + "(select count(1) from agreementProduct where agreementProduct.parentid = agreement.id) as productCount"
				   + "from agreement"
				   + "left join dealer on agreement.customerid = dealer.id"
				   + "where @{filter}"
				   + "limit @{beginno}, @{pagesize}";
		
		sql = deleteMySQLPageLimit(sql);
		System.out.println(sql);
	}
}
