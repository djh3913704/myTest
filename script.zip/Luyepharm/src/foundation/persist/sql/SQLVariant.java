package foundation.persist.sql;

import foundation.variant.VariantSegment;


public class SQLVariant extends VariantSegment {

	public SQLVariant(String name) {
		super(name);
	}

	@Override
	public SQLVariant newInstance() {
		SQLVariant result = new SQLVariant(name);
		
		if (NamedSQL.Param_Filter.equalsIgnoreCase(name)) {
			result.value = " 1 = 1 ";
		}
		else if (NamedSQL.Param_OrderBy.equalsIgnoreCase(name)) {
			result.value = "id";
		}
		
		return result;
	}
	
}
