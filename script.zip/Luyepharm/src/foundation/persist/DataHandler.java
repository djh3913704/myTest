package foundation.persist;

import java.sql.Connection;

import org.apache.log4j.Logger;


import foundation.callable.Callable;
import foundation.config.Configer;
import foundation.data.DataType;
import foundation.data.Entity;
import foundation.data.EntitySet;
import foundation.data.Page;
import foundation.encrypt.Encryption;
import foundation.file.FileIoException;
import foundation.persist.loader.EntityLoader;
import foundation.persist.loader.EntitySetLoader;
import foundation.persist.loader.ValueLoader;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.util.Util;

public class DataHandler {
	protected static Logger logger;
	public static boolean isEncryption = false;
	
	static {
		logger = Logger.getLogger(Callable.class);
		isEncryption = Util.stringToBoolean(Configer.getParam("isEncryption"));
	}
	
	public static EntitySet getDataSet(String tableName, String filter) throws Exception {
		return getDataSet(tableName, filter, null);
	}
	
	public static EntitySet getDataSet(String tableName, String filter, String orderby) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance("getDataSet");

		namedSQL.setTableName(tableName);
		namedSQL.setFilter(filter);
		namedSQL.setOrderBy(orderby);		
		
		EntitySetLoader loader = new EntitySetLoader(tableName);
		SQLRunner.getData(namedSQL, loader);
		
		return loader.getDataSet();
	}
	
	public static EntitySet getDataSetByPage(String tableName, String filter, Page page, String orderby) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance("getDataSet");
		namedSQL.setTableName(tableName);
		namedSQL.setFilter(filter);
		
		String dbtype = Configer.getDataBaseType().toString();
		NamedSQL pageDataSQL = NamedSQL.getInstance("getDataByPage_" + dbtype);
		pageDataSQL.setOrderBy(orderby);		
		pageDataSQL.setParam("sql", namedSQL.getSQLString());
		pageDataSQL.setParam("beginNo", page.getBeginRecordNo_1());
		pageDataSQL.setParam("pageSize", page.getPageSize());		
		pageDataSQL.setParam("endno", page.getEndRecordNo());		
		
		EntitySetLoader loader = new EntitySetLoader(tableName);
		SQLRunner.getData(pageDataSQL, loader);
		
		return loader.getDataSet();
	}

	public static Entity getLine(String tableName, String id) throws Exception {
		TableMeta tableMeta = TableMetaCenter.getInstance().get(tableName);
		
		NamedSQL namedSQL = NamedSQL.getInstance("getLineById");
		namedSQL.setTableName(tableName);
		namedSQL.setParam("fieldNameId", tableMeta.getFiledName_Key());
		namedSQL.setParam("id", Util.quotedStr(id));
		
		EntityLoader loader = new EntityLoader(tableName);
		SQLRunner.getData(namedSQL, loader);
		
		return loader.getEntity();
	}
	
	public static void deleteById(String tableName, String id) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance("deleteById");
		namedSQL.setTableName(tableName);
		namedSQL.setParam("id", id);
		
		SQLRunner.execSQL(namedSQL);
	}
	
	public static void deleteByCriteria(String tableName, String filter) throws Exception {
		if (Util.isEmptyStr(filter)) {
			filter = " 1=1 ";
		}
		
		NamedSQL namedSQL = NamedSQL.getInstance("deleteByCriteria");
		namedSQL.setTableName(tableName);
		namedSQL.setParam("filter", filter);
		
		SQLRunner.execSQL(namedSQL);
	}

	public static int getCount(String tableName, String filter) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance("getCount");
		namedSQL.setTableName(tableName);
		namedSQL.setFilter(filter);
		
		ValueLoader loader = new ValueLoader();
		SQLRunner.getData(namedSQL, loader);
		
		return loader.getInt();
	}

	public static EntitySet getSetByPage(String tableName, String filter, Page page) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance("getSetByPage");
		namedSQL.setTableName(tableName);
		namedSQL.setFilter(filter);
		namedSQL.setParam("beginNo", page.getBeginRecordNo());
		namedSQL.setParam("endNo", page.getEndRecordNo());
		
		EntitySetLoader loader = new EntitySetLoader(tableName);
		SQLRunner.getData(namedSQL, loader);
		
		return loader.getDataSet();
	}
	
	public static EntitySet getSetByPage(TableMeta tableMeta, String filter, Page page) throws Exception {
		String tableName = tableMeta.getName();
		String fieldNames = tableMeta.getDoubleQuotedFieldNames();
		
		NamedSQL namedSQL = NamedSQL.getInstance("getSetByPage");
		namedSQL.setTableName(tableName);
		namedSQL.setFilter(filter);
		namedSQL.setParam("fieldNames", fieldNames);	
		namedSQL.setParam("beginNo", page.getBeginRecordNo());
		namedSQL.setParam("endNo", page.getEndRecordNo());
		
		EntitySetLoader loader = new EntitySetLoader(tableName);
		loader.setTableMeta(tableMeta);
		SQLRunner.getData(namedSQL, loader);
		
		return loader.getDataSet();
	}
	
	public static EntitySet getSetByPage(TableMeta tableMeta, String fields, String filter, Page page) throws Exception {
		String tableName = tableMeta.getName();
		
		NamedSQL namedSQL = NamedSQL.getInstance("getSetByPage");
		namedSQL.setTableName(tableName);
		namedSQL.setFilter(filter);
		namedSQL.setParam("fieldNames", fields);	
		namedSQL.setParam("beginNo", page.getBeginRecordNo());
		namedSQL.setParam("endNo", page.getEndRecordNo());
		
		EntitySetLoader loader = new EntitySetLoader(tableName);
		loader.setTableMeta(tableMeta);
		SQLRunner.getData(namedSQL, loader);
		
		return loader.getDataSet();
	}

	public static void addDataSet(EntitySet entitySet) throws Exception {
		addDataSet(null, entitySet);
	}
	
	public static void addDataSet(Connection conn, EntitySet entitySet) throws Exception {
		for (Entity entity: entitySet) {
			addLine(conn, entity);
		}
	}
	
	public static void addLine(Entity entity) throws Exception {
		addLine(null, entity);
	}
	
	public static void addLine(Connection conn, Entity entity) throws Exception {
		if (Util.isEmptyStr(entity.getString("id"))) {
			entity.set("id", Util.newShortGUID());
		}
		
		TableMeta tableMeta = entity.getTableMeta();
		String tableName = tableMeta.getName();	
		
		/*if (isEncryption) {
			entity = encryptionLine(tableName, entity);
		}*/
		
		NamedSQL namedSQL = NamedSQL.getInstance("insert");
		namedSQL.setTableName(tableName);
		namedSQL.setFieldNames(tableMeta, entity);
		namedSQL.setValues(entity);
		
		SQLRunner.execSQL(conn, namedSQL);
	}
	
	public static Entity encryptionLine(String tableName, Entity dataEntity) throws Exception {
		TableMeta dataTableMeta = dataEntity.getTableMeta();
		
		NamedSQL namedSQL = NamedSQL.getInstance("getEncryptiondetailBytable");
		namedSQL.setTableName(tableName);
		
		EntitySet entitySet = SQLRunner.getEntitySet(namedSQL);
		if (!Util.isEmptyStr(entitySet) && entitySet.size() > 0) {
			for (Entity entity : entitySet) {
				String fieldname = entity.getString("fieldname");
				
				Field field = dataTableMeta.get(fieldname);
				
				double d = 0.0;
				
				DataType type = field.getDataType();
				
				if (DataType.Decimal == type) {
					d = dataEntity.getBigDecimal(fieldname).doubleValue();
				}
				else if (DataType.String == type) {
					d = Double.parseDouble(dataEntity.getString(fieldname));
				}
				else {
					throw new FileIoException(tableName + "表中" + fieldname + "字段的数据类型不可加密");
				}
				
				double fieldval = Encryption.retNumber(d, "YR");
				dataEntity.set(fieldname, fieldval);
			}
		}
		
		return dataEntity;
	}

	public static void saveLine(Entity entity) throws Exception {
		if (Util.isEmptyStr(entity.getString("id"))) {
			entity.set("id", Util.newShortGUID());
		}
		
		TableMeta tableMeta = entity.getTableMeta();
		String tableName = tableMeta.getName();	
		
		NamedSQL namedSQL = NamedSQL.getInstance("getCountOfId");
		namedSQL.setTableName(tableName);
		namedSQL.setParam("id", Util.quotedStr(entity.getString("id")));
		int cnt = SQLRunner.getInteger(namedSQL);
		
		if (cnt == 0) {
			addLine(entity); 
		}
		else {
			updateLine(entity);
		}
	}

	public static void updateLine(Entity entity) throws Exception {
		TableMeta tableMeta = entity.getTableMeta();
		String tableName = tableMeta.getName();	
		
		NamedSQL namedSQL = NamedSQL.getInstance("updateById");
		namedSQL.setTableName(tableName);
		namedSQL.setFieldNameValues(entity);
		namedSQL.setParam("fieldNameId", "id");
		namedSQL.setParam("id", Util.quotedStr(entity.getString("id")));
		
		SQLRunner.execSQL(namedSQL);		
	}
	
	public static void clearFieldbyEntity (Entity entity,String field) throws Exception {
		TableMeta tableMeta = entity.getTableMeta();
		String tableName = tableMeta.getName();	
		
		NamedSQL namedSQL = NamedSQL.getInstance("clearFieldbyId");
		namedSQL.setTableName(tableName);
		namedSQL.setParam("field",field);
		namedSQL.setParam("fieldNameId", "id");
		namedSQL.setParam("id", Util.quotedStr(entity.getString("id")));
		
		SQLRunner.execSQL(namedSQL);		
	}
	
	public static void deleteLine(Entity entity) throws Exception {
		TableMeta tableMeta = entity.getTableMeta();
		String tableName = tableMeta.getName();	
		
		NamedSQL namedSQL = NamedSQL.getInstance("deleteById");
		namedSQL.setTableName(tableName);
		namedSQL.setParam("id", entity.getString("id"));
		
		SQLRunner.execSQL(namedSQL);
	}
	
	public static void execSQL(String namedsql) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance(namedsql);
		
		logger.debug(namedSQL.getSQL());
		SQLRunner.execSQL(namedSQL);
	}
}
