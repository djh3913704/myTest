package foundation.persist;

import java.util.List;

import foundation.callable.Callable;
import foundation.config.Configer;
import foundation.data.Entity;
import foundation.data.EntitySet;
import foundation.data.Page;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.Result;
import foundation.persist.sql.ReturnType;
import foundation.persist.sql.SQLRunner;
import foundation.server.Sysparam;
import foundation.variant.VariantRequestParams;
import foundation.variant.VariantSegment;

public class DataObject extends Callable {

	private String data;
	private String operator;

	protected void doReceive(String[] paths) throws Exception {
		try {
			if (paths.length >= 3) {
				data = paths[1];
				operator = paths[2];

				if ("procedure".equalsIgnoreCase(data)) {
					execProcedure();
					resultPool.success();
				}
				else {
					if ("getDataSet".equalsIgnoreCase(operator)) {
						try {
							String filter = getFilter(data);
							String orderby = getOrderBy();
							EntitySet entitySet = DataHandler.getDataSet(data, filter, orderby);

							resultPool.addValue(entitySet);
						}
						catch (Exception e) {
							e.printStackTrace();
							throw e;
						}
					}
					else if ("getSetByPage".equalsIgnoreCase(operator)) {
						String filter = getFilter(data);
						int totalCount = DataHandler.getCount(data, filter);
						String orderby = getOrderBy();
						Page page = getPage(totalCount);
						EntitySet entitySet = DataHandler.getDataSetByPage(data, filter, page, orderby);

						resultPool.addValue("page", page);
						resultPool.addValue(entitySet);
					}
					else if ("getComboboxDataSet".equalsIgnoreCase(operator)) {
						String filter = getFilter(data);
						String orderby = getOrderBy();
						EntitySet entitySet = DataHandler.getDataSet(data, filter, orderby);
						resultPool.addValue(entitySet);
					}
					else if ("getLine".equalsIgnoreCase(operator)) {
						String id = getId();
						Entity entity = DataHandler.getLine(data, id);
						resultPool.addValue(entity);
					}
					else if ("deleteById".equalsIgnoreCase(operator)) {
						String id = getId();

						DataHandler.deleteById(data, id);
						resultPool.success();
					}
					else if ("deleteByCriteria".equalsIgnoreCase(operator)) {
						String filter = getFilter(data);
						
						DataHandler.deleteByCriteria(data, filter);
						resultPool.success();
					}
					else if ("newObject".equalsIgnoreCase(operator)) {
						Entity entity = new Entity(data);
						entity.loadDefaultValue(new VariantRequestParams(request));
						resultPool.addValue("line", entity);
					}
					else if ("addLine".equalsIgnoreCase(operator)) {
						Entity entity = new Entity(data);
						entity.loadDefaultValue(new VariantRequestParams(request));
						getEntityFrowRequest(entity);
						DataHandler.addLine(entity);
						
						resultPool.addValue("line", entity);
						resultPool.success();
					}
					else if ("saveLine".equalsIgnoreCase(operator)) {
						Entity entity = new Entity(data);
						getEntityFrowRequest(entity);

						DataHandler.saveLine(entity);
						resultPool.success();
					}
					else if ("getCount".equalsIgnoreCase(operator)) {
						String filter = getFilter(data);
						int totalCount = DataHandler.getCount(data, filter);
						resultPool.addValue(totalCount);
					}
					else if ("getSysparams".equalsIgnoreCase(operator)) {
						List<Sysparam> list = Configer.getClientSysparams();
						resultPool.addValue(list);
					}
					else if ("updateTable".equalsIgnoreCase(operator)) {
						NamedSQL namedSQL = NamedSQL.getInstance(data);
						
						for (VariantSegment variant : namedSQL) {
							String name = variant.getName();
							String value = locateSQLVariant(name);
							
							if (value == null) {
								if (Page.containsVarinat(name)) {
									continue;
								}
								logger.error("execute procedure error, empty param: " + name);
								return;
							}
							
							variant.setValue(value);
						}
						
						SQLRunner.execSQL(namedSQL);
						resultPool.success();
					}
				}
			}
			else {
				writer.ReplyError("bad data message path:" + fullPath);
			}			
		}
		catch (Exception e) {
			logger.error("execute dataobject error: " + fullPath);
			throw e;
		}
	}
	
	private void execProcedure() throws Exception {
		ReturnType returnType = ReturnType.EntitySet;
		if (paths.length > 3) {
			returnType = ReturnType.valueOfString(paths[3]);
		}

		Page page = tryGetPage();
		
		
		//1. get original SQL
		NamedSQL namedSQL = NamedSQL.getInstance(operator);
		
		for (VariantSegment variant : namedSQL) {
			String name = variant.getName();
			String value = locateSQLVariant(name);
			
			if (value == null) {
				if (Page.containsVarinat(name)) {
					continue;
				}
				logger.error("execute procedure error, empty param: " + name);
				return;
			}
			
			variant.setValue(value);
		}
		
		//2. get data
		if (page != null) {
			//2.1 get data by page
			String dbtype = Configer.getDataBaseType().toString();
			
			NamedSQL countSQL = NamedSQL.getInstance("getCount2");
			countSQL.setParam("sql", namedSQL.getSQLString());
			int count = SQLRunner.getInteger(countSQL);
			page.setRecordCount(count);
			
			NamedSQL pageDataSQL = NamedSQL.getInstance("getDataByPage_" + dbtype);
			for (VariantSegment variant : pageDataSQL) {
				String name = variant.getName();
				String value = page.getStringValue(name, null);
				
				if ("sql".equals(name)) {
					continue;
				}
				
				if (value == null) {
					value = locateSQLVariant(name);
				}
				
				if (value != null) {
					variant.setValue(value);
				}
			}
			
			pageDataSQL.setParam("sql", namedSQL.getSQLString());
			
			pageDataSQL.setReturnType(returnType);
			Result result = pageDataSQL.exec();
			
			resultPool.addValue(result.getObject());
			resultPool.addValue("page", page);
		}
		else {
			//2.2 get data on original SQL
			namedSQL.setReturnType(returnType);
			Result result = namedSQL.exec();
			resultPool.addValue(result.getObject());
		}
	}

}
