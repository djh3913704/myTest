package foundation.file;

public class FileLock {

	private String name;
	private FileLockManager manager;
	private FileProgressor progressor;
	
	public FileLock(String name, FileLockManager manager) {
		this.name = name;
		this.manager = manager;
		
		progressor = new FileProgressor();
	}
	
	public FileProgressor getProgress() {
		return progressor;
	}

	public void release() {
		manager.releaseLock(name);
	}

	public String getName() {
		return name;
	}
}
