package foundation.file;

import javax.servlet.http.HttpServletResponse;

import foundation.callable.DataPool;
import foundation.user.OnlineUser;

public class FileRequest {

	protected OnlineUser onlineUser;
	protected DataPool dataPool;
	protected HttpServletResponse httpResponse;
	private String repository;
	private String fileIOCode;
	protected Range range;  //本类中无初始化，给子类使用
	
	public FileRequest(OnlineUser user, String[] paths, DataPool dataPool, HttpServletResponse httpResponse) throws FileRequestException {
		this.onlineUser = user;
		this.dataPool = dataPool;
		this.httpResponse = httpResponse;
		
		this.repository = dataPool.getParameter("repository").getStringValue();
		this.fileIOCode = dataPool.getParameter("code").getStringValue();	
		this.range = Range.valueOfString(dataPool.getParameter("range").getStringValue()); 
	}
	
	public Range getRange() {
		return range;
	}

	public OnlineUser getOnlineUser() {
		return onlineUser;
	}
	
	public String getRepository() {
		return repository;
	}

	public String getFileIOCode() {
		return fileIOCode;
	}

	public DataPool getDataPool() {
		return dataPool;
	}
	
}
