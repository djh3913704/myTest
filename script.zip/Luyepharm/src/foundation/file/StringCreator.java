package foundation.file;

public class StringCreator {
	  private Boolean empty = true;
      private String division;
      private StringBuilder builder;

      public StringCreator(String value) {
          builder = new StringBuilder();
          division = value;
      }

      public void append(String value) {
          if (!empty) {
              builder.append(division);
          }

          builder.append(value);
          empty = false;
      }

      public  String ToString() {
          return builder.toString();
      }
}
