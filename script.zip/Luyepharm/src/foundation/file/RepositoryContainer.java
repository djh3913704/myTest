package foundation.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import foundation.config.Configer;
import foundation.server.PreloadContainer;
import foundation.util.Util;

public class RepositoryContainer extends PreloadContainer<Repository> {

	private static RepositoryContainer instance;
	private Repository defaultRepository;
	
	public static synchronized RepositoryContainer getInstance() {
		if (instance == null) {
			instance = new RepositoryContainer();
		}
		
		return instance;
	}
	
	@Override
	public void load() throws Exception {
		try {
			File file = new File(Configer.getPath_Config(), "repository.xml");
			
			logger.debug("load entity file:" + file);
			InputStream inputStream = new FileInputStream(file);
			
	        try {
	    		SAXReader reader = new SAXReader();
				Document doc = reader.read(inputStream);
				Element root = doc.getRootElement();
				
				loadRepositorys(root);
					
			} catch (DocumentException e) {
				logger.error("can not load sql file: " + file);
				logger.error(e);
			} finally {
				try {
					inputStream.close();
				} catch (IOException e) {
				}
			}
		}
		catch (Exception e) {
			logger.error(e);
		}		
	}

	private void loadRepositorys(Element root) throws Exception {
		Iterator<?> iterator = root.elementIterator("repository");
		
		while (iterator.hasNext()) {
			Element element = (Element) iterator.next();	
			loadOneRepository(element);
		}		
	}

	private void loadOneRepository(Element element) throws Exception {
		String name = element.attributeValue("name");	
		String root = element.attributeValue("root");
		boolean isDefault = Util.stringToBoolean(element.attributeValue("default"));
		
		String path = element.getTextTrim();
		
		Repository repository = new Repository(name, root);
		repository.setPath(path);
		
		add(name, repository);
		
		if (isDefault) {
			defaultRepository = repository;
		}
	}

	public Repository getDefault() {
		return defaultRepository;
	}

}
