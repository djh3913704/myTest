package foundation.file;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import foundation.callable.DataPool;
import foundation.file.processor.AppendMode;
import foundation.file.processor.DeleteMode;
import foundation.file.processor.FileIOItem;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.variant.VariantContext;

public class EventListener {

	private static Logger logger;
	private static EventListener instance;
	private static Object lock = new Object();
	private Set<IFileEventListener> listenerSet;

	static {
		logger = Logger.getLogger(EventListener.class);
	}

	private EventListener() {
		listenerSet = new HashSet<IFileEventListener>();
	}

	public static EventListener getInstance() {
		if (instance == null) {
			synchronized (lock) {
				if (instance == null) {
					instance = new EventListener();
				}
			}
		}

		return instance;
	}

	public static void register(IFileEventListener listener) {
		getInstance();

		if (!instance.listenerSet.contains(listener)) {
			instance.listenerSet.add(listener);
		}
	}

	public static void fireRepositoryEvent(String event, UploadResult result, DataPool datapool) throws Exception {
		notifyRepositoryEventToListers(event, result, datapool);
	}

	public static void fireDataBaseEvent(String ioCode, String event, List<FileIOItem> ioList, DataPool datapool) throws Exception {
		getInstance();

		if (event == null) {
			logger.error("file event listener error: empty event");
		}

		event = event.toLowerCase();

		if ("beforesave".equals(event)) {
			notifyDataBaseEventToListers(ioCode, "beforesave", datapool);
			instance.onBeforeSave(datapool, ioList);
		}
		else if ("aftersave".equals(event)) {
			instance.onAfterSave(datapool, ioList);
			notifyDataBaseEventToListers(ioCode, "aftersave", datapool);
		}
	}

	private void onBeforeSave(DataPool datapool, List<FileIOItem> ioList) throws Exception {
		for (FileIOItem fileIOItem : ioList) {
			FileIOContext context = fileIOItem.getContext();

			// if (processor.isDefaultBeroreSave()) {
			// execute("emptyTempTable", context);
			// }

			if (fileIOItem != null) {
				fileIOItem.fire("beforesave", context);
			}
		}
	}

	private void onAfterSave(DataPool datapool, List<FileIOItem> ioList) throws Exception {
		for (FileIOItem fileIOItem : ioList) {
			FileIOContext context = fileIOItem.getContext();

			// 1. process temple data
			if (fileIOItem != null) {
				fileIOItem.fire("precessTempTable", context);//
			}

			// processor.checkout(context); // 上传临时表处理后的检测
			// processor.checkoutKeyfield(context); // 上传临时表处理后的keyfield唯一性检测

			if (fileIOItem.isStandardMove()) {
				transferData(context, fileIOItem);// 上传到正式表
			}

			// 3. after save
			if (fileIOItem != null) {
				fileIOItem.fire("aftersave", context);
			}
		}
	}

	protected void transferData(FileIOContext context, FileIOItem fileIO) throws Exception {
		AppendMode appendMode = fileIO.getAppendMode();
		DeleteMode deleteMode = fileIO.getDeleteMode();

		if (AppendMode.Append == appendMode) {
			execute("transferAll", context);
		}
		else if (AppendMode.ClearAndAppend == appendMode) {
			// 1. clear data
			if (fileIO.existsFilterFieldValues()) {
				execute("deleteByFilter", context);
			}
			else {
				execute("deleteAll", context);
			}

			// 2. transfer data
			execute("transferAll", context);
		}
		else if (AppendMode.UpdateChanged == appendMode) {
			// 1. delete not exists data
			if (DeleteMode.HardDelete == deleteMode) {
				execute("hardDeleteNotExists", context);
			}
			else if (DeleteMode.SoftDelete == deleteMode) {
				execute("softDeleteNotExists", context);
			}

			// 2. update exists data
			execute("updateExists", context);

			// 3. insert append data
			execute("insertAppend", context);
		}
		else if (AppendMode.InsertChanged == appendMode) {

			// 2. update exists data
			execute("updateExists", context);

			// 3. insert append data
			execute("insertAppend", context);
		}
	}

	private void execute(String sqlName, FileIOContext context) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance(sqlName);
		context.setParametersTo(namedSQL);
		SQLRunner.execSQL(namedSQL);
	}

	private static void notifyDataBaseEventToListers(String ioCode, String event, DataPool datapool) {
		for (IFileEventListener listener : instance.listenerSet) {
			try {
				listener.onDataBaseEvent(ioCode, event, datapool);
			} catch (Exception e) {
				logger.error("file event error: " + e.getMessage());
			}
		}
	}

	private static void notifyRepositoryEventToListers(String event, UploadResult result, DataPool datapool) {
		for (IFileEventListener listener : instance.listenerSet) {
			try {
				listener.onRepositoryEvent(event, result, datapool);
			} catch (Exception e) {
				logger.error("file event error: " + e.getMessage());
			}
		}
	}

}
