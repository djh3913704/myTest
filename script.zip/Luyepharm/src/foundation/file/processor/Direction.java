package foundation.file.processor;

public enum Direction {
	 Normal, Convert;
	 
		public static Direction valueOfString(String value) {
			
			if ("Normal".equalsIgnoreCase(value)) {
				return Normal;
			}
			else if ("Convert".equalsIgnoreCase(value)) {
				return Convert;
			}
			
			return Normal;
		}
}
