package foundation.file.processor;

import foundation.data.Entity;
import foundation.file.FileIOContext;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;

public class IOHandler {
	
	private String id;
	private String ioCode;
	private String name;
	private String eventCode;
	private String errorMsg;
	private String itemId;
	

	public IOHandler() {
		
	}

	public void load(Entity entity) {
		id = entity.getString("id");
		ioCode = entity.getString("iocode");
		name = entity.getString("namedSql");
		eventCode = entity.getString("eventCode");
		errorMsg = entity.getString("errormsg");
		itemId = entity.getString("itemId");
	}

	public String getEventCode() {
		return eventCode;
	}

	public void exec(FileIOContext context) throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance(name);
		context.setParametersTo(namedSQL);
		SQLRunner.execSQL(namedSQL);
	}

	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}

	public String getIoCode() {
		return ioCode;
	}
	
    public String getItemId() {
        return itemId;
    }
    
}
