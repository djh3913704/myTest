package foundation.file.processor;

import foundation.data.DataType;
import foundation.persist.*;

public class IOMappingItemRuntime {
	private IOMappingItem item;
	private String fromField;
	private int fromIndex;
	private DataType fromType;
	private String toField;
	private int toIndex;
	private DataType toType;

	public IOMappingItemRuntime(IOMappingItem item, String fromField,
			Field fromFieldMeta, String toField, Field toFieldMeta) {
		this.item = item;

		// 1. set from
		this.fromField = fromField == null ? null : fromField.toLowerCase();

		if (fromFieldMeta != null) {
			fromIndex = fromFieldMeta.getIndex();
			fromType = fromFieldMeta.getDataType();
		} else {
			fromIndex = -1;
			fromType = null;
		}

		// 2. set to
		this.toField = toField == null ? null : toField.toLowerCase();
		if (toFieldMeta != null) {
			toIndex = toFieldMeta.getIndex();
			toType = toFieldMeta.getDataType();
		} else {
			toIndex = -1;
			toType = null;
		}
	}

	public String getFromField() {
		return fromField;
	}

	public String getToField() {
		return toField;
	}

	public DataType getFromType() {
		if (item == null) {
			return fromType;
		}

		if (item.getDataType() == null) {
			return fromType;
		}

		return item.getDataType();
	}

	public int getToIndex() {
		return toIndex;
	}

	public DataType getToType() {
		if (item == null) {
			return toType;
		}

		if (item.getDataType() == null) {
			return toType;
		}

		return item.getDataType();
	}

	public String getRule() {
		return item.getRule();
	}

	public String getTypeStr() {
		return item.getTypeStr();
	}

	public int getFromIndex() {
		return fromIndex;
	}

	public void setFromIndex(int fromIndex) {
		this.fromIndex = fromIndex;
	}
}
