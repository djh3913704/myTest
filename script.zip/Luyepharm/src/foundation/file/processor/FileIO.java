package foundation.file.processor;

import java.util.ArrayList;
import java.util.List;
import foundation.data.Entity;
import foundation.data.MapList;

public class FileIO extends IOProcessor {

	protected String id;
	protected String code;
	protected String tableName;

	private MapList<FileIOItem> itemList;

	public FileIO() {
		itemList = new MapList<FileIOItem>();
	}

	public void load(Entity entity) throws Exception {
		id = entity.getString("id");
		code = entity.getString("code");
	}

	public String getId() {
		return id;
	}

	public String getCode() {
		return code;
	}

	public MapList<FileIOItem> getItems() {
		return itemList;
	}

	public List<FileIOItem> getItemList(String typecode) {
		List<FileIOItem> result = new ArrayList<FileIOItem>();

		List<FileIOItem> list = itemList.getItemList();

		for (FileIOItem item : list) {
			if (typecode.equals(item.getTypeCode())) {
				result.add(item);
			}
		}

		return result;
	}

	public void addItem(FileIOItem item) {
		String id = item.getId();
		itemList.add(id, item);
	}

	public FileIOItem getItem(String id) {
		if (!itemList.contains(id)) {
			return null;
		}

		return itemList.get(id);
	}

	public void clear() {
		itemList.clear();
	}

	public void createRuntime() throws Exception {
		List<FileIOItem> items = itemList.getItemList();

		for (FileIOItem ioItem : items) {
			ioItem.createTableMeta();
		}
	}
}
