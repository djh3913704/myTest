package foundation.file.processor;

import java.util.List;

import foundation.persist.TableMeta;
import foundation.persist.TableMetaCenter;
import foundation.util.Util;
import foundation.callable.DataPool;
import foundation.data.Entity;
import foundation.file.FileIOContext;

public class FileIOItem extends IOProcessor {
	public static String TypeCode_Import = "import";
	public static String TypeCode_DB = "db";
	public static String TypeCode_Output = "output";

	private String id;
	private String fromName;
	private String toName;
	private String typeCode;
	private String mappingId;
	private Boolean distinctSelect;
	private Boolean standardMove;
	private String[] filterFieldValues;
	private String[] keyFieldPairs;
	private AppendMode appendMode;
	private DeleteMode deleteMode;
	private Direction direction;

	private TableMeta fromMeta;
	private TableMeta toMeta;
	private IOMapping mapping;
	private IOMappingRuntime mappingRuntime;
	private FileIOContext context;

	public FileIOItem() {
		mapping = new IOMapping();
	}

	public void load(Entity entity) {
		id = entity.getString("id");
		fromName = entity.getString("fromName");
		toName = entity.getString("toName");
		mappingId = entity.getString("mappingId");
		typeCode = entity.getString("typeCode");

		distinctSelect = Util.stringToBoolean(entity.getString("distinctSelect"), false);
		standardMove = Util.stringToBoolean(entity.getString("standardMove"),
				true);

		appendMode = AppendMode.valueOfString(entity.getString("appendMode"));
		deleteMode = DeleteMode.valueOfString(entity.getString("deleteMode"));
		direction = Direction.valueOfString(entity.getString("direction"));

		String keyField = entity.getString("keyfieldPairs");
		if (!Util.isEmptyStr(keyField)) {
			keyFieldPairs = keyField.split(";");
		}

		String filterField = entity.getString("filterFieldValues");
		if (!Util.isEmptyStr(filterField)) {
			filterFieldValues = filterField.split(";");
		}
	}

	public void createTableMeta() throws Exception {
		if (TypeCode_DB.equals(typeCode)) {
			fromMeta = TableMetaCenter.getInstance().get(fromName);
			toMeta = TableMetaCenter.getInstance().get(toName);
		}
	}

	public void createMappingRuntime(FileIOContext context) throws Exception {

		if (TypeCode_DB.equals(typeCode)) {
			mappingRuntime = mapping.createRuntime(TypeCode_DB, fromMeta,
					toMeta, direction);
		}
	}

	public String getFromName() {
		return fromName;
	}

	public String getToName() {
		return toName;
	}

	public String getId() {
		return id;
	}

	public Boolean isDistinctSelect() {
		return distinctSelect;
	}

	public String[] getFilterFieldValues() {
		return filterFieldValues;
	}

	public String[] getKeyFieldPairs() {
		return keyFieldPairs;
	}

	public IOMapping getMapping() {
		return mapping;
	}

	public Boolean isStandardMove() {
		return standardMove;
	}

	public AppendMode getAppendMode() {
		return appendMode;
	}

	public DeleteMode getDeleteMode() {
		return deleteMode;
	}

	public Direction getDirection() {
		return direction;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public Boolean existsFilterFieldValues() {
		if (filterFieldValues == null) {
			return false;
		}

		return filterFieldValues.length > 0;
	}

	public String getMappingId() {
		return mappingId;
	}

	public void setMapping(IOMapping mapping) {
		this.mapping = mapping;
	}

	public List<IOMappingItemRuntime> getUpdateMappingRuntime() {
		return mappingRuntime.getUpdateMappingRuntime();
	}

	public IOMappingItemRuntimeList getInsertMappingRuntime() {
		return mappingRuntime.getInsertMappingRuntime();
	}

	public FileIOContext createContext(DataPool pool) throws Exception {
		context = new FileIOContext(pool, this);
		return context;
	}

	public FileIOContext getContext() {
		return context;
	}
	
}
