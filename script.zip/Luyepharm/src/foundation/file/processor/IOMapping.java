package foundation.file.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import foundation.data.Entity;
import foundation.persist.TableMeta;
import java.util.List;
import foundation.persist.*;
import foundation.util.Util;

public class IOMapping {
	private String id;
	private String name;
	private Boolean open;
	private List<IOMappingItem> itemList;
	private Map<String, IOMappingItem> fromItemMap;
	private Map<String, IOMappingItem> toItemMap;

	public IOMapping() {
		itemList = new ArrayList<IOMappingItem>();
		fromItemMap = new HashMap<String, IOMappingItem>();
		toItemMap = new HashMap<String, IOMappingItem>();
	}

	public void load(Entity entity) {
		id = entity.getString("id");
		name = entity.getString("name");
		open = Util.stringToBoolean(entity.getString("open"), true);
	}

	public IOMappingRuntime createRuntime(String condition, TableMeta fromMeta,
			TableMeta toMeta, Direction direction) throws Exception {
		List<IOMappingItemRuntime> updateMappingRuntime = new ArrayList<IOMappingItemRuntime>();
		List<IOMappingItemRuntime> insertMappingRuntime = new ArrayList<IOMappingItemRuntime>();

		// 1. add design field
		for (IOMappingItem item : itemList) {
			String fromField, toField;

			if (Direction.Normal == direction) {
				fromField = item.getFromField();
				toField = item.getToField();
			} else {
				fromField = item.getToField();
				toField = item.getFromField();
			}

			Field fromFieldMeta = fromMeta.get(fromField);
			int fromIndex = fromMeta.getIndex(fromField);
			fromFieldMeta.setIndex(fromIndex);
			Field toFieldMeta = toMeta.get(toField);
			int toIndex = fromMeta.getIndex(toField);
			toFieldMeta.setIndex(toIndex);

			if (fromFieldMeta == null || toFieldMeta == null) {
				if (FileIOItem.TypeCode_DB.equals(condition)) {
					if (item.isUpdateIgnore() || item.isInsertIgnore()) {
						continue;
					} else {
						throw new Exception("IO Mapping fields not in table:"
								+ item.ToString() + " " + fromMeta.getName()
								+ ", " + toMeta.getName());
					}
				} else {
					continue;
				}
			}

			IOMappingItemRuntime itemRuntime = new IOMappingItemRuntime(item,
					fromField, null, toField, null);

			if (!item.isUpdateIgnore()) {
				updateMappingRuntime.add(itemRuntime);
			}

			if (!item.isInsertIgnore()) {
				insertMappingRuntime.add(itemRuntime);
			}
		}

		// 2. add auto field
		if (open) {
			String[] fromFields = fromMeta.getLowerNames();

			for (String field : fromFields) {
				if (!toMeta.contains(field)) {
					continue;
				}

				Field fromFieldMeta = fromMeta.get(field);
				Field toFieldMeta = toMeta.get(field);

				IOMappingItemRuntime itemRuntime = new IOMappingItemRuntime(
						null, field, fromFieldMeta, field, toFieldMeta);

				if (!fromItemMap.containsKey(field)) {
					updateMappingRuntime.add(itemRuntime);
				}

				if (!fromItemMap.containsKey(field)) {
					insertMappingRuntime.add(itemRuntime);
				}
			}
		}

		return new IOMappingRuntime(updateMappingRuntime, insertMappingRuntime);
	}

	public int size() {
		return itemList.size();
	}

	public List<IOMappingItem> getList() {
		return itemList;
	}

	public void addItem(IOMappingItem item) {
		String fromField = item.getFromField();
		String toField = item.getToField();

		itemList.add(item);

		if (fromField != null) {
			fromItemMap.put(fromField, item);
		}

		if (toField != null) {
			toItemMap.put(toField, item);
		}
	}

	public String getFromField(String toField) {
		if (toField == null) {
			return null;
		}

		toField = toField.toLowerCase();

		if (!toItemMap.containsKey(toField)) {
			return null;
		}

		IOMappingItem item = toItemMap.get(toField);
		return item.getFromField();
	}

	public String getToField(String fromField) {
		if (fromField == null) {
			return null;
		}

		fromField = fromField.toLowerCase();

		if (!fromItemMap.containsKey(fromField)) {
			return null;
		}

		IOMappingItem item = fromItemMap.get(fromField);
		return item.getToField();
	}

	public IOMappingItem getItemByFromField(String fromField) {
		if (fromField == null) {
			return null;
		}

		fromField = fromField.toLowerCase();

		if (!fromItemMap.containsKey(fromField)) {
			return null;
		}

		IOMappingItem item = fromItemMap.get(fromField);
		return item;
	}

	public IOMappingItem getItemByToField(String toField) {
		if (toField == null) {
			return null;
		}

		toField = toField.toLowerCase();

		if (!toItemMap.containsKey(toField)) {
			return null;
		}

		IOMappingItem item = toItemMap.get(toField);
		return item;
	}

	public void clear() {
		itemList.clear();
		fromItemMap.clear();
		toItemMap.clear();
	}

	public Boolean isOpen() {
		return open;
	}

	public String getId() {
		return id;
	}
}
