package foundation.file.processor;

public enum DeleteMode {

	Undefined, HardDelete, SoftDelete;

	public static DeleteMode valueOfString(String value) {

		if ("HardDelete".equalsIgnoreCase(value)) {
			return HardDelete;
		}
		else if ("SoftDelete".equalsIgnoreCase(value)) {
			return SoftDelete;
		}

		return Undefined;
	}

	public static DeleteMode valueOfBoolean(Boolean value) {
		if (value) {
			return HardDelete;
		}
		else {
			return SoftDelete;
		}
	}
}
