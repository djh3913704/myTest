package foundation.file.processor;

public enum AppendMode {

	Undefined, Append, ClearAndAppend, UpdateChanged, InsertChanged;

	public static AppendMode valueOfString(String value) {
		if ("Append".equalsIgnoreCase(value)) {
			return Append;
		}
		else if ("ClearAndAppend".equalsIgnoreCase(value)) {
			return ClearAndAppend;
		}
		else if ("UpdateChanged".equalsIgnoreCase(value)) {
			return UpdateChanged;
		}
		else if ("InsertChanged".equalsIgnoreCase(value)) {
			return InsertChanged;
		}

		return Undefined;
	}
}
