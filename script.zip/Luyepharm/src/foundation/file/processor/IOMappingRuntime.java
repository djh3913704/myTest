package foundation.file.processor;

import java.util.*;

public class IOMappingRuntime {
	private IOMappingItemRuntimeList updateMappingRuntime;
	private IOMappingItemRuntimeList insertMappingRuntime;

	public IOMappingRuntime(List<IOMappingItemRuntime> updateMappingRuntime,
			List<IOMappingItemRuntime> insertMappingRuntime) {
		this.updateMappingRuntime = new IOMappingItemRuntimeList(
				updateMappingRuntime);
		this.insertMappingRuntime = new IOMappingItemRuntimeList(
				insertMappingRuntime);
	}

	public IOMappingItemRuntimeList getUpdateMappingRuntime() {
		return updateMappingRuntime;
	}

	public IOMappingItemRuntimeList getInsertMappingRuntime() {
		return insertMappingRuntime;
	}
	
}
