package foundation.file.processor;

import foundation.data.MapList;
import foundation.file.FileIOContext;
import foundation.util.Util;

public abstract class IOProcessor {
	
	private MapList<IOHandler> ioHandlers;

	public IOProcessor() {	
		ioHandlers = new MapList<IOHandler>();
	}

	public void fire(String eventCode, FileIOContext context) throws Exception {
		if (Util.isEmptyStr(eventCode)) {
			return;
		}

		eventCode = eventCode.toLowerCase();

		for (IOHandler handler : ioHandlers) {
			if (eventCode.equalsIgnoreCase(handler.getEventCode())) {
				handler.exec(context);
			}
		}
	}

	public IOHandler getIOHandler(String name) {
		return ioHandlers.get(name);
	}

	public MapList<IOHandler> getIOHandlers() {
		return ioHandlers;
	}

	public void addIOHandler(IOHandler handler) {
		ioHandlers.add(handler.getName(), handler);
	}
}
