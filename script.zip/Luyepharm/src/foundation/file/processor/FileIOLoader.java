package foundation.file.processor;

import foundation.config.Preloader;

public class FileIOLoader extends Preloader {

	private static FileIOLoader instance;
	private FileIOContainer container;

	
	public FileIOLoader() {
		container = FileIOContainer.getInstance();
	}

	public synchronized static FileIOLoader getInstance() {
		if (instance == null) {
			instance = new FileIOLoader();
		}
		return instance;
	}

	@Override
	public void load() throws Exception {
		container.load();	
	}
	
	public void refresh() throws Exception {
		container.clear();
		load();
	}
	
}
