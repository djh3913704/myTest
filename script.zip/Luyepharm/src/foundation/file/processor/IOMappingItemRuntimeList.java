package foundation.file.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IOMappingItemRuntimeList extends ArrayList<IOMappingItemRuntime> {

	private static final long serialVersionUID = 1L;
	private Map<String, IOMappingItemRuntime> fromMap;
	private Map<String, IOMappingItemRuntime> toMap;

	public IOMappingItemRuntimeList(List<IOMappingItemRuntime> itemList) {
		fromMap = new HashMap<String, IOMappingItemRuntime>();
		toMap = new HashMap<String, IOMappingItemRuntime>();

		for (IOMappingItemRuntime item : itemList) {
			addItem(item);
		}
	}

	public void addItem(IOMappingItemRuntime item) {
		add(item);
		
		fromMap.put(item.getFromField(), item);
		toMap.put(item.getToField(), item);
	}

	public Boolean contaisFromField(String fromField) {
		if (fromField == null) {
			return false;
		}

		return fromMap.containsKey(fromField.toLowerCase());
	}

	public Boolean contaisToField(String toField) {
		if (toField == null) {
			return false;
		}

		return toMap.containsKey(toField.toLowerCase());
	}

	public IOMappingItemRuntime getItemByFromField(String fromField) {
		if (fromField == null) {
			return null;
		}

		fromField = fromField.toLowerCase();

		if (!fromMap.containsKey(fromField)) {
			return null;
		}

		return fromMap.get(fromField);
	}

	public IOMappingItemRuntime getItemByToField(String toField) {
		if (toField == null) {
			return null;
		}

		toField = toField.toLowerCase();

		if (!toMap.containsKey(toField)) {
			return null;
		}

		return toMap.get(toField);
	}
}
