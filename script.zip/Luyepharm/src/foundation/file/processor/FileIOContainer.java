package foundation.file.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.data.Entity;
import foundation.data.EntitySet;

public class FileIOContainer {

	private static FileIOContainer instance;
	private Map<String, FileIO> fileIOMap;
	private Map<String, FileIOItem> ioItemMap;
	private Map<String, IOMapping> ioMappingMap;
	private List<FileIO> fileIOList;

	private FileIOContainer() {
		fileIOMap = new HashMap<String, FileIO>();
		ioItemMap = new HashMap<String, FileIOItem>();
		ioMappingMap = new HashMap<String, IOMapping>();
		fileIOList = new ArrayList<FileIO>();
	}

	public static synchronized FileIOContainer getInstance() {
		if (instance == null) {
			instance = new FileIOContainer();
		}

		return instance;
	}

	public static FileIO get(String ioCode) {
		getInstance();

		if (ioCode == null) {
			return null;
		}

		ioCode = ioCode.toLowerCase();

		if (!instance.fileIOMap.containsKey(ioCode)) {
			return null;
		}

		return instance.fileIOMap.get(ioCode);
	}

	public void load() throws Exception {
		getInstance();
		NamedSQL namedSQL;

		// 1. load mapping
		namedSQL = NamedSQL.getInstance("getMappingList");
		namedSQL.setParam("tableName", "BLUE_TT_IOMapping");
		EntitySet mappingList = SQLRunner.getEntitySet(namedSQL);

		for (Entity mappingEntity : mappingList) {
			IOMapping mapping = new IOMapping();
			mapping.load(mappingEntity);

			instance.ioMappingMap.put(mapping.getId(), mapping);
		}

		// 2. load mapping detail
		namedSQL = NamedSQL.getInstance("getMappingDetails");
		namedSQL.setParam("tableName", "BLUE_TT_IOMappingDetail");
		EntitySet mappingDetails = SQLRunner.getEntitySet(namedSQL);
		for (Entity mappingEntity : mappingDetails) {
			IOMappingItem mappingItem = new IOMappingItem();
			mappingItem.load(mappingEntity);

			IOMapping mapping = instance.getIOMapping(mappingItem.getParentId());

			if (mapping == null) {
				return;
			}

			mapping.addItem(mappingItem);
		}

		// 3. load fileio
		namedSQL = NamedSQL.getInstance("getFileIOList");
		namedSQL.setParam("tableName", "BLUE_TT_FileIO");
		EntitySet fileIOList = SQLRunner.getEntitySet(namedSQL);
		for (Entity fileIoEntity : fileIOList) {
			FileIO fileIO = new FileIO();
			fileIO.load(fileIoEntity);

			instance.addFileIO(fileIO);
		}

		// 4. load fileio item
		namedSQL = NamedSQL.getInstance("getFileIOItemList");
		namedSQL.setParam("tableName", "BLUE_TT_FileIO");
		EntitySet fileIOItemList = SQLRunner.getEntitySet(namedSQL);
		for (Entity fileIoItemEntity : fileIOItemList) {
			String ioCode = fileIoItemEntity.getString("code");
			FileIO fileIO = instance.getFileIO(ioCode);

			if (fileIO == null) {
				return;
			}

			FileIOItem ioItem = new FileIOItem();
			ioItem.load(fileIoItemEntity);

			IOMapping mapping = instance.ioMappingMap.get(ioItem.getMappingId());
			ioItem.setMapping(mapping);

			fileIO.addItem(ioItem);
			instance.ioItemMap.put(ioItem.getId(), ioItem);
		}

		// 5. create mapping runtime
		for (FileIO fileIO : instance.fileIOList) {
			fileIO.createRuntime();
		}

		// 6. load ioItem handler
		namedSQL = NamedSQL.getInstance("getIOItemHandlerList");
		namedSQL.setParam("tableName", "iohandler");
		EntitySet privateHandlers = SQLRunner.getEntitySet(namedSQL);
		for (Entity handlerEntity : privateHandlers) {
			IOHandler handler = new IOHandler();
			handler.load(handlerEntity);

			FileIOItem ioItem = instance.getIOItem(handler.getItemId());

			if (ioItem == null) {
				return;
			}

			ioItem.addIOHandler(handler);
		}

		// 7. load fileIO handler
		namedSQL = NamedSQL.getInstance("getFileIOHandlerList");
		namedSQL.setParam("tableName", "iohandler");
		EntitySet publicHandlerList = SQLRunner.getEntitySet(namedSQL);

		for (Entity handlerEntity : publicHandlerList) {

			IOHandler handler = new IOHandler();
			handler.load(handlerEntity);

			FileIO fileIO = instance.getFileIO(handler.getIoCode());

			if (fileIO == null) {
				return;
			}

			fileIO.addIOHandler(handler);
		}
	}

	public void clear() {
		fileIOList.clear();
		fileIOMap.clear();
		ioItemMap.clear();
		ioMappingMap.clear();
	}

	private FileIO getFileIO(String code) {
		if (code == null) {
			return null;
		}

		code = code.toLowerCase();

		if (!instance.fileIOMap.containsKey(code)) {
			return null;
		}

		return instance.fileIOMap.get(code);
	}

	private FileIOItem getIOItem(String id) {
		if (!instance.ioItemMap.containsKey(id)) {
			return null;
		}

		return instance.ioItemMap.get(id);
	}

	private IOMapping getIOMapping(String id) {
		if (!instance.ioMappingMap.containsKey(id)) {
			return null;
		}

		return instance.ioMappingMap.get(id);
	}

	private void addFileIO(FileIO fileIO) {
		String ioCode = fileIO.getCode();

		if (ioCode == null) {
			return;
		}

		ioCode = ioCode.toLowerCase();
		instance.fileIOMap.put(ioCode, fileIO);

		fileIOList.add(fileIO);
	}
	
}
