package foundation.file.processor;

import foundation.data.DataType;
import foundation.data.Entity;
import foundation.util.Util;

public class IOMappingItem {
	private String id;
	private String parentId;
	private String fromField;
	private String toField;
	private Boolean updateIgnore;
	private Boolean insertIgnore;
	private DataType type;
	private String rule;
	private String typeStr;

	public IOMappingItem() {

	}

	public void load(Entity entity) {
		id = entity.getString("id");
		parentId = entity.getString("parentId");
		fromField = entity.getString("fromField");
		toField = entity.getString("toField");
		typeStr = entity.getString("datatype");
		type = DataType.valueOfString(typeStr);
		updateIgnore = Util.stringToBoolean(entity.getString("updateIgnore"), false);
		insertIgnore =Util.stringToBoolean(entity.getString("insertIgnore"), false);	
		rule = entity.getString("rule");
	}

	public String getId() {
		return id;
	}

	public String getFromField() {
		return fromField;
	}

	public String getToField() {
		return toField;
	}

	public Boolean isUpdateIgnore() {
		return updateIgnore;
	}

	public Boolean isInsertIgnore() {
		return insertIgnore;
	}

	public String getParentId() {
		return parentId;
	}

	public String ToString() {
		return fromField + "-->" + toField;
	}

	public DataType getDataType() {
		return type;
	}

	public String getRule() {
		return rule;
	}

	public String getTypeStr() {
		return typeStr;
	}
	
}