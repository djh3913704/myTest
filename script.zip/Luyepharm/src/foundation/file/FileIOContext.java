package foundation.file;

import java.util.ArrayList;
import java.util.List;
import foundation.callable.DataPool;
import foundation.data.Variant;
import foundation.file.processor.FileIOItem;
import foundation.file.processor.IOMappingItemRuntime;
import foundation.file.processor.IOMappingItemRuntimeList;
import foundation.variant.VariantContext;
import foundation.variant.VariantRequestParams;

public class FileIOContext extends VariantContext {

	private static List<String> fparamList;
	protected FileIOItem ioItem;
	protected DataPool datapool;

	public FileIOContext(DataPool datapool, FileIOItem fileIO) throws Exception {
		ioItem = fileIO;
		this.datapool = datapool;
	}

	@Override
	public String getStringValue(String name, VariantRequestParams params) throws Exception {
		if ("totable".equalsIgnoreCase(name)) {
			return ioItem.getToName();
		}
		else if ("fromtable".equalsIgnoreCase(name)) {
			return ioItem.getFromName();
		}
		else if ("distinct".equalsIgnoreCase(name)) {
			return ioItem.isDistinctSelect() ? "distinct" : "";
		}
		else if ("updatefieldpairs".equalsIgnoreCase(name)) {
			return getUpdateFieldPairs();
		}
		else if ("updatefromfieldnames".equalsIgnoreCase(name)) {
			return getUpdateFromFieldNames();
		}
		else if ("inserttofieldnames".equalsIgnoreCase(name)) {
			return getInsertToFieldNames();
		}
		else if ("insertfromfieldnames".equalsIgnoreCase(name)) {
			return getInsertFromFieldNames();
		}
		else if ("filterfieldvalues".equalsIgnoreCase(name)) {
			return getFilterFieldValues();
		}
		else if ("keyfieldpairs".equalsIgnoreCase(name)) {
			return getKeyFieldPairs();
		}
		else {
			Variant value = datapool.getParameter(name);

			if (value.isNull()) {
				return null;
			}

			return value.getStringValue();
		}
	}

	private String getUpdateFieldPairs() {
		StringCreator result = new StringCreator(", ");

		List<IOMappingItemRuntime> runtimeList = ioItem.getUpdateMappingRuntime();
		String toTable = ioItem.getToName();
		String fromTable = ioItem.getFromName();

		for (IOMappingItemRuntime itemRuntime : runtimeList) {
			result.append(toTable + "." + itemRuntime.getToField() + " = " + fromTable + "." + itemRuntime.getFromField());
		}

		return result.ToString();
	}

	private String getUpdateFromFieldNames() {
		StringCreator result = new StringCreator(", ");

		List<IOMappingItemRuntime> runtimeList = ioItem.getUpdateMappingRuntime();

		for (IOMappingItemRuntime itemRuntime : runtimeList) {
			result.append(itemRuntime.getFromField());
		}

		return result.ToString();
	}

	private String getInsertFromFieldNames() {
		StringCreator result = new StringCreator(", ");

		IOMappingItemRuntimeList runtimeList = ioItem.getInsertMappingRuntime();

		for (IOMappingItemRuntime itemRuntime : runtimeList) {
			result.append(itemRuntime.getFromField());
		}

		return result.ToString();
	}

	private String getInsertToFieldNames() {
		StringCreator result = new StringCreator(", ");

		List<IOMappingItemRuntime> runtimeList = ioItem.getInsertMappingRuntime();

		for (IOMappingItemRuntime itemRuntime : runtimeList) {
			result.append(itemRuntime.getToField());
		}

		return result.ToString();
	}

	private String getFilterFieldValues() throws Exception {
		String[] filterFieldValues = ioItem.getFilterFieldValues();

		if (filterFieldValues == null || filterFieldValues.length == 0) {
			return "1=1";
		}

		StringCreator result = new StringCreator(" and ");

		for (String fieldvalue : filterFieldValues) {
			String fieldvaluePair = setParametersTo(fieldvalue);
			result.append(fieldvaluePair);
		}

		return result.ToString();
	}

	private String getKeyFieldPairs() throws Exception {
		String[] keyFields = ioItem.getKeyFieldPairs();

		// 1. if not define
		if (keyFields == null || keyFields.length == 0) {
			return ioItem.getFromName() + ".id = " + ioItem.getToName() + ".id";
		}

		// if define
		StringCreator result = new StringCreator(" and ");

		for (String fieldPair : keyFields) {
			String keyFieldPair = setParametersTo(fieldPair);
			result.append(keyFieldPair);
		}

		return result.ToString();
	}

	public String setParametersTo(String segment) throws Exception {
		if (segment == null) {
			return segment;
		}

		segment = segment.toLowerCase();
		if (fparamList == null) {
			fparamList = new ArrayList<String>();
			fparamList.add("totable");
			fparamList.add("fromtable");
		}
		for (String name : fparamList) {
			if (segment.indexOf(name) >= 0) {
				String value = getStringValue(name, null);

				if (value == null) {
					continue;
				}
				segment = segment.replace(name, value);
			}
		}

		return segment;
	}

}
