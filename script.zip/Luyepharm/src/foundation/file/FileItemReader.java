package foundation.file;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import foundation.fileupload.FileItem;
import foundation.fileupload.disk.DiskFileItemFactory;
import foundation.fileupload.servlet.ServletFileUpload;

import foundation.config.Configer;
import foundation.user.OnlineUser;

public class FileItemReader {

	private int MAX_CACHE_SIZE = 30 * 1024 * 1024;
	private int MAX_FILE_SIZE = 100 * 1024 * 1024;
	private File repository;

	public FileItemReader(OnlineUser onlineUser) {
		this.repository = new File(Configer.getPath_Upload(onlineUser.getName()));
	}

	@SuppressWarnings("unchecked")
	public List<FileItem> read(HttpServletRequest request) throws Exception {
		if (!repository.exists()) {
			repository.mkdirs();
		}

		DiskFileItemFactory diskFileFactory = new DiskFileItemFactory();
		diskFileFactory.setSizeThreshold(MAX_CACHE_SIZE);
		diskFileFactory.setRepository(repository);

		ServletFileUpload fileUpload = new ServletFileUpload(diskFileFactory);
		fileUpload.setSizeMax(MAX_FILE_SIZE);

		return fileUpload.parseRequest(request);
	}
}
