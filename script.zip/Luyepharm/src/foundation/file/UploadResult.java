package foundation.file;

public class UploadResult {

	private String filecode;
	private String path;
	private String tempPath;
	
	public UploadResult(String filecode) {
		this.filecode = filecode;
	}

	public String getFilecode() {
		return filecode;
	}

	public String getPath() {
		return path;
	}

	public String getTempPath() {
		return tempPath;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public void setTempPath(String tempPath) {
		this.tempPath = tempPath;
	}
	
}
