package foundation.file;

import java.util.List;

import foundation.fileupload.FileItem;
import org.apache.log4j.Logger;

import foundation.callable.Callable;
import foundation.file.download.DownloadRequest;
import foundation.file.download.FileExporter;
import foundation.util.Util;

public class FileCenter extends Callable {

	protected static Logger logger;
	protected static FileLockManager lockManager;

	static {
		logger = Logger.getLogger(FileCenter.class);
		lockManager = new FileLockManager();
	}

	@Override
	protected void publishMethod() {
		addMethod("upload");
		addMethod("download");
		addMethod("getProgress");
		addMethod("testHandler");
	}

	protected void upload() throws Exception {
		try {
			UploadRequest uploadRequest = new UploadRequest(onlineUser, paths, dataPool, response);
//			FileLock lock = getFileLock(uploadRequest);

			try {
//				if (lock == null) {
//					resultPool.setMessage("busy", "system is busy for upload [" + uploadRequest.getFileIOCode() + "]");
//					return;
//				}

				List<FileItem> fileItems = uploadRequest.getFileList();
				if (fileItems.isEmpty()) {
					resultPool.error("请选择上传文件");
					return;
				}

				FileReceiver receiver = new FileReceiver(resultPool);
				receiver.exec(uploadRequest);
			}
			catch (FileIoException e) {
				resultPool.error(e.getMessage());
			}
			catch (Exception e) {
				throw e;
			}
			finally {
//				lock.release();
			}
		}
		catch (FileRequestException e) {
			resultPool.error(e.getMessage());
		}
	}
	
	protected void testHandler() throws Exception {
		UploadRequest uploadRequest = new UploadRequest(onlineUser, paths, dataPool, response);
		FileReceiver receiver = new FileReceiver(resultPool);
		receiver.testHandler(uploadRequest);
	}
	
	protected void download() throws Exception {
		try {
			DownloadRequest downloadRequest = new DownloadRequest(onlineUser, paths, request, response);
			FileLock lock = getFileLock(downloadRequest);

			try {
				if (lock == null) {
					resultPool.setMessage("busy", "system is busy for download [" + downloadRequest.getFileIOCode() + "]");
					return;
				}

				fireReplay = false;
				FileExporter exporter = new FileExporter();
				exporter.exec(downloadRequest);
			}
			catch (Exception e) {
				throw e;
			}
			finally {
				lock.release();
			}
		}
		catch (FileRequestException e) {
			resultPool.error(e.getMessage());
		}
	}

	private FileLock getFileLock(FileRequest fileRequest) {
		Range range = fileRequest.getRange();
		String code = fileRequest.getFileIOCode();

		if (Range.OnlineUser == range) {
			return onlineUser.getFileLock(code);
		}
		else if (Range.Application == range) {
			return lockManager.getLock(code);
		}

		return null;
	}

	protected void getProgress() throws Exception {
		String code = request.getParameter("code");
		String type = request.getParameter("type");

		if (Util.isEmptyStr(code)) {
			resultPool.error("emptyValue", "empty value: code");
			return;
		}

		FileProgressor progress = onlineUser.getFileProgress(code);

		if (progress == null) {
			progress = lockManager.getFileProgress(code);
		}

		if (progress == null) {
			return;
		}

		if (type != null) {
			resultPool.addValue(progress.getProgress());
		}
		else {
			resultPool.addValue("progress", progress);
		}
	}

}
