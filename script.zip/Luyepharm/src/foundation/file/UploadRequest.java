package foundation.file;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import foundation.callable.DataPool;
import foundation.fileupload.FileItem;
import foundation.user.OnlineUser;

public class UploadRequest extends FileRequest {

	private List<FileItem> fileList;
	private UploadOperator operator;

	
	public UploadRequest(OnlineUser onlineUser, String paths[], DataPool dataPool, HttpServletResponse response) throws Exception {
		super(onlineUser, paths, dataPool, response);
		init(dataPool);
	}

	private void init(DataPool dataPool) throws Exception {
		operator = UploadOperator.valueOfString(dataPool.getParameter("operator").getStringValue()); // 默认toDB
		
		if (UploadOperator.Unknown == operator) {
			operator = UploadOperator.ToDBAndRepository;
		}
		
		loadFilesFromRequest();
	}

	private void loadFilesFromRequest() throws Exception {
		FileItemReader itemReader = new FileItemReader(onlineUser);
		fileList = itemReader.read(dataPool.getHttpRequest());
	}

	public List<FileItem> getFileList() throws Exception {
		if (fileList == null) {
			fileList = new ArrayList<FileItem>();
		}

		return fileList;
	}

	public UploadOperator getOperator() {
		return operator;
	}

	public HttpServletRequest getHttpRequest() {
		return dataPool.getHttpRequest();
	}

	
}
