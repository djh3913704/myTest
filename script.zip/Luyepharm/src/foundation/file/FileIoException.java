package foundation.file;

import org.apache.log4j.Logger;

import foundation.util.Util;

public class FileIoException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9169324954448420083L;
	private String message;
	private static Logger logger;
	
	static {
		logger = Logger.getLogger(FileIoException.class);
	}
	
	public  FileIoException() {}
	
	public  FileIoException(String msg) {
		logger.error("FileIoException :" + msg);
		this.message = msg;
	}
	
	public void  setMessage(String msg) {
		logger.error("FileIoException :" + msg);
		this.message = msg;
	}
	
	@Override
	public String getMessage() {
		
		if (Util.isEmptyStr(message)) {
			return super.getMessage();
		}
		else {
			return message;
		}
		
	}
}
