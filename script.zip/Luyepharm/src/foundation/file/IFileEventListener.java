package foundation.file;

import foundation.callable.DataPool;


public interface IFileEventListener {

	void onDataBaseEvent(String ioCode, String event, DataPool datapool) throws Exception;
	
	void onRepositoryEvent(String event, UploadResult result, DataPool datapool) throws Exception;
	
}
