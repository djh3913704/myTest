package foundation.file;

import java.io.File;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.http.HttpStatus;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import foundation.callable.DataPool;
import foundation.callable.ResultPool;
import foundation.config.Configer;
import foundation.file.processor.FileIO;
import foundation.file.processor.FileIOContainer;
import foundation.file.processor.FileIOItem;
import foundation.fileupload.FileItem;
import foundation.util.Util;
import foundation.variant.VariantRequestParams;

public class FileReceiver {

	private static String URL_WebMan = "";
	private static RepositoryContainer repositoryContainer;
	private UploadRequest request;
	private FileProgressor progressor;
	private ResultPool resultPool;

	static {
		repositoryContainer = RepositoryContainer.getInstance();
		URL_WebMan = Configer.getParam("URL_WebMan");
	}
	
	public FileReceiver(ResultPool resultPool) {
		this.resultPool = resultPool;
		this.progressor = new FileProgressor();
	}
	
	public void exec(UploadRequest request) throws Exception {
		this.request = request;
		doExec();
	}
	
	public void doExec() throws Exception {
		progressor.newTask("上传文件");
		/*try {*/
			List<FileItem> fileList = request.getFileList();
			UploadOperator operator = request.getOperator();

			if (UploadOperator.ToRepository == operator) {
				progressor.newPhase("toRepository", "保存文件到文档库");
				saveFilesToRepository(fileList);
				progressor.endPhase();
			}
			else if (UploadOperator.ToDB == operator) {
				progressor.newPhase("toDB", "保存文件到数据库");
				saveFilesToDB(fileList);
				progressor.endPhase();
			}
			else if (UploadOperator.ToDBAndRepository == operator) {
				progressor.newPhase("toDB", "保存文件到数据库");
				saveFilesToDB(fileList);
				progressor.endPhase();

				progressor.newPhase("toRepository", "保存文件到文档库");
				saveFilesToRepository(fileList);
				progressor.endPhase();
			}
			/*}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
		finally {
			progressor.endTask();
		}*/
	}

	public void testHandler(UploadRequest request) throws Exception {
//		String iocode = request.getFileIOCode();
//		List<FileIO> fileIOList = fileIOContainer.get(iocode);
//		DataPool datapool = request.getDataPool();
//		
//		EventListener.fireDataBaseEvent(iocode, "beforeSave", fileIOList, datapool);
//		EventListener.fireDataBaseEvent(iocode, "afterSave", fileIOList, datapool);		
	}
	
	private void saveFilesToRepository(List<FileItem> fileList) throws Exception {
		String name = request.getRepository();
		Repository repository = repositoryContainer.get(name);
		
		if (repository == null) {
			repository = repositoryContainer.getDefault();
		}
		
		if (repository == null) {
			resultPool.error("save file error: can not find repository " + name);
			return;
		}
		
		VariantRequestParams params = new VariantRequestParams(request.getHttpRequest());
		String result = repository.saveFileToAttachmentPath(fileList, params);
		resultPool.addValue("path", result);
	}

	private void saveFilesToDB(List<FileItem> fileList) throws Exception {
		VariantRequestParams params = new VariantRequestParams(request.getHttpRequest());
		
		String name = request.getRepository();
		Repository repository = repositoryContainer.get(name);
		DataPool datapool = request.getDataPool();
		
		if (repository == null) {
			repository = repositoryContainer.getDefault();
		}
		
		if (repository == null) {
			resultPool.error("save file error: can not find repository " + name);
			return;
		}
		
		String iocode = request.getFileIOCode();
		FileIO fileIOList = FileIOContainer.get(iocode);
	    List<FileIOItem> fileIoItems = fileIOList.getItemList(FileIOItem.TypeCode_DB);
	      for (FileIOItem item : fileIoItems) {
              FileIOContext context = (FileIOContext)(item.createContext(datapool));
              item.createMappingRuntime(context);
          }
		
		//1. save to disc	
		List<UploadResult> resultList = repository.saveFile(fileList, params);	
		
		//2. before save event
		EventListener.fireDataBaseEvent(iocode, "beforeSave", fileIoItems, datapool);
		
		//3. save to database from web man
		for (UploadResult result: resultList) {
			saveOneFileToDB(result, iocode);
			if (datapool.getParameter("repository").getStringValue().equals("db")) {
				String filePath = result.getPath();
			
				File file = new File(filePath);
				if (file.exists()) {
					FileUtils.deleteDirectory(file);
					file.delete();
					progressor.newPhase(iocode, "删除文件夹：" + filePath);
				}
			}
		}
		
		//4. execute handler
		EventListener.fireDataBaseEvent(iocode, "afterSave", fileIoItems, datapool);
	}

	private void saveOneFileToDB(UploadResult result, String iocode) throws Exception {
		try {
			HttpClient httpclient = HttpClients.createDefault();
			
			String url = Util.joinPath(URL_WebMan, "NewUpload?code=" + iocode + "&filespath=" + result.getTempPath());
			HttpGet httpget = new HttpGet(url);
			
			HttpResponse httpResponse = httpclient.execute(httpget);
			StatusLine statusLine = httpResponse.getStatusLine();
			
	 		if (statusLine.getStatusCode() == HttpStatus.OK.value()) {
			  String strResult = EntityUtils.toString(httpResponse.getEntity());  
			  JsonObject returnData = new JsonParser().parse(strResult).getAsJsonObject();
			  JsonElement jsonElement = returnData.get("Success");

			  System.out.println("//TDDO 上载结果解析");
			 
			  boolean success = jsonElement.getAsBoolean();
			  
			  if (!success) {
				  JsonObject error = returnData.get("Error").getAsJsonObject();
				  JsonElement message= error.get("Message");
				  throw new Exception("web man upload error: " + message);
			  }
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	public UploadRequest getRequest(){
		return request;
	}
	
	public FileProgressor getProgressor(){
		return progressor;
	}
	
	public ResultPool getResultPool(){
		return resultPool;
	}

}
