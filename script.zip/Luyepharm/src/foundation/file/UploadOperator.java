package foundation.file;


public enum UploadOperator {

	ToDB, ToRepository, ToDBAndRepository, Unknown;

	public static UploadOperator valueOfString(String value) {
		if ("ToDB".equalsIgnoreCase(value)) {
			return ToDB;
		}
		else if ("ToRepository".equalsIgnoreCase(value)) {
			return ToRepository;
		}
		else if ("ToDBAndRepository".equalsIgnoreCase(value)) {
			return ToDBAndRepository;
		}
		else {
			return Unknown;
		}
	}
}
