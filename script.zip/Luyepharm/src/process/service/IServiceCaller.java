package process.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import foundation.callable.ResultPool;
import foundation.data.Variant;
import foundation.user.OnlineUser;

public interface IServiceCaller {

	OnlineUser getOnlineUser();

	Variant getParameter(String string);

	HttpServletRequest getRequest();

	HttpServletResponse getResponse();
	
	ResultPool getResultPool();

	void error(String error);

	String[] getPaths();

}
