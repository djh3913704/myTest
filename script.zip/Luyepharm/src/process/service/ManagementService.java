package process.service;


public class ManagementService extends Service {

	public ManagementService(IServiceCaller serviceCaller) throws Exception {
		super(serviceCaller);
	}

	@Override
	public void call(String operator) {
		
	}
	
}
