package process.service.writer;

import org.activiti.engine.runtime.ProcessInstance;

import foundation.callable.EnvelopWriter;
import foundation.callable.IBeanWriter;

public class ProcessInstanceWriter implements IBeanWriter {

	private ProcessInstance bean;
	
	public ProcessInstanceWriter() {
		
	}
	
	@Override
	public void write(EnvelopWriter writer) {
		writer.beginObject();
		
		try {
			writer.writeString("id", bean.getId());
			writer.writeString("name", bean.getName());
		}
		finally {
			writer.endObject();
		}
	}

	@Override
	public void setBean(Object bean) {
		this.bean = (ProcessInstance) bean;
	}

}
