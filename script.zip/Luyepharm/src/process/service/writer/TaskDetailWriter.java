package process.service.writer;

import java.util.Map;
import foundation.callable.EnvelopWriter;
import foundation.callable.IBeanWriter;
import foundation.data.Entity;

public class TaskDetailWriter implements IBeanWriter {


	
	private Object[] bean;

	public TaskDetailWriter() {
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void write(EnvelopWriter writer) {
		writer.beginObject();
		
		try {
			writer.writeObject((Map<String, Object>)bean[1]);
			writer.writeEntity("tasks", (Entity)bean[0]);
			
		}
		finally {
			writer.endObject();
		}
	}

	@Override
	public void setBean(Object bean) {
		this. bean = (Object[])bean;
	}

}
