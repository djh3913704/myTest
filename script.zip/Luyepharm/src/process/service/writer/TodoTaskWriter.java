package process.service.writer;

import java.util.Map;

import foundation.callable.EnvelopWriter;
import foundation.callable.IBeanWriter;

public class TodoTaskWriter implements IBeanWriter {


	
	private Map<String, String> bean;

	public TodoTaskWriter() {
		
	}
	
	@Override
	public void write(EnvelopWriter writer) {
		writer.beginObject();
			
		try {
			if (bean == null) {
				return;
			}
			writer.writeString("id", bean.get("id"));
			writer.writeString("status", bean.get("status"));
			writer.writeString("name", bean.get("name"));
			writer.writeString("pdname", bean.get("pdname"));
			writer.writeString("pdversion", bean.get("pdversion"));
			writer.writeString("pid", bean.get("pid"));
			writer.writeString("createTime", bean.get("createTime"));
			writer.writeString("sid", bean.get("sid"));
			if (bean.containsKey("isSuspension")) {
				writer.writeString("isSuspension", bean.get("isSuspension"));
			}
			writer.writeString("isSuspension", "false");
		}
		finally {
			writer.endObject();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void setBean(Object bean) {
		this. bean = (Map<String, String>)bean;
	}

}
