package process.service.writer;

import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.Model;
import org.activiti.engine.repository.ProcessDefinition;

import foundation.callable.EnvelopWriter;
import foundation.callable.IBeanWriter;

public class ModelWriter implements IBeanWriter {
	
	private Object[] bean;
	

	public ModelWriter() {
		
	}
	
	@Override
	public void write(EnvelopWriter writer) {
		writer.beginObject();
		
		try {
			Model model = (Model)bean[0];
			Deployment deployment = (Deployment)bean[1];
			ProcessDefinition prodef = (ProcessDefinition)bean[2];
			//1.
			if (model != null) {
				writer.writeString("id", model.getId());
				writer.writeString("category", model.getCategory());
				writer.writeInteger("version", model.getVersion());
				writer.writeDate("createTime", model.getCreateTime());
				writer.writeDate("lastUpdateTime", model.getLastUpdateTime());	
				writer.writeString("description", model.getMetaInfo());
			}
			
			//2.
			if (deployment != null) {
				writer.writeString("isDeploymented", "true");
				writer.writeDate("deploymentTime", deployment.getDeploymentTime());
			}else {
				writer.writeString("isDeploymented", "false");
				writer.writeString("deploymentTime", "未部署");
			}
			//3.
			if (prodef != null) {
				writer.writeString("isSuspension", String.valueOf(prodef.isSuspended()));
				writer.writeString("name", prodef.getName());
				
			}else {
				writer.writeString("isSuspension", "false");
				writer.writeString("name", model.getName());
			}
				
		}
		finally {
			writer.endObject();
		}
	}

	@Override
	public void setBean(Object bean) {
		this.bean = (Object[]) bean;
	}

}
