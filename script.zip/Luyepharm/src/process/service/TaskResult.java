package process.service;

import java.util.HashMap;
import java.util.Map;

public class TaskResult {

	private boolean pass;
	private String reason;
	
	
	public TaskResult() {
		pass = false;
		reason = "未知原因";
	}
	
	public boolean isPass() {
		return pass;
	}

	public void setPass(boolean pass) {
		this.pass = pass;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Map<String, Object> getVariables() {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("passflag", pass);
		result.put("reason", reason);
		
		return result;
	}

}
