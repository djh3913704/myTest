package process.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import oracle.net.aso.l;

import org.activiti.bpmn.model.BpmnModel;
import org.activiti.editor.language.json.converter.BpmnJsonConverter;
import org.activiti.engine.HistoryService;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.impl.RepositoryServiceImpl;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.pvm.PvmTransition;
import org.activiti.engine.impl.pvm.ReadOnlyProcessDefinition;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.activiti.engine.repository.Model;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.runtime.ProcessInstanceQuery;
import org.activiti.engine.task.Task;
import org.activiti.image.ProcessDiagramGenerator;
import org.springframework.util.Assert;

import process.service.writer.ProcessInstanceWriter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import foundation.data.Variant;
import foundation.util.Util;


public class RuntimeService extends Service {

	private org.activiti.engine.RuntimeService service;
	private org.activiti.engine.RepositoryService repositoryService;
	private TaskService taskService;
	private HistoryService historyService;
	
	public RuntimeService(IServiceCaller serviceCaller) throws Exception {
		super(serviceCaller);
		service = processEngine.getRuntimeService();
		repositoryService = processEngine.getRepositoryService();
		taskService = processEngine.getTaskService();
		historyService = processEngine.getHistoryService();
		
	}

	@Override
	public void call(String operator) throws Exception {
		if ("getList".equalsIgnoreCase(operator)) {
			getList();
		}		
		else if ("startProcess".equalsIgnoreCase(operator)) {
			startProcess();
		}
		else if ("suspendProcess".equalsIgnoreCase(operator)) {
			suspendProcess();
		}
		else if ("activateProcess".equalsIgnoreCase(operator)) {
			activateProcess();
		}
		else if ("getDiagram".equalsIgnoreCase(operator)) {
			getDiagram();
		}
		else if ("getActivitiProccessImage".equalsIgnoreCase(operator)) {
			getActivitiProccessImage();
		}
		
	}

	private void getList() {
		ProcessInstanceQuery query = service.createProcessInstanceQuery();
		List<ProcessInstance> instanceList = query.list();
		resultPool.addValue(null, instanceList, new ProcessInstanceWriter());
	}

	private void startProcess() {
		String processId = getProcessId();
		ProcessInstance process = service.startProcessInstanceById(processId);
	}
	
	private void suspendProcess() {
		String processId = getProcessId();
		service.suspendProcessInstanceById(processId);
	}
	
	private void activateProcess() {
		String processId = getProcessId();
		service.activateProcessInstanceById(processId);
	}
	
	private void getDiagram() throws IOException {
		Variant processId = serviceCaller.getParameter("workflowId");
		
		Task task = taskService.createTaskQuery().processInstanceId(processId.getStringValue()).singleResult();
		if (task ==null) {
			return ;
		}
		ProcessDefinition singleResult = repositoryService.createProcessDefinitionQuery().processDefinitionId(task.getProcessDefinitionId()).singleResult();
		Model model = repositoryService.createModelQuery().deploymentId(singleResult.getDeploymentId()).singleResult();
		JsonNode editorNode = new ObjectMapper().readTree(repositoryService.getModelEditorSource(model.getId()));
	    BpmnJsonConverter jsonConverter = new BpmnJsonConverter();
	    BpmnModel bpmnModel = jsonConverter.convertToBpmnModel(editorNode);
	    List<String> activeActivityIds = service.getActiveActivityIds(task.getExecutionId());
	    ProcessEngineConfiguration engineConfiguration = processEngine.getProcessEngineConfiguration();
	    ProcessDiagramGenerator diagramGenerator = engineConfiguration.getProcessDiagramGenerator();
	    InputStream resource = diagramGenerator.generateDiagram(bpmnModel, "png",activeActivityIds,activeActivityIds, "宋体","宋体" ,null, 0);
	    
	    try {
	    	HttpServletResponse response = serviceCaller.getResponse(); 
	    	response.setHeader("Content-Type", "image/png");
		    OutputStream outputStream = response.getOutputStream();
		    byte[] b = new byte[1024];
	        int len;
	        while ((len = resource.read(b, 0, 1024)) != -1) {
	            outputStream.write(b, 0, len);
	        }
	    }
	    finally {
	    	resource.close();
	    }
	}
	
	public void getActivitiProccessImage() {
		try {
			Variant processId = serviceCaller.getParameter("workflowId");
			String pProcessInstanceId = processId.getStringValue();
			
			if (Util.isEmptyStr(pProcessInstanceId)) {
				return;
			}
			
			List<HistoricProcessInstance> list = historyService.createHistoricProcessInstanceQuery().processInstanceId(pProcessInstanceId).list();
			if (list.size() == 0) {
				return;
			}
			HistoricProcessInstance processInstance = list.get(0);

			if (processInstance != null) {
	            ProcessDefinitionEntity processDefinition = (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService)
	            		.getDeployedProcessDefinition(processInstance.getProcessDefinitionId());
	            List<HistoricActivityInstance> historicActivityInstanceList = historyService.createHistoricActivityInstanceQuery()
	                    .processInstanceId(pProcessInstanceId).orderByHistoricActivityInstanceId().asc().list();
	            List<String> executedActivityIdList = new ArrayList<String>();
	            int index = 1;
	            
	            for (HistoricActivityInstance activityInstance : historicActivityInstanceList) {
	                executedActivityIdList.add(activityInstance.getActivityId());                
	                index++;
	            }
	            
	            List<String> flowIds = new ArrayList<String>();
	            flowIds = getHighLightedFlows(processDefinition, historicActivityInstanceList);
	            BpmnModel bpmnModel = repositoryService
	                    .getBpmnModel(processInstance.getProcessDefinitionId());
//	            ProcessDiagramGenerator pec = processEngine.getProcessEngineConfiguration().getProcessDiagramGenerator();
	            process.canvas.ProcessDiagramGenerator pec = new process.canvas.ProcessDiagramGenerator();
	            
	            InputStream imageStream = pec.generateDiagram(bpmnModel, "png", executedActivityIdList, flowIds,"宋体","微软雅黑",null,2.0);
	            HttpServletResponse response = serviceCaller.getResponse();
	            response.setContentType("image/png");
	            OutputStream os = response.getOutputStream();
	            int bytesRead = 0;
	            byte[] buffer = new byte[1024*8];
	            
	            while ((bytesRead = imageStream.read(buffer, 0, 1024*8)) != -1) {
	                os.write(buffer, 0, bytesRead);
	            }
	            os.close();
	            imageStream.close();
	        }        
	    } 
		catch (Exception e) {  
	    	e.printStackTrace();
	    }
	}
	
	public List<String> getHighLightedFlows(ProcessDefinitionEntity processDefinitionEntity,List<HistoricActivityInstance> historicActivityInstances) { 
		List<String> highFlows = new ArrayList<String>();  
		
		for (int i = 0; i < historicActivityInstances.size() - 1; i++) {
		    ActivityImpl activityImpl = processDefinitionEntity.findActivity(historicActivityInstances.get(i).getActivityId());     
		    List<ActivityImpl> sameStartTimeNodes = new ArrayList<ActivityImpl>();    
		    ActivityImpl sameActivityImpl1 = processDefinitionEntity.findActivity(historicActivityInstances.get(i + 1).getActivityId());
	        sameStartTimeNodes.add(sameActivityImpl1); 
	        
	        for (int j = i + 1; j < historicActivityInstances.size() - 1; j++) {        
	    		HistoricActivityInstance activityImpl1 = historicActivityInstances.get(j);       
	    		HistoricActivityInstance activityImpl2 = historicActivityInstances.get(j + 1);       
	    		if (activityImpl1.getStartTime().equals(activityImpl2.getStartTime())) {
	    			ActivityImpl sameActivityImpl2 = processDefinitionEntity.findActivity(activityImpl2.getActivityId());           
	    			sameStartTimeNodes.add(sameActivityImpl2);           
	    		} 
	    		else {          
	    			break;          
	    		}   
	        }       
	        List<PvmTransition> pvmTransitions = activityImpl.getOutgoingTransitions(); 
	        
	        for (PvmTransition pvmTransition : pvmTransitions) {
	        	ActivityImpl pvmActivityImpl = (ActivityImpl) pvmTransition.getDestination();      
	        	if (sameStartTimeNodes.contains(pvmActivityImpl)) {               
	        		highFlows.add(pvmTransition.getId());           
	        	}        
	        }    
		}    
		return highFlows;
	}
	private ActivityImpl getCurrentAcitivity(String processDefinitionId) {
		Execution execution = service.createExecutionQuery().processDefinitionId(processDefinitionId).singleResult();  
		String activityId = execution.getActivityId();  
		ActivityImpl currentActivity = queryTargetActivity(activityId);  
		logger.debug(currentActivity.getId()+""+currentActivity.getProperty("name"));  
		return currentActivity;  
	}

	 public ActivityImpl  queryTargetActivity(String id){  
	    ReadOnlyProcessDefinition deployedProcessDefinition = (ProcessDefinitionEntity)((RepositoryServiceImpl)repositoryService).getDeployedProcessDefinition("ziyouliu:1:4");  
	    @SuppressWarnings("unchecked")
	    
		List<ActivityImpl> activities = (List<ActivityImpl>) deployedProcessDefinition.getActivities();  
	    for (ActivityImpl activityImpl : activities) {  
	        if(activityImpl.getId().equals(id)){  
	            return activityImpl;  
	        }  
	     }  
	    return null;  
	 }  

}
