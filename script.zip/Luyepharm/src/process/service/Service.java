package process.service;


import java.util.Map;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.activiti.engine.TaskService;
import org.activiti.engine.task.Task;
import org.apache.log4j.Logger;

import foundation.callable.ResultPool;
import foundation.data.Variant;

public abstract class Service {
	
	protected static Logger logger;
	
	protected IServiceCaller serviceCaller;
	protected ResultPool resultPool;
	protected ProcessEngine processEngine;
	protected String[] paths;
	
	static {
		logger = Logger.getLogger(Service.class);
	}
	
	
	public Service(IServiceCaller serviceCaller) throws Exception {
		processEngine = ProcessEngines.getDefaultProcessEngine();
		
		this.serviceCaller = serviceCaller;
		this.resultPool = serviceCaller.getResultPool();
		this.paths = serviceCaller.getPaths();
	}
	
	abstract public void call(String operator) throws Exception ;
	
	protected String getProcessId() {
		Variant processId = serviceCaller.getParameter("workflowId");
		
		if (processId.isEmpty()) {
			error("empty processId");
		}
		
		return processId.getStringValue();
	}
	
	protected Task getTask(String processId) {
		TaskService taskService = processEngine.getTaskService();
		Task task = taskService.createTaskQuery().processInstanceId(processId).singleResult();
		return task;
	}
	
	public Map<String, Object> getTaskVariables(String processId) {
		TaskService taskService = processEngine.getTaskService();
		Task task = taskService.createTaskQuery().processInstanceId(processId).singleResult();
		Map<String, Object> variables = taskService.getVariables(task.getId());
		return variables;
	}
	
	protected void error(String error) {
		serviceCaller.error(error);
		logger.error(error);
	}
}
