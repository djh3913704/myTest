package process.service;

import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.activiti.bpmn.converter.BpmnXMLConverter;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.editor.language.json.converter.BpmnJsonConverter;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.Model;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.task.Task;
import org.apache.commons.io.IOUtils;

import process.service.writer.TaskDetailWriter;
import process.service.writer.TodoTaskWriter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import foundation.data.Entity;
import foundation.data.Variant;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.user.OnlineUser;
import foundation.util.Util;

public class TaskService extends Service {

	private org.activiti.engine.TaskService taskService;
	private RepositoryService repositoryService;
	private OnlineUser onlineUser;
	private HistoryService historyService;
	
	
	public TaskService(IServiceCaller serviceCaller) throws Exception {
		super(serviceCaller);
		
		repositoryService = processEngine.getRepositoryService();
		taskService = processEngine.getTaskService();
		historyService = processEngine.getHistoryService();
	}

	@Override
	public void call(String operator) throws Exception {
		onlineUser = serviceCaller.getOnlineUser();
		
		if (onlineUser == null) {
			error(" user is empty");
			return;
		}		
		
		if ("getTodoTask".equalsIgnoreCase(operator)) {
			getTodoTask();
		}
		else if ("claimTask".equalsIgnoreCase(operator)) {
			claimTask();
		}
		else if ("completeTask".equalsIgnoreCase(operator)) {
			completeTask();
		}
		else if ("getAllTask".equalsIgnoreCase(operator)) {
			getAllTask();
		}
		else if ("getTaskDetail".equalsIgnoreCase(operator)) {
			getTaskDetail();
		}
		else if ("getModelXml".equalsIgnoreCase(operator)) {
			getModelXml();
		}
		
		
	}

	public boolean setOtherVariables(Map<String, Object> variables) {
		try {
			String processId = getProcessId();
			Task task = getTask(processId);
			taskService.setVariables(task.getId(), variables);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

	public void getModelXml() throws Exception {
		Variant taskId = serviceCaller.getParameter("taskId");
		Task task = getTask(taskId.getStringValue());
		String processDefinitionId = task.getProcessDefinitionId();
		
		ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();
		Deployment deployment = repositoryService.createDeploymentQuery().deploymentId(processDefinition.getDeploymentId()).singleResult();
		Model model = repositoryService.createModelQuery().deploymentId(deployment.getId()).singleResult();
		BpmnJsonConverter jsonConverter = new BpmnJsonConverter();
        JsonNode editorNode = new ObjectMapper().readTree(repositoryService.getModelEditorSource(model.getId()));
        BpmnModel bpmnModel = jsonConverter.convertToBpmnModel(editorNode);
        BpmnXMLConverter xmlConverter = new BpmnXMLConverter();
        byte[] bpmnBytes = xmlConverter.convertToXML(bpmnModel);

        HttpServletResponse response = serviceCaller.getResponse();
        
        ByteArrayInputStream in = new ByteArrayInputStream(bpmnBytes);
        IOUtils.copy(in, response.getOutputStream());
        String filename = bpmnModel.getMainProcess().getId() + ".bpmn20.xml";
        response.setHeader("Content-Disposition", "attachment; filename=" + filename);
        response.flushBuffer();
	}

	public void getTaskDetail() throws Exception {
		Variant taskId = serviceCaller.getParameter("taskId");
		Task task = getTask(taskId.getStringValue());
		Map<String, Object> variables = taskService.getVariables(task.getId());
		
		NamedSQL namedSQL = NamedSQL.getInstance("getTaskDetail");
		namedSQL.setParam("taskid", task.getId());
		Entity entity = SQLRunner.getEntity(namedSQL);
		
		resultPool.addValue("detail", new Object[]{entity, variables},new TaskDetailWriter());
	}

	public void getAllTask() {
		 List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		 List<Task> list = taskService.createTaskQuery().list();
		 
		 for (Task task : list) {
			 String processDefinitionId = task.getProcessDefinitionId();
			 ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();
			
			 Map<String, String> singleTask = packageTaskInfo( task, processDefinition);
//			 singleTask.put("status", "待办理");
			 result.add(singleTask);
		}
		 
		if (result.isEmpty()) {
			resultPool.addValue("no all task");
		}
		else {
			resultPool.addValue("allTask", result, new TodoTaskWriter());
		}
	}

	public String claimTask() {
		String workflowId = serviceCaller.getParameter("workflowId").getStringValue();
		return claimTask(workflowId);
	}
	
	public String claimTask(String workflowId) {
		Task task = getTask(workflowId);
		
		onlineUser = serviceCaller.getOnlineUser();
		resultPool = serviceCaller.getResultPool();
		
		try {
			taskService.claim(task.getId(), onlineUser.getId());
			resultPool.setMessage("Task is claimed");
			return task.getId();
		}
		catch (Exception e) {
			return null;
		}
	}
	
	public boolean completeTask() {
		Variant taskId = serviceCaller.getParameter("taskId");
		Variant passFlag = serviceCaller.getParameter("passFlag");
		Variant reason = serviceCaller.getParameter("reason");
		
		return completeTask(taskId.getStringValue(), passFlag.getStringValue(), reason.getStringValue());
	}
	
	public boolean completeTask(String taskId, String pass, String reason, Map<String,Object> other) {
		Map<String, Object> variables = new LinkedHashMap<String, Object>();
		if(other != null){
			Set<String> keySet = other.keySet();
			for (String key : keySet) {
				variables.put(key, other.get(key));
			}
		}
		variables.put("passflag", pass);
		variables.put("reason", reason);
		try {
			taskService.setVariables(taskId, variables);
			taskService.complete(taskId,variables);
			resultPool.success();
			
			return true;
		} 
		catch (Exception e) {
			e.printStackTrace();
			resultPool.error("办理任务失败： " + e.getMessage());
			logger.debug("can not complete task(" + taskId + "): " + e.getMessage());
			return false;
		}
	}	
	
	public boolean completeTask(String taskId, String pass, String reason) {
		Object variable = taskService.getVariable(taskId, "AggrementExaminer");
		Map<String, Object> variables = new LinkedHashMap<String, Object>();
		
		variables.put("passflag", pass);
		variables.put("reason", reason);
		try {
			taskService.setVariables(taskId, variables);
			taskService.complete(taskId,variables);
			resultPool.success();
			
			return true;
		} 
		catch (Exception e) {
			e.printStackTrace();
			resultPool.error("办理任务失败： " + e.getMessage());
			logger.debug("can not complete task(" + taskId + "): " + e.getMessage());
			return false;
		}
	}	
	
	public List<String> getTodoTask() {
		List<String> result = new ArrayList<String>();
		if (onlineUser == null) {
			onlineUser = serviceCaller.getOnlineUser();
		}
		List<Task> list = taskService.createTaskQuery().taskAssignee(onlineUser.getId()).active().list();
		 
		for (Task task : list) {
			String processInstanceId = task.getProcessInstanceId();
			HistoricProcessInstance processInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
			String businessKey = processInstance.getBusinessKey();
			result.add(businessKey);
		}
		
		List<Task> toClaimList = taskService.createTaskQuery().taskCandidateUser(onlineUser.getId()).active().list();
		
		for (Task task : toClaimList) {
			String processInstanceId = task.getProcessInstanceId();
			HistoricProcessInstance processInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
			String businessKey = processInstance.getBusinessKey();
			result.add(businessKey);
		}
		return result;
	}
	
    private Map<String, String> packageTaskInfo(Task task, ProcessDefinition processDefinition) {
        Map<String, String> singleTask = new HashMap<String, String>();
        Map<String,Object> taskVariables = taskService.getVariables(task.getId());
        singleTask.put("sid", (String)taskVariables.get("applyUserId"));
        singleTask.put("id", task.getId());
        singleTask.put("name", task.getName());
        singleTask.put("isSuspension", String.valueOf(task.isSuspended()));
        singleTask.put("createTime", new SimpleDateFormat("yyyy-MM-dd hh:mm").format(task.getCreateTime()));
        singleTask.put("pdname", processDefinition.getName());
        singleTask.put("pdversion", Integer.toString(processDefinition.getVersion()));
        singleTask.put("pid", task.getProcessInstanceId());
        return singleTask;
    }
    
    public Task gettaskByprocessId(String proInsId) {
		if(Util.isEmptyStr(proInsId)){
			return null;
		}
		
		Task task = taskService.createTaskQuery().processInstanceId(proInsId).singleResult();
		
		return task;
	}
    
    public Task geTask() {
    	Variant processId = serviceCaller.getParameter("workflowId");
    	Task task = taskService.createTaskQuery().processInstanceId(processId.getStringValue()).singleResult();
    	return task;
	}
}
