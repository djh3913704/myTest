package process.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.repository.Model;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;

import foundation.data.EntitySet;
import foundation.data.Variant;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.user.OnlineUser;
import foundation.util.Util;

public class IdentityService extends Service {

	private org.activiti.engine.IdentityService identityService;
	private RuntimeService runtimeService;
	private RepositoryService repositoryService;
	
	
	public IdentityService(IServiceCaller serviceCaller) throws Exception {
		super(serviceCaller);
		
		identityService = processEngine.getIdentityService();
		runtimeService = processEngine.getRuntimeService();
		repositoryService = processEngine.getRepositoryService();
	}

	@Override
	public void call(String operator) throws Exception {
		if ("startProcess".equalsIgnoreCase(operator)) {
			startProcess();
		}	
	}

	public String startProcess() throws Exception {
		Variant dataId = serviceCaller.getParameter("id");
		Variant typecode = serviceCaller.getParameter("typecode");
		
		return startProcess(dataId.getStringValue(), typecode.getStringValue());
	}
	
	public String startProcess(String dataId, String typecode) throws Exception {
		OnlineUser user = serviceCaller.getOnlineUser();
		if (user == null) {
			error(" user is null");
			return "";
		}
		
		ProcessInstance processInstance = null;
        try {
        	Map<String, Object> variables = new HashMap<String, Object>();
        	
        	// add workflowstall
        	String workflowStall = serviceCaller.getParameter("workflowstall").getStringValue();
        	
        	if (Util.isEmptyStr(workflowStall)) {
				workflowStall = "1";
			}
        	
        	int workflowStallInt = Integer.parseInt(workflowStall);
        	variables.put("workflowstall", workflowStallInt);
        	
        	identityService.setAuthenticatedUserId(user.getId());

            //get max version processDefinition
            List<Model> modelList = repositoryService.createModelQuery().modelKey(typecode).orderByModelVersion().desc().list();
            ProcessDefinition processDefinition = null;
            
            for (Model model : modelList) {
				if (processDefinition == null && model.getDeploymentId() != null) {
					String deploymentId = model.getDeploymentId();
					processDefinition = repositoryService.createProcessDefinitionQuery().deploymentId(deploymentId).singleResult();
				}
			}
            
            processInstance = runtimeService.startProcessInstanceById(processDefinition.getId(), dataId, variables);

            String processInstanceId = processInstance.getId();
            
            NamedSQL updateActinstUserSql = NamedSQL.getInstance("updateActinstUser");
            updateActinstUserSql.setParam("userid", user.getId());
            updateActinstUserSql.setParam("id", processInstanceId);
            SQLRunner.execSQL(updateActinstUserSql);
            
            return processInstanceId;
           
    	}
    	finally {
    		identityService.setAuthenticatedUserId(null);
    	}
	}
	
	public String startProcess(String dataId, String typecode, HashMap<String, Object> variables) throws Exception {
		OnlineUser user = serviceCaller.getOnlineUser();
		if (user == null) {
			error(" user is null");
			return "";
		}
		
		ProcessInstance processInstance = null;
		try {
			String workflowStall = (String) variables.get("workflowstall");
			
			if (Util.isEmptyStr(workflowStall)) {
				// add workflowstall
				workflowStall = serviceCaller.getParameter("workflowstall").getStringValue();
				
				if (Util.isEmptyStr(workflowStall)) {
					workflowStall = "1";
				}
				
				int workflowStallInt = Integer.parseInt(workflowStall);
				variables.put("workflowstall", workflowStallInt);
			}
			
			identityService.setAuthenticatedUserId(user.getId());
			
			//get max version processDefinition
			List<Model> modelList = repositoryService.createModelQuery().modelKey(typecode).orderByModelVersion().desc().list();
			ProcessDefinition processDefinition = null;
			
			for (Model model : modelList) {
				if (processDefinition == null && model.getDeploymentId() != null) {
					String deploymentId = model.getDeploymentId();
					processDefinition = repositoryService.createProcessDefinitionQuery().deploymentId(deploymentId).singleResult();
				}
			}
			
			processInstance = runtimeService.startProcessInstanceById(processDefinition.getId(), dataId, variables);
			
			String processInstanceId = processInstance.getId();
			
			NamedSQL updateActinstUserSql = NamedSQL.getInstance("updateActinstUser");
			updateActinstUserSql.setParam("userid", user.getId());
			updateActinstUserSql.setParam("id", processInstanceId);
			SQLRunner.execSQL(updateActinstUserSql);
			
			return processInstanceId;
			
		}
		finally {
			identityService.setAuthenticatedUserId(null);
		}
	}
	
	
}
