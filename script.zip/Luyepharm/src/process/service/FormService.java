package process.service;

import java.util.LinkedHashMap;
import java.util.Map;

import foundation.data.Entity;
import foundation.data.Variant;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;

public class FormService extends Service {

	public FormService(IServiceCaller serviceCaller) throws Exception {
		super(serviceCaller);
	}

	@Override
	public void call(String operator) throws Exception {
		if ("getProcessFromType".equalsIgnoreCase(operator)) {
			getProcessFromType();
		}
	}

	private void getProcessFromType() throws Exception {
		Map<String, String> formTypes = new LinkedHashMap<String, String>();
		
		Variant modelId = serviceCaller.getParameter("modelid");
		NamedSQL namedSQL = NamedSQL.getInstance("getfrommodelmapping");
		namedSQL.setParam("field", "modelid");
		namedSQL.setParam("value", modelId.getStringValue());
		Entity entity = SQLRunner.getEntity(namedSQL);
		String tableName = entity.getString("formname");
		String formDispaly = entity.getString("formdisplay");	
		formTypes.put("tablename", tableName);
		formTypes.put("fromname", formDispaly);
		
		resultPool.addValue(formTypes);
	}
	
}
