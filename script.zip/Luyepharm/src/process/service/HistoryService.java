package process.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.task.Task;

import process.service.writer.TodoTaskWriter;
import foundation.data.Entity;
import foundation.data.Variant;
import foundation.persist.Field;
import foundation.persist.TableMeta;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.user.OnlineUser;

public class HistoryService extends Service {

	private org.activiti.engine.HistoryService historyService;
	private RepositoryService repositoryService;
	private TaskService taskService;

	public HistoryService(IServiceCaller serviceCaller) throws Exception {
		super(serviceCaller);
		
		historyService = processEngine.getHistoryService();
		repositoryService = processEngine.getRepositoryService();
		taskService = processEngine.getTaskService();
	}

	@Override
	public void call(String operator) throws Exception {
		if ("getMyRunTask".equalsIgnoreCase(operator)) {
			getMyRunTask();
		}
		else if ("getHistoryTask".equalsIgnoreCase(operator)) {
			getHistoryTask();
		}
		else if ("getAllTask".equalsIgnoreCase(operator)) {
			getAllTask();
		}
		else if ("getTaskDetail".equalsIgnoreCase(operator)) {
			getTaskDetail();
		}
		else if ("isTaskFinished".equalsIgnoreCase(operator)) {
			isTaskFinished();
		}
		else if ("getHistoryAction".equalsIgnoreCase(operator)) {
			getHistoryAction();
		}
		else if ("getMyHistotyApprove".equalsIgnoreCase(operator)) {
			getMyHistotyApprove();
		}
		
	}

	public HistoricVariableInstance getRecentHistoryVariables(String key) {
		String processId = getProcessId();
		HistoricVariableInstance singleResult = historyService.createHistoricVariableInstanceQuery().processInstanceId(processId).variableName(key).orderByVariableName().desc().singleResult();
		return singleResult;
		
	}
	public List<HistoricVariableInstance> getHistoryVariables(String Key) {
		List<HistoricVariableInstance> list = historyService.createHistoricVariableInstanceQuery().variableName(Key).list();
		return list;
	}

	private void getHistoryAction() {
		ArrayList<HistoricActivityInstance> result = new ArrayList<HistoricActivityInstance>();
		String workflowId = serviceCaller.getParameter("workflowId").getStringValue();
		List<HistoricActivityInstance> list = historyService.createHistoricActivityInstanceQuery().processInstanceId(workflowId).list();
		for (HistoricActivityInstance historicActivityInstance : list) {
			if (!historicActivityInstance.getActivityType().equalsIgnoreCase("exclusiveGateway")) {
				result.add(historicActivityInstance);
			}
		}
		resultPool.addValue(result);
	}	
	
	public List<String> getMyHistotyApprove() {
		OnlineUser user = serviceCaller.getOnlineUser();
		ArrayList<String> result = new ArrayList<String>();
		String workflowId = serviceCaller.getParameter("workflowId").getStringValue();
		List<HistoricActivityInstance> list = historyService.createHistoricActivityInstanceQuery().processInstanceId(workflowId).list();
		for (HistoricActivityInstance historicActivityInstance : list) {
			if (!historicActivityInstance.getActivityType().equalsIgnoreCase("exclusiveGateway") ) {
				if (user.getType().equalsIgnoreCase("DM") || (historicActivityInstance.getAssignee() != null && historicActivityInstance.getAssignee().equalsIgnoreCase(user.getId()))) {
					result.add(historicActivityInstance.getProcessInstanceId());
				}
			}
		}
		return result;
	}
	
	public boolean isTaskFinished() {
		String processId = getProcessId();
		
		if (processId.isEmpty()) {
			return true;
		}
		
		HistoricProcessInstance instance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processId).singleResult();
		Date endTime = instance.getEndTime();
		
		String endActivityId = instance.getEndActivityId();
		
		return (endActivityId!=null && endActivityId.equalsIgnoreCase("endevent") && endTime !=null);
	}

	public void getTaskDetail() throws Exception {
		Variant processInstanceId = serviceCaller.getParameter("processInstanceId");
		String tableName = null;
		String userId = null;
		LinkedHashMap<String,String> variableMap = new LinkedHashMap<String, String>();
		List<HistoricVariableInstance> list = historyService.createHistoricVariableInstanceQuery().processInstanceId(processInstanceId.getStringValue()).list();

		for (HistoricVariableInstance historicVariableInstance : list) {
			String variableName = historicVariableInstance.getVariableName();
			if (variableName.equalsIgnoreCase("tablename")) {
				tableName = (String) historicVariableInstance.getValue();
				continue;
			}
			if (variableName.equalsIgnoreCase("applyUserId")) {
				userId = (String) historicVariableInstance.getValue();
				continue;
			}
			variableMap.put(variableName, String.valueOf(historicVariableInstance.getValue()));
		}
		
		if (tableName != null && userId != null) {
			NamedSQL namedSQL = NamedSQL.getInstance("getLineById");
			namedSQL.setTableName(tableName);
			namedSQL.setParam("fieldNameId", "user_id");
			namedSQL.setParam("id", "'"+userId+"'");
			Entity entity = SQLRunner.getEntity(namedSQL);
			TableMeta tableMeta = entity.getTableMeta();
			List<Field> fields = tableMeta.getFields();
			for (Field field : fields) {
				String fieldValue = entity.getString(field.getName());
				variableMap.put(field.getName(), fieldValue);
			}
		}
		
		resultPool.addValue(variableMap);
	}

	public void getAllTask() {
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		OnlineUser user = serviceCaller.getOnlineUser();
		List<HistoricProcessInstance> unFinishedTaskList = historyService.createHistoricProcessInstanceQuery().includeProcessVariables().list();
		Map<String, String> singleTask = null  ;

		for (HistoricProcessInstance historicProcessInstance : unFinishedTaskList) {
			String userId = historicProcessInstance.getStartUserId();
			if (user.getId().equalsIgnoreCase(userId)) {
					if (historicProcessInstance.getEndTime() == null) {
						Task Assigneetask = taskService.createTaskQuery().taskAssignee(userId).processInstanceId(historicProcessInstance.getId()).singleResult();
						if (Assigneetask != null) {
							ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(historicProcessInstance.getProcessDefinitionId()).singleResult();
							singleTask = packageTaskInfo( Assigneetask, processDefinition);
							 singleTask.put("status", "待办理");
						}
						Task CandiDateTask = taskService.createTaskQuery().taskCandidateUser(userId).processInstanceId(historicProcessInstance.getId()).singleResult();
						if (CandiDateTask != null) {
							ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(historicProcessInstance.getProcessDefinitionId()).singleResult();
							singleTask = packageTaskInfo( CandiDateTask, processDefinition);
							singleTask.put("status", "待接收");
						}
					}
					else {
						String processDefinitionId = historicProcessInstance.getProcessDefinitionId();
						ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();
						singleTask = packageTaskInfo(new SimpleDateFormat("yyyy-MM-dd hh:mm"),historicProcessInstance, processDefinition);
						singleTask.put("status", "已结束");
					}
					
				result.add(singleTask);
			}
		}
		
		resultPool.addValue("myUnFinishedTask", result, new TodoTaskWriter());
	}

	public void getHistoryTask() {
		OnlineUser user = serviceCaller.getOnlineUser();
		List<HistoricProcessInstance> unFinishedTaskList = historyService.createHistoricProcessInstanceQuery().includeProcessVariables().finished().list();
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();

		for (HistoricProcessInstance historicProcessInstance : unFinishedTaskList) {
			String userId = historicProcessInstance.getStartUserId();
			if (user.getId().equalsIgnoreCase(userId)) {
				String processDefinitionId = historicProcessInstance.getProcessDefinitionId();
					
				 ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();
				 Map<String, String> singleTask = packageTaskInfo(new SimpleDateFormat("yyyy-MM-dd hh:mm"),historicProcessInstance, processDefinition);
				 singleTask.put("status", "已结束");
				 result.add(singleTask);
			}
		}
		
		resultPool.addValue("historytask", result, new TodoTaskWriter());
	}

	public void getMyRunTask() {
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		OnlineUser user = serviceCaller.getOnlineUser();
		List<HistoricProcessInstance> unFinishedTaskList = historyService.createHistoricProcessInstanceQuery().includeProcessVariables().unfinished().list();
		Map<String, String> singleTask = null  ;

		for (HistoricProcessInstance historicProcessInstance : unFinishedTaskList) {
			String userId = historicProcessInstance.getStartUserId();
			if (user.getId().equalsIgnoreCase(userId)) {
				
					Task Assigneetask = taskService.createTaskQuery().taskAssignee(userId).processInstanceId(historicProcessInstance.getId()).singleResult();
					if (Assigneetask != null) {
						ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(historicProcessInstance.getProcessDefinitionId()).singleResult();
						singleTask = packageTaskInfo( Assigneetask, processDefinition);
						 singleTask.put("status", "待办理");
					}
					Task CandiDateTask = taskService.createTaskQuery().taskCandidateUser(userId).processInstanceId(historicProcessInstance.getId()).singleResult();
					if (CandiDateTask != null) {
						ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(historicProcessInstance.getProcessDefinitionId()).singleResult();
						singleTask = packageTaskInfo( CandiDateTask, processDefinition);
						 singleTask.put("status", "待接收");
					}
					
				result.add(singleTask);
			}
		}
		
		resultPool.addValue("myUnFinishedTask", result, new TodoTaskWriter());
	}
	
	public Map<String, String> packageTaskInfo(SimpleDateFormat sdf, HistoricProcessInstance historicProcessInstance, ProcessDefinition processDefinition) {
		OnlineUser user = serviceCaller.getOnlineUser();
		
		Map<String, String> singleTask = new HashMap<String, String>();
		singleTask.put("sid", user.getId());
		singleTask.put("id", historicProcessInstance.getId());
		singleTask.put("name", "已结束");
		singleTask.put("createTime", sdf.format(historicProcessInstance.getStartTime()));
		singleTask.put("pdname", processDefinition.getName());
		singleTask.put("pdversion", Integer.toString(processDefinition.getVersion()));
		singleTask.put("pid", historicProcessInstance.getId());
		
		return singleTask;
	}
	 
	public Map<String, String> packageTaskInfo(Task task, ProcessDefinition processDefinition) {
        Map<String, String> singleTask = new HashMap<String, String>();
        
        Map<String,Object> taskVariables = taskService.getVariables(task.getId());
        singleTask.put("sid", (String)taskVariables.get("applyUserId"));
		singleTask.put("id", task.getId());
		singleTask.put("name", task.getName());
		singleTask.put("isSuspension", String.valueOf(task.isSuspended()));
		singleTask.put("createTime", new SimpleDateFormat("yyyy-MM-dd hh:mm").format(task.getCreateTime()));
		singleTask.put("pdname", processDefinition.getName());
		singleTask.put("pdversion", Integer.toString(processDefinition.getVersion()));
		singleTask.put("pid", task.getProcessInstanceId());
		
		return singleTask;
	}
}
