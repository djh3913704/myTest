package process.service;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.zip.ZipInputStream;

import javax.servlet.http.HttpServletResponse;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;

import org.activiti.bpmn.converter.BpmnXMLConverter;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.FlowElement;
import org.activiti.editor.constants.ModelDataJsonConstants;
import org.activiti.editor.language.json.converter.BpmnJsonConverter;
import org.activiti.engine.ActivitiException;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.Model;
import org.activiti.engine.repository.ModelQuery;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.task.Task;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.PNGTranscoder;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import process.WorkflowUtils;
import process.service.writer.ModelWriter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import foundation.config.Configer;
import foundation.data.Entity;
import foundation.data.EntitySet;
import foundation.data.Variant;
import foundation.fileupload.FileItem;
import foundation.fileupload.disk.DiskFileItemFactory;
import foundation.fileupload.servlet.ServletFileUpload;
import foundation.persist.DataHandler;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;


public class RepositoryService extends Service {

	private static final String MODEL_NAME = "name";
	private static final String MODEL_REVISION = "revision";
	private static final String MODEL_DESCRIPTION = "description";
	private org.activiti.engine.RepositoryService service;
	private ObjectMapper objectMapper;

	
	public RepositoryService(IServiceCaller serviceCaller) throws Exception {
		super(serviceCaller);
		
		service = processEngine.getRepositoryService();
		objectMapper = new ObjectMapper();
	}

	@Override
	public void call(String operator) throws Exception {
		if ("model".equalsIgnoreCase(operator)) {
		    String modelOperator = paths[4];
		    if (modelOperator.equalsIgnoreCase("save")) {
		    	saveModel();
		    }
		    else {
		    	getModel();
		    }
		}
		else if ("editor".equalsIgnoreCase(operator)) {
			getEditor();
		}
		else if ("createModel".equalsIgnoreCase(operator)) {
			createModel();
		}
		else if ("deleteModel".equalsIgnoreCase(operator)) {
			deleteModel();
		}
		else if ("deployModel".equalsIgnoreCase(operator)) {
			deployModel();
		}
		else if ("deleteDeployModel".equalsIgnoreCase(operator)) {
			deleteDeployModel();
		}
		else if ("getProcessList".equalsIgnoreCase(operator)) {
			getProcessList();
		}
		else if ("readProcessSource".equals(operator)) {
			readProcessResource();
		}
		else if ("uploadFlow".equalsIgnoreCase(operator)) {
			uploadFlow();
		}
		else if ("updateProcessDefStatus".equalsIgnoreCase(operator)) {
			updateProcessDefStatus();
		}
		else if ("getModelXml".equalsIgnoreCase(operator)) {
			getModelXml();
		}
		else if ("getAllActivities".equalsIgnoreCase(operator)) {
			getAllActivities();
		}
	}

	private void getAllActivities() {
		
	}

	private void getModelXml() throws Exception {
		Variant getModleId = serviceCaller.getParameter("modleId");
		Model model = service.getModel(getModleId.getStringValue());
		BpmnJsonConverter jsonConverter = new BpmnJsonConverter();
        JsonNode editorNode = new ObjectMapper().readTree(service.getModelEditorSource(model.getId()));
        BpmnModel bpmnModel = jsonConverter.convertToBpmnModel(editorNode);
        BpmnXMLConverter xmlConverter = new BpmnXMLConverter();
        byte[] bpmnBytes = xmlConverter.convertToXML(bpmnModel);

        HttpServletResponse response = serviceCaller.getResponse();
        
        ByteArrayInputStream in = new ByteArrayInputStream(bpmnBytes);
        IOUtils.copy(in, response.getOutputStream());
        String filename = bpmnModel.getMainProcess().getId() + ".bpmn20.xml";
        response.setHeader("Content-Disposition", "attachment; filename=" + filename);
        response.flushBuffer();
	}

	private void updateProcessDefStatus() {
		String type = serviceCaller.getParameter("type").getStringValue();
		String modelId = serviceCaller.getParameter("modelId").getStringValue();
		
		Model model = service.createModelQuery().modelId(modelId).singleResult();
		ProcessDefinition processDefinition = service.createProcessDefinitionQuery().deploymentId(model.getDeploymentId()).singleResult();
		String processDefinitionId = processDefinition.getId();
		try {
			if ("active".equalsIgnoreCase(type)) {
				service.activateProcessDefinitionById(processDefinitionId, true, null);
			}
			else if ("suspend".equalsIgnoreCase(type)) {
				service.suspendProcessDefinitionById(processDefinitionId, true, null);
			}
			resultPool.addValue(type +" update success");
		} catch (Exception e) {
			e.printStackTrace();
			resultPool.addValue(type +" update fail");
			logger.debug(type +" update fail");
			
		}
		
	}

	private void deleteDeployModel() {
		String modelId = serviceCaller.getParameter("modelId").getStringValue();
		
		try {
            Model modelData = service.getModel(modelId);
            String deploymentId = modelData.getDeploymentId();
            
            if (deploymentId != null) {
				service.deleteDeployment(deploymentId, true);
				modelData.setDeploymentId(null);
				modelData.setCategory(null);
			}
            
            resultPool.addValue("删除部署成功，部署ID=" + deploymentId);
        } 
		catch (Exception e) {
        	e.printStackTrace();
        	resultPool.addValue("删除部署失败，modelId=" + modelId);
            logger.error("根据模型删除部署流程失败：modelId="+modelId, e);
        }
	}
	
	private void deployModel() {
		String modelId = serviceCaller.getParameter("modelId").getStringValue();
		
		try {
            Model modelData = service.getModel(modelId);
            ObjectNode modelNode = (ObjectNode) new ObjectMapper().readTree(service.getModelEditorSource(modelData.getId()));
            byte[] bpmnBytes = null;
            BpmnModel model = new BpmnJsonConverter().convertToBpmnModel(modelNode);
            bpmnBytes = new BpmnXMLConverter().convertToXML(model);
            
            String processName = modelData.getName() + ".bpmn20.xml";
            Deployment deployment = service.createDeployment().name(modelData.getName()).addString(processName, new String(bpmnBytes,"UTF-8")).deploy();
            modelData.setDeploymentId(deployment.getId());
            modelData.setCategory(deployment.getId());
            
            service.saveModel(modelData);
            
            resultPool.addValue("部署成功，部署ID=" + deployment.getId());
        } 
		catch (Exception e) {
        	e.printStackTrace();
        	resultPool.addValue("部署失败，modelId=" + modelId);
            logger.error("根据模型部署流程失败：modelId="+modelId, e);
        }
	}
	
	private void deleteModel() {
		String modelId = serviceCaller.getParameter("modelId").getStringValue();
		
		try {
			Model model = service.getModel(modelId);
			String deploymentId = model.getDeploymentId();
			if (deploymentId != null) {
				
				//TODO 
				updateDeletedStatus("agreement",deploymentId);
				updateDeletedStatus("rebateslit",deploymentId);
				//updateDeletedStatus("agreement",deploymentId);
				
				service.deleteDeployment(deploymentId,true);
			}
		
			service.deleteModel(modelId);
			
			resultPool.addValue("delete model successful");
		} 
		catch (Exception e) {
			e.printStackTrace();
			logger.debug("delete model failed");
			resultPool.addValue("delete model failed");
		}
	}
	private void createModel() throws Exception {
		String modelName = serviceCaller.getParameter("name").getStringValue();
		String key = serviceCaller.getParameter("key").getStringValue();
		String desp = serviceCaller.getParameter("desp").getStringValue();
		
		ObjectMapper objectMapper = new ObjectMapper();  
        ObjectNode editorNode = objectMapper.createObjectNode();  
        editorNode.put("id", "canvas");  
        editorNode.put("resourceId", "canvas");  
        ObjectNode stencilSetNode = objectMapper.createObjectNode();  
        stencilSetNode.put("namespace", "http://b3mn.org/stencilset/bpmn2.0#");  
        editorNode.set("stencilset", stencilSetNode);  
        Model modelData = service.newModel();  
        
        ObjectNode modelObjectNode = objectMapper.createObjectNode();  
        modelObjectNode.put(MODEL_NAME, modelName);  
        modelObjectNode.put(MODEL_REVISION, 1);  
        modelObjectNode.put(MODEL_DESCRIPTION, desp);  
        modelData.setMetaInfo(modelObjectNode.toString());  
        modelData.setName(modelName);  
        modelData.setKey(key);
        
        service.saveModel(modelData);  
        service.addModelEditorSource(modelData.getId(), editorNode.toString().getBytes("utf-8")); 
        String id = modelData.getId();
        
        resultPool.addValue(id);
	}
	
	@SuppressWarnings("unchecked")
	private void uploadFlow()  {
		try{	
			DiskFileItemFactory factory = new DiskFileItemFactory();  
	        ServletFileUpload servletFileUpload = new ServletFileUpload(factory);
			servletFileUpload.setHeaderEncoding("UTF-8");   
	        List<FileItem> items = servletFileUpload.parseRequest(serviceCaller.getRequest());  
	        if (items.isEmpty()) {
				resultPool.error("请选择上传文件");
				return;
			}
	        FileItem fileItem = items.get(0);
	        InputStream inputStream = fileItem.getInputStream();
            Deployment deployment = null;

            String extension = FilenameUtils.getExtension(fileItem.getName());
            if (extension.equals("zip") || extension.equals("bar")) {
                ZipInputStream zip = new ZipInputStream(inputStream);
                deployment = service.createDeployment().addZipInputStream(zip).deploy();
            } else {
                deployment = service.createDeployment().addInputStream(fileItem.getName(), inputStream).deploy();
            }
            
            ProcessDefinition processDefinition = service.createProcessDefinitionQuery().deploymentId(deployment.getId()).singleResult();
            Model model = change2Model(processDefinition);
            byte[] modelEditorSource = service.getModelEditorSource(model.getId());
            String string = new String(modelEditorSource, "utf-8");
            logger.debug(string);
            WorkflowUtils.exportDiagramToFile(service, processDefinition, Configer.getPath_Application()+"/model/"+model.getId()+".png");
            
        } catch (Exception e) {
        	e.printStackTrace();
            logger.error("error on deploy process, because of file input stream", e);
        }
	}

	private Model change2Model(ProcessDefinition processDefinition)throws Exception {
		InputStream bpmnStream = service.getResourceAsStream(processDefinition.getDeploymentId(),processDefinition.getResourceName());
		String processDefinitionKey = processDefinition.getKey();
		int modelVersion = 1;
		XMLInputFactory xif = XMLInputFactory.newInstance();
		InputStreamReader in = new InputStreamReader(bpmnStream, "UTF-8");
		XMLStreamReader xtr = xif.createXMLStreamReader(in);
		BpmnModel bpmnModel = new BpmnXMLConverter().convertToBpmnModel(xtr);
		
		BpmnJsonConverter converter = new BpmnJsonConverter();
		com.fasterxml.jackson.databind.node.ObjectNode modelNode = converter.convertToJson(bpmnModel);
		
		List<Model> list = service.createModelQuery().modelKey(processDefinitionKey).orderByModelVersion().desc().list();
		
		if (list.size() != 0) {
			Model MaxVerModel = list.get(0);
			Integer version = MaxVerModel.getVersion();
			modelVersion = version+1;
		}
		
		Model modelData = service.newModel();
		modelData.setKey(processDefinitionKey);
		modelData.setName(processDefinition.getResourceName());
		modelData.setCategory(processDefinition.getDeploymentId());
		modelData.setDeploymentId(processDefinition.getDeploymentId());
		modelData.setVersion(modelVersion);
		
		ObjectNode modelObjectNode = new ObjectMapper().createObjectNode();
		modelObjectNode.put(ModelDataJsonConstants.MODEL_NAME, processDefinition.getName());
		modelObjectNode.put(ModelDataJsonConstants.MODEL_REVISION, modelVersion);
		modelObjectNode.put(ModelDataJsonConstants.MODEL_DESCRIPTION, processDefinition.getDescription());
		modelData.setMetaInfo(modelObjectNode.toString());
		
		service.saveModel(modelData);
		service.addModelEditorSource(modelData.getId(), modelNode.toString().getBytes("utf-8"));
		return modelData;
	}

	private void readProcessResource() {
		String resoucreType = serviceCaller.getParameter("resoucreType").getStringValue();
		String processDefinitionId = serviceCaller.getParameter("processDefinitionId").getStringValue();
		String resourceName = "";
		ProcessDefinition processDefinition = service.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();

		if ("xml".equalsIgnoreCase(resoucreType)) {

		}
		else if ("image".equalsIgnoreCase(resoucreType)) {
			resourceName = processDefinition.getDiagramResourceName();
		}
		
		HttpServletResponse response = serviceCaller.getResponse();
		InputStream resourceAsStream = service.getResourceAsStream(processDefinition.getDeploymentId(), resourceName);
		try {
			byte[] b = new byte[1024];
	        int len = -1;
	        while ((len = resourceAsStream.read(b, 0, 1024)) != -1) {
	        	response.getOutputStream().write(b, 0, len);
	        }
		}
		catch (Exception e) {
			e.printStackTrace();
			error("file can not be read");
		}
		finally {
				try {
					resourceAsStream.close();
				} catch (IOException e) {
					e.printStackTrace();
					error("steam can not be close");
				}
		}
       
	}

	private void getProcessList() {
		List<Object[]> processList = new ArrayList<Object[]>();
		ModelQuery modelQuery = service.createModelQuery().orderByModelVersion().desc();
		List<Model> list = modelQuery.list();
		for (Model model: list) {
			boolean isAdd = true;
			String deploymentId = model.getDeploymentId();
			Deployment deployment = null;
			ProcessDefinition prodef= null;
			
			if (deploymentId != null) {
				prodef = service.createProcessDefinitionQuery().deploymentId(deploymentId).singleResult();
				deployment = service.createDeploymentQuery().deploymentId(deploymentId).singleResult();
			}
			for (Object[] obj : processList) {
				Model processModel = (Model) obj[0];
				if (model.getKey().equals(processModel.getKey())) {
					if (model.getVersion() <= processModel.getVersion()) {
						isAdd = false;
						continue;
					}
				}
			}
			if (isAdd) {
				processList.add(new Object[]{model, deployment,prodef});
				
			}
			
	    }
		
		
	  
	  resultPool.addValue("processList", processList, new ModelWriter());
	}

	private void getModel() {
	    ObjectNode modelNode = null;
	    
	    String modelId = paths[3];
	    Model model = service.getModel(modelId);
	      
	    if (model != null) {
	      try {
	        if (StringUtils.isNotEmpty(model.getMetaInfo())) {
	          modelNode = (ObjectNode) objectMapper.readTree(model.getMetaInfo());
	        } 
	        else {
	          modelNode = objectMapper.createObjectNode();
	          modelNode.put(ModelDataJsonConstants.MODEL_NAME, model.getName());
	        }
	        
	        modelNode.put(ModelDataJsonConstants.MODEL_ID, model.getId());
	        ObjectNode editorJsonNode = (ObjectNode) objectMapper.readTree(new String(service.getModelEditorSource(model.getId()), "utf-8"));
	        modelNode.put("model", editorJsonNode);
	        
	        resultPool.addValue("name",model.getName());
	        resultPool.addValue("description", model.getMetaInfo());
	        resultPool.addValue("modelId", modelId);
	        resultPool.addJson("model", editorJsonNode.toString());
	        
	      } 
	      catch (Exception e) {
	        logger.error("Error creating model JSON", e);
	        throw new ActivitiException("Error creating model JSON", e);
	      }
	    }	
	}

	private void saveModel()  {
	  HashMap<String,String> hashMap = new HashMap<String, String>();
	  String modelId = paths[3];
	  StringBuilder builder  = new StringBuilder();
	  FileOutputStream fileOutputStream2 = null;
	  ByteArrayOutputStream outStream = null;
	  FileOutputStream fileOutputStream = null;
	  try {
		  //1.1
		  serviceCaller.getRequest().setCharacterEncoding("utf-8");
		  BufferedReader in = new BufferedReader(new InputStreamReader(serviceCaller.getRequest().getInputStream(),"UTF-8"));  
		  String line;  
	      while ((line = in.readLine()) != null)  {
	    	builder.append(line);
	      }
	      String decode = URLDecoder.decode(builder.toString(),"utf-8");
	     System.out.println(decode);
	      String[] split = decode.split("&");
	      
	      for (String item : split) {
	    	  String[] split2 = item.split("=");
	    	  String key = split2[0];
	    	  int length = key.length();
	    	  String value = item.substring((length+1));
	    	  hashMap.put(key, value);
	      }
	      
	      String jsonXmlString = hashMap.get("json_xml");
	      jsonXmlString = jsonXmlString.replaceAll("\\+\\+", "&&");
	      hashMap.put("json_xml", jsonXmlString);
	      
	      Model model = service.getModel(modelId);
	      Integer version = model.getVersion();
	      String key = model.getKey();
	      //1.2 add new model version++ 
	      Model newModel = service.newModel();
	      ObjectNode modelJson = (ObjectNode) objectMapper.readTree(model.getMetaInfo());
	      modelJson.put(MODEL_NAME, hashMap.get("name"));
	      modelJson.put(MODEL_DESCRIPTION, hashMap.get("description"));
	      modelJson.put(MODEL_REVISION, (version + 1));
	      
	      newModel.setMetaInfo(modelJson.toString());
	      newModel.setVersion((version + 1));
	      newModel.setName(hashMap.get("name"));
	      newModel.setKey(key);
	      
	      //1.3
		  ObjectNode modelNode = (ObjectNode) new ObjectMapper().readTree(hashMap.get("json_xml").getBytes("utf-8"));
          BpmnModel bpmnModel = new BpmnJsonConverter().convertToBpmnModel(modelNode);
          byte[] bpmnBytes = new BpmnXMLConverter().convertToXML(bpmnModel);
		  String processName = newModel.getId()+ ".bpmn20.xml";
          Deployment deployment = service.createDeployment().name(newModel.getName()).addString(processName,new String(bpmnBytes,"UTF-8")).deploy();
          newModel.setDeploymentId(deployment.getId());
          newModel.setCategory(deployment.getId());
	      
	      service.saveModel(newModel);
	      
	      //1.4
	      service.addModelEditorSource(newModel.getId(), hashMap.get("json_xml").getBytes("utf-8"));
	      
	      InputStream svgStream = new ByteArrayInputStream(hashMap.get("svg_xml").getBytes("utf-8"));
	      TranscoderInput input = new TranscoderInput(svgStream);
	      PNGTranscoder transcoder = new PNGTranscoder();
		  outStream = new ByteArrayOutputStream();
		  TranscoderOutput output = new TranscoderOutput(outStream);
		  transcoder.transcode(input, output);
		  final byte[] result = outStream.toByteArray();
		  service.addModelEditorSourceExtra(newModel.getId(), result);
		  String newModelId = newModel.getId();
		  //2.
		  String path = Configer.getParam("ModelPicPathRoot");
		  File dir = new File(path);
		  if (!dir.exists()) {
			  dir.mkdirs();
		  }
		  //2.1 save model xml to server
		
          File file = new File(path,newModelId + ".bpmn20.xml");
          if (file.exists()) {
			file.delete();
          }
          file.createNewFile();
          fileOutputStream2 = new FileOutputStream(file);
          fileOutputStream2.write(bpmnBytes);
          
          //2.2 save model png to server
		  fileOutputStream = new FileOutputStream(new File(path,newModelId + ".png"));
		  InputStream svgs =  new ByteArrayInputStream(hashMap.get("svg_xml").getBytes("utf-8"));
		  TranscoderInput inputs = new TranscoderInput(svgs);
		  TranscoderOutput outputs = new TranscoderOutput(fileOutputStream);
		  transcoder.transcode(inputs, outputs);
		  fileOutputStream.flush(); 
		  
		} catch (Exception e) {
			logger.error("Error saving model", e);
		    throw new ActivitiException("Error saving model", e);
		}
	  	finally {
	  		try {
	  			if (fileOutputStream != null) {
	  				fileOutputStream.close();
				}
	  			if (fileOutputStream2 != null) {
	  				fileOutputStream2.close();
				}
	  			if (outStream != null) {
	  				outStream.close();
				}
				
			} 
	  		catch (IOException e) {
	  			logger.error("Error  close ioStream ", e);
				e.printStackTrace();
			}
	  	}
	}

	private void getEditor() throws IOException {
		File file = new File(Configer.getPath_Config(), "stencilset.json");
		String value = null;
		
		FileInputStream fileInputStream = new FileInputStream(file);
		try {
			value = IOUtils.toString(fileInputStream, "utf-8");
		}
		finally {
			fileInputStream.close();
		}
		
		resultPool.setJson(value);		
	}
	
	public static void save2File(InputStream input, String filePath,String fileName) {  
	        BufferedOutputStream bos = null;  
	        FileOutputStream fos = null;  
	        File file = null;  
	        try {  
	            file = new File(filePath,fileName);  
	            fos = new FileOutputStream(file);  
	            bos = new BufferedOutputStream(fos);  
	            int ch = 0;
	            int read = input.read();
	            
	            while((ch=read) != -1){  
	                fos.write(ch);  
	            }  
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        } finally {  
	            if (bos != null) {  
	                try {  
	                    bos.close();  
	                } catch (IOException e1) {  
	                    e1.printStackTrace();  
	                }  
	            }  
	            if (fos != null) {  
	                try {  
	                    fos.close();  
	                } catch (IOException e1) {  
	                    e1.printStackTrace();  
	                }  
	            }  
	        }  
	    }  
	
	private void updateDeletedStatus(String tableName, String deploymentId) throws Exception {
		NamedSQL getDeletedWorkflowItem = NamedSQL.getInstance("getDeletedWorkflowItem");
		getDeletedWorkflowItem.setParam("tablename", tableName);
		getDeletedWorkflowItem.setParam("deploymentid", deploymentId);
		EntitySet entitySet = SQLRunner.getEntitySet(getDeletedWorkflowItem);
		
		for (Entity entity : entitySet) {
			String id = entity.getString("id");
			Entity line = DataHandler.getLine(tableName, id);
			String statusCode = line.getString("statuscode");
			
			if (statusCode.equalsIgnoreCase("open")) {
				continue;
			}
			line.setString("statuscode", "input");
			line.update();
			
			DataHandler.clearFieldbyEntity(line, "keycode");		
		}
		
	}
	
	public String getNextPosition(Task task) {
		String currentPosition = task.getTaskDefinitionKey();
		String processDefinitionId = task.getProcessDefinitionId();
		BpmnModel bpmnModel = service.getBpmnModel(processDefinitionId);
		
		if (bpmnModel != null) {
			Collection<FlowElement> flowElements = bpmnModel.getMainProcess().getFlowElements();
			FlowElement[] flowArray = new FlowElement[flowElements.size()];
			flowElements.toArray(flowArray);
			
			int pos = -1;
			
			//1. goto current position
			for (int i = 0; i < flowArray.length - 1; i++) {
				FlowElement flowElement = flowArray[i];
				
				if (flowElement.getId().equalsIgnoreCase(currentPosition)) {
					pos = i;
				}
			}
			
			if (pos < 0) {
				return null;
			}

			//2. find parent
			for (int i = pos + 1; i < flowArray.length -1; i++) {
				FlowElement element = flowArray[i];
				String type = element.getClass().getSimpleName();
					
				if (!"UserTask".equalsIgnoreCase(type)) {
					continue;
				}
				
				return element.getId();
			}
		}
		
		return null;
	}
}
