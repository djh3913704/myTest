package process;

import java.io.File;
import java.io.FileNotFoundException;

import org.activiti.engine.ProcessEngineConfiguration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.xml.sax.EntityResolver;

import foundation.config.ConfigFileLoader;
import foundation.config.Configer;
import foundation.data.PropertyReader;
import foundation.persist.SqlSession;

public class EngineLoader extends ConfigFileLoader{

	public static ProcessEngineConfiguration engineConfiguration;
	
	
	@Override
	public void load() throws Exception {
		File file = new File(Configer.getPath_Application("process"), "engine.properties");
		PropertyReader propertyReader = new PropertyReader(file);
		createEngine(propertyReader);
	}

	private void createEngine(PropertyReader propertyReader) {
		engineConfiguration = ProcessEngineConfiguration.createStandaloneProcessEngineConfiguration();
		engineConfiguration.setDataSource(SqlSession.getDataSource());
		engineConfiguration.setDatabaseSchemaUpdate(propertyReader.get("engine.schema.update").getStringValue());
		engineConfiguration.setJobExecutorActivate(propertyReader.get("engine.activate.jobexecutor").getBooleanValue());
		engineConfiguration.setAsyncExecutorEnabled(propertyReader.get("engine.asyncexecutor.enabled").getBooleanValue());
		engineConfiguration.setAsyncExecutorActivate(propertyReader.get("engine.asyncexecutor.activate").getBooleanValue());
		engineConfiguration.setHistory(propertyReader.get("engine.history.level").getStringValue());
		
	  	if (propertyReader.get("engine.email.enabled").getBooleanValue()) {
	  		engineConfiguration.setMailServerHost(propertyReader.get("engine.email.host").getStringValue());
	  		engineConfiguration.setMailServerPort(propertyReader.get("engine.email.port").getIntValue());
	  		engineConfiguration.setMailServerUsername(propertyReader.get("engine.email.username").getStringValue());
	  		engineConfiguration.setMailServerPassword(propertyReader.get("engine.email.password").getStringValue());
	  	}
	  	
	  	engineConfiguration.buildProcessEngine();
	}

	protected DataSourceTransactionManager createTransactionManager() {
	    DataSourceTransactionManager transactionManager = new DataSourceTransactionManager();
	    transactionManager.setDataSource(SqlSession.getDataSource());
	    return transactionManager;
	}
	
	@Override
	protected EntityResolver getEntityResolver() throws FileNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
