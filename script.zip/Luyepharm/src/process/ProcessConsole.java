package process;

import process.service.FormService;
import process.service.HistoryService;
import process.service.IServiceCaller;
import process.service.IdentityService;
import process.service.ManagementService;
import process.service.RepositoryService;
import process.service.RuntimeService;
import process.service.TaskService;

import foundation.callable.Callable;
import foundation.data.Variant;

public class ProcessConsole extends Callable implements IServiceCaller {
	
	public ProcessConsole() {
		
	}
	
	@Override
	protected void publishMethod() {
		addMethod("repository");
		addMethod("runtime");
		addMethod("form");
		addMethod("history");
		addMethod("management");
		addMethod("identity");
		addMethod("task");
	}
	
	protected void repository() throws Exception {
		String operator = paths[2];
		
		RepositoryService service = new RepositoryService(this);
		service.call(operator);
	}
	
	protected void runtime() throws Exception {
		String operator = paths[2];
		
		RuntimeService service = new RuntimeService(this);
		service.call(operator);		
	}
	
	protected void form() throws Exception {
		String operator = paths[2];
		
		FormService service = new FormService(this);
		service.call(operator);		
	}
	
	protected void history() throws Exception {
		String operator = paths[2];
		
		HistoryService service = new HistoryService(this);
		service.call(operator);		
	}
	
	protected void management() throws Exception {
		String operator = paths[2];
		
		ManagementService service = new ManagementService(this);
		service.call(operator);		
	}
	
	protected void identity() throws Exception {
		String operator = paths[2];
		
		IdentityService service = new IdentityService(this);
		service.call(operator);		
	}
	
	protected void task() throws Exception {
		String operator = paths[2];
		
		TaskService service = new TaskService(this);
		service.call(operator);
	}

	@Override
	public Variant getParameter(String name) {
		return dataPool.getParameter(name);
	}

	@Override
	public void error(String error) {
		resultPool.error(error);
		
	}
}
