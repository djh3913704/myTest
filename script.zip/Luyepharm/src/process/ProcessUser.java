package process;

import org.activiti.engine.identity.User;

import foundation.user.OnlineUser;

public class ProcessUser implements User {

	private static final long serialVersionUID = 1L;
	
	private String id;
	private String firstName;
	private String lastName;
	private String password;
	
	public ProcessUser() {
		
	}

	public void load(OnlineUser onlineUser) {
		id = onlineUser.getName();
		firstName = onlineUser.getName();
		password = onlineUser.getPassword();
	}
	
	@Override
	public String getId() {
		return id;
	}

	@Override
	public void setId(String value) {
		id = value;
	}

	@Override
	public String getFirstName() {
		return firstName;
	}

	@Override
	public void setFirstName(String value) {
		firstName = value;
	}

	@Override
	public void setLastName(String vlaue) {
		lastName = vlaue;
	}

	@Override
	public String getLastName() {
		return lastName;
	}

	@Override
	public void setEmail(String email) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public void setPassword(String value) {
		password = value;
	}

	@Override
	public boolean isPictureSet() {
		// TODO Auto-generated method stub
		return false;
	}
	
}
