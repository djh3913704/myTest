package process.canvas;

import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Line2D.Double;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.activiti.bpmn.model.AssociationDirection;
import org.activiti.bpmn.model.GraphicInfo;
import org.activiti.image.impl.DefaultProcessDiagramCanvas;
import org.activiti.image.util.ReflectUtil;

import com.sun.org.apache.bcel.internal.generic.NEW;

import sun.print.resources.serviceui;


public class ProcessDiagramCanvas extends DefaultProcessDiagramCanvas {
	
	protected static Color HIGHLIGHT_COLOR = new Color(237,125,49);
	protected static int ICON_PADDING = 3;
	private String annotationFontName;
	
	public ProcessDiagramCanvas(int width, int height, int minX, int minY,
			String imageType) {
		
		super(width, height, minX, minY, imageType);
		this.activityFontName = "宋体";
		this.labelFontName = "宋体";
		this.annotationFontName = "宋体";
		initialize(imageType);
	}
	@Override
	public void drawHighLight(int x, int y, int width, int height) {
		Paint originalPaint = g.getPaint();
		Stroke originalStroke = g.getStroke();
		g.setPaint(HIGHLIGHT_COLOR);
		g.setStroke(THICK_TASK_BORDER_STROKE);
		RoundRectangle2D rect = new RoundRectangle2D.Double(x, y, width, height, 20, 20);
		g.draw(rect);
		g.setPaint(originalPaint);
		g.setStroke(originalStroke);
	}
	
	@Override
	 public void drawConnection(int[] xPoints, int[] yPoints, boolean conditional, boolean isDefault, String connectionType, AssociationDirection associationDirection, boolean highLighted, double scaleFactor)
	  {
	    Paint originalPaint = this.g.getPaint();
	    Stroke originalStroke = this.g.getStroke();

	    this.g.setPaint(CONNECTION_COLOR);
	    if (connectionType.equals("association")) {
	      this.g.setStroke(ASSOCIATION_STROKE);
	    } else if (highLighted) {
	      this.g.setPaint(HIGHLIGHT_COLOR);
	      this.g.setStroke(HIGHLIGHT_FLOW_STROKE);
	    }

	    for (int i = 1; i < xPoints.length; ++i) {
	      Integer sourceX = Integer.valueOf(xPoints[(i - 1)]);
	      Integer sourceY = Integer.valueOf(yPoints[(i - 1)]);
	      Integer targetX = Integer.valueOf(xPoints[i]);
	      Integer targetY = Integer.valueOf(yPoints[i]);
	      // e.g.(0,0) --->  (10,20)     (0,20)  (10,20)
	      Double line1 = new Line2D.Double(sourceX.intValue(), sourceY.intValue(), sourceX.intValue(), targetY.intValue());
	      Double line2 = new Line2D.Double(sourceX.intValue(), targetY.intValue(), targetX.intValue(), targetY.intValue());
	      //Line2D.Double line = new Line2D.Double(sourceX.intValue(), sourceY.intValue(), targetX.intValue(), targetY.intValue());
	      this.g.draw(line1);
	      this.g.draw(line2);
	    }
	    Line2D.Double line;
	    if (isDefault) {
	      line = new Line2D.Double(xPoints[0], yPoints[0], xPoints[1], yPoints[1]);
	      drawDefaultSequenceFlowIndicator(line, scaleFactor);
	    }

	    if (conditional) {
	      line = new Line2D.Double(xPoints[0], yPoints[0], xPoints[1], yPoints[1]);
	      drawConditionalSequenceFlowIndicator(line, scaleFactor);
	    }

	    if ((associationDirection.equals(AssociationDirection.ONE)) || (associationDirection.equals(AssociationDirection.BOTH))) {
	      line = new Line2D.Double(xPoints[(xPoints.length - 2)], yPoints[(xPoints.length - 2)], xPoints[(xPoints.length - 1)], yPoints[(xPoints.length - 1)]);
	      drawArrowHead(line, scaleFactor);
	    }
	    if (associationDirection.equals(AssociationDirection.BOTH)) {
	      line = new Line2D.Double(xPoints[1], yPoints[1], xPoints[0], yPoints[0]);
	      drawArrowHead(line, scaleFactor);
	    }
	    this.g.setPaint(originalPaint);
	    this.g.setStroke(originalStroke);
	  }
		
	@Override
	protected void drawTask(String name, GraphicInfo graphicInfo, boolean thickBorder){
	    Paint originalPaint = this.g.getPaint();
	    int x = (int)graphicInfo.getX();
	    int y = (int)graphicInfo.getY();
	    int width = (int)graphicInfo.getWidth();
	    int height = (int)graphicInfo.getHeight();

	    this.g.setPaint(TASK_BOX_COLOR);

	    int arcR = 6;
	    if (thickBorder) {
	      arcR = 3;
	    }

	    RoundRectangle2D rect = new RoundRectangle2D.Double(x, y, width, height, 10, 10);
	    this.g.fill(rect);
	    this.g.setPaint(TASK_BORDER_COLOR);

	    if (thickBorder) {
	      Stroke originalStroke = this.g.getStroke();
	      this.g.setStroke(THICK_TASK_BORDER_STROKE);
	      this.g.draw(rect);
	      this.g.setStroke(originalStroke);
	    } else {
	      this.g.draw(rect);
	    }

	    this.g.setPaint(originalPaint);

	    if ((name != null) && (name.length() > 0)) {
	      int boxWidth = width - 6;
	      int boxHeight = height - 16 - ICON_PADDING - ICON_PADDING - 12 - 2 - 2;
	      int boxX = x + width / 2 - (boxWidth / 2);
	      int boxY = y + height / 2 - (boxHeight / 2) + ICON_PADDING + ICON_PADDING - 2 - 2;

	      drawMultilineCentredText(name, boxX, boxY, boxWidth, boxHeight);
	    }
	  }	 
}
