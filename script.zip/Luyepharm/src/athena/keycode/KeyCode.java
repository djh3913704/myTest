package athena.keycode;

import java.util.ArrayList;
import java.util.List;


import foundation.data.Entity;
import foundation.data.EntitySet;
import foundation.persist.DataHandler;
import foundation.persist.TableMeta;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.util.ContentBuilder;
import foundation.util.Util;
import foundation.variant.Expression;
import foundation.variant.VariantSegment;

public class KeyCode {

	private String name;
	private String tableName;
	private String keyCodeField;
	private List<String> sourceFieldList;
	private Expression filter;
	private String remark;
	
	public KeyCode(String name) {
		sourceFieldList = new ArrayList<String>();
		keyCodeField = "keycode";
		
		this.name = name;
	}
	
	public String getKeycodeValue(Entity entity) throws FieldNotExistException, ValueNotExistException {
		if (Util.isEmptyStr(entity.getString("keycode"))) {//TODO 
			return entity.getString("no");
		}
		else {
			return entity.getString("keycode");
		}
	}
	
	public String getValue(Entity entity) throws FieldNotExistException, ValueNotExistException {
		ContentBuilder result = new ContentBuilder("-");
		
		TableMeta meta = entity.getTableMeta();
		
		for (String field: sourceFieldList) {
			if (!meta.contains(field)) {
				throw new FieldNotExistException(field);
			}
			
			String value  = entity.getString(field);
			
			if (Util.isEmptyStr(value)) {
				throw new ValueNotExistException(field);
				
			}
			
			result.append(value);
		}
		
		return result.toString();
	}
	
	public void createKeycode(Entity entity) throws FieldNotExistException, ValueNotExistException {
		String keycode = getKeycodeValue(entity);
		entity.set(keyCodeField, keycode);
	}
	

	public void clearKeycode(Entity entity) throws Exception {
		entity.set(keyCodeField, null);
		DataHandler.clearFieldbyEntity(entity, keyCodeField);		
	}
	 
	public int getCount(Entity entity) throws Exception {
		String keycode = getValue(entity);
		
		NamedSQL namedSQL = NamedSQL.getInstance("getKeycodeCount");
		namedSQL.setTableName(tableName);
		namedSQL.setParam("keycodeField", keyCodeField);
		namedSQL.setParam("keycodeValue", keycode);
		
		return SQLRunner.getInteger(namedSQL);
	}
	
	public boolean exists(Entity entity) throws Exception {
		int cnt = getCount(entity);
		return cnt > 0;
	}
	
	public EntitySet getExistsEntitySet(Entity entity) throws Exception {
		String keycode = getValue(entity);
		
		NamedSQL namedSQL = NamedSQL.getInstance("getKeycodeExistsSet");
		namedSQL.setTableName(tableName);
		namedSQL.setParam("keycodeField", keyCodeField);
		namedSQL.setParam("keycodeValue", keycode);
		
		return SQLRunner.getEntitySet(namedSQL);
	}
	
	public boolean conflicts(Entity entity) throws Exception {
		int cnt = getConfiltCount(entity);
		return cnt > 0;
	}
	
	public int getConfiltCount(Entity entity) throws Exception {
		String keycode = getValue(entity);
		String filterString = getFilterString(entity);
		
		NamedSQL namedSQL = NamedSQL.getInstance("getKeycodeConfiltCount");
		namedSQL.setTableName(tableName);
		namedSQL.setParam("keycodeField", keyCodeField);
		namedSQL.setParam("keycodeValue", keycode);
		namedSQL.setParam("filter", filterString);
		
		return SQLRunner.getInteger(namedSQL);
	}
	
	public EntitySet getConfiltEntitySet(Entity entity) throws Exception {
		//String keycode = getValue(entity);
		String filterString = getFilterString(entity);
		String parentid = entity.getString("id");
		
	//	NamedSQL namedSQL = NamedSQL.getInstance("getKeycodeConfiltSet");
		NamedSQL namedSQL = NamedSQL.getInstance("getQtyDetailKeycodeConfiltSet");
	//	namedSQL.setTableName(tableName);
	//	namedSQL.setParam("keycodeField", keyCodeField);
	//	namedSQL.setParam("keycodeValue", keycode);
		namedSQL.setParam("parentid", parentid);
		namedSQL.setParam("filter", filterString);
		
		return SQLRunner.getEntitySet(namedSQL);
	}
	
	public EntitySet getConfiltEntitySetByOriginal(Entity entity) throws Exception {
		String filterString = getFilterString(entity);
		String parentid = entity.getString("id");
		String originalid = entity.getString("originalid");
		
		NamedSQL namedSQL = NamedSQL.getInstance("getQtyDetailKeycodeConfiltByOriginal");
		namedSQL.setParam("parentid", parentid);
		namedSQL.setParam("originalid", originalid);
		namedSQL.setParam("filter", filterString);
		
		return SQLRunner.getEntitySet(namedSQL);
	}
	
	private String getFilterString(Entity entity) {
		filter.clearVariantValues();
		for (VariantSegment segment: filter) {
			String name = segment.getName();
			String value = entity.getString(name);
			segment.setValue(value);
		}
		
		String filterString = filter.getString();
		if (Util.isEmptyStr(filterString)) {
			filterString = " 1=1 ";
		}
		
		return filterString;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return name + " " + remark;
	}

	public String getRemark() {
		return remark;
	}

	public void addSourceField(String fieldName) {
		sourceFieldList.add(fieldName);	
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getKeyCodeField() {
		return keyCodeField;
	}

	public void setKeyCodeField(String value) {
		if (!Util.isEmptyStr(value)) {
			this.keyCodeField = value;
		}
	}

	public List<String> getSourceField() {
		return sourceFieldList;
	}

	public void setSourceField(List<String> sourceField) {
		this.sourceFieldList = sourceField;
	}

	public String getName() {
		return name;
	}

	public Expression getFilter() {
		return filter;
	}

	public void setFilter(String filter) throws Exception {
		this.filter = new Expression(filter);
	}
	
}
