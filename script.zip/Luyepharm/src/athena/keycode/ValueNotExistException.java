package athena.keycode;

public class ValueNotExistException extends Exception {

	private static final long serialVersionUID = 1L;
	private String field;
	
	public ValueNotExistException(String field) {
		this.field = field;
	}

	@Override
	public String toString() {
		return "value not exists: " + field;
	} 

}
