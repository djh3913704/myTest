package athena.keycode;

public class FieldNotExistException extends Exception {

	private static final long serialVersionUID = 1L;
	private String field;
	
	public FieldNotExistException(String field) {
		this.field = field;
	}

	@Override
	public String toString() {
		return "field not exists: " + field;
	} 

	
}
