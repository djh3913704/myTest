package athena.keycode;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import foundation.config.Configer;
import foundation.config.IPreloader;
import foundation.server.Container;

public class KeyCodeContainer extends Container<KeyCode> implements IPreloader {

	private static KeyCodeContainer instance;
	private boolean active;
	
	private KeyCodeContainer() {
		
	}
	
	public static synchronized KeyCodeContainer getInstance() {
		if (instance == null) {
			instance = new KeyCodeContainer();
		}
		
		return instance;
	}

	@Override
	public void load() throws Exception {
		File file = new File(Configer.getPath_Config(), "keycode.xml");
		
		if (!file.exists()) {
			return;
		}
		
		loadFile(file);
	}

	private void loadFile(File file) {
		try {
			logger.debug("load entity file:" + file);
			InputStream inputStream = new FileInputStream(file);
			
	        try {
	    		SAXReader reader = new SAXReader();
				Document doc = reader.read(inputStream);
				Element root = doc.getRootElement();
				
				loadObjects(root);
					
			} catch (DocumentException e) {
				logger.error("can not load sql file: " + file);
				logger.error(e);
			} finally {
				try {
					inputStream.close();
				} catch (IOException e) {
				}
			}
		}
		catch (Exception e) {
			logger.error(e);
		}				
	}

	private void loadObjects(Element root) throws Exception {
		Iterator<?> iterator = root.elementIterator("object");
		
		while (iterator.hasNext()) {
			Element element = (Element) iterator.next();	
			loadOneObject(element);
		}		
	}

	private void loadOneObject(Element element) throws Exception {
		String name = element.attributeValue("name");
		String remark = element.attributeValue("remark");
		String tableName = element.attributeValue("tablename");
		String keyCodeField = element.attributeValue("keycodeField");
		
		//1.
		KeyCode keyCode = new KeyCode(name);
		keyCode.setTableName(tableName);
		keyCode.setKeyCodeField(keyCodeField);
		keyCode.setRemark(remark);
		
		add(name, keyCode);
		
		//2.
		Iterator<?> iterator = element.elementIterator("sourceField");
		
		while (iterator.hasNext()) {
			Element sourceFieldElemnet = (Element) iterator.next();
			String fieldName = sourceFieldElemnet.attributeValue("name");
			keyCode.addSourceField(fieldName);
		}
		
		//3.
		Iterator<?> filterIterator = element.elementIterator("filter");
		
		while (filterIterator.hasNext()) {
			Element filterElemnet = (Element) filterIterator.next();
			keyCode.setFilter(filterElemnet.getTextTrim());
		}
	}

	@Override
	public boolean isActive() {
		return active;
	}

	@Override
	public void setActive(boolean active) {
		this.active = active;
	}
	
}
