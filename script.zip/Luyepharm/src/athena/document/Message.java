package athena.document;

public class Message {

}
