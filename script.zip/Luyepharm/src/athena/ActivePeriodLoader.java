package athena;

import foundation.config.Preloader;
import foundation.data.Entity;
import foundation.data.EntitySet;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;

public class ActivePeriodLoader extends Preloader {

	@Override
	public void load() throws Exception {
		NamedSQL namedSQL = NamedSQL.getInstance("getDataSet");
		namedSQL.setTableName("workperiod");
				
		EntitySet entitySet = SQLRunner.getEntitySet(namedSQL);
		
		if (entitySet.isEmpty()) {
			throw new Exception("empty active period");
		}
		
		Entity entity = entitySet.next();
		
		String id = entity.getString("id");
		int year = entity.getInteger("year");
		int month = entity.getInteger("month");
		
		ActivePeriod.init(id, year, month);
	}
	
}
