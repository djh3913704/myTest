package athena;

import java.util.ArrayList;
import java.util.List;

import foundation.variant.GlobalVariant;
import foundation.variant.IVariantRequestListener;
import foundation.variant.VariantExistsException;
import foundation.variant.VariantRequestParams;

public class ActivePeriod implements IVariantRequestListener {
	
	private static ActivePeriod instance;
	private static Object lock = new Object();
	private String id;
	private int year;
	private int month;
	private static List<String> paramNames;
	
	private ActivePeriod() {
		paramNames = new ArrayList<String>();
	}
	
	public static ActivePeriod getInstance() {
		if (instance == null) {
			synchronized (lock) {
				if (instance == null) {
					instance = new ActivePeriod();
				}
			}
		}
		
		return instance;
	}
	public static void init(String id, int year, int month) throws VariantExistsException {
		ActivePeriod period = getInstance();
		
		period.id = id;
		period.year = year;
		period.month = month;
		
		paramNames.add("activePeriod.year");
		paramNames.add("activePeriod.month");
		GlobalVariant.regist(period);
	}

	@Override
	public List<String> getVariantNames() {
		return paramNames;
	}

	@Override
	public String getStringValue(String name, VariantRequestParams params) {
		if ("period.year".equals(name) || "activeperiod.year".equals(name)) {
			return String.valueOf(year);
		}
		else if ("period.month".equals(name) || "activeperiod.month".equals(name)) {
			return String.valueOf(month);
		}
		
		return null;
	}

	public String getId() {
		return id;
	}

	public int getYear() {
		return year;
	}

	public int getMonth() {
		return month;
	}
	
	
	
}
