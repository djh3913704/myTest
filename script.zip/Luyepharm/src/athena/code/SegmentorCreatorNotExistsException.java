package athena.code;

public class SegmentorCreatorNotExistsException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public SegmentorCreatorNotExistsException(String name) {
		super("rule segment creator not exists: " + name);
	}

}
