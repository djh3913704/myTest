package athena.code;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import foundation.config.Configer;
import foundation.config.IPreloader;
import foundation.server.Container;


public class CodeRuleContainer extends Container<CodeRule> implements IPreloader {

	private static CodeRuleContainer instance;
	private boolean active;
	
	private CodeRuleContainer() {
		
	}
	
	public static synchronized CodeRuleContainer getInstance() {
		if (instance == null) {
			instance = new CodeRuleContainer();
		}
		
		return instance;
	}
	
	@Override
	public void load() throws Exception {
		File file = new File(Configer.getPath_Config(), "coderule.xml");
		
		if (!file.exists()) {
			return;
		}
		
		loadFile(file);		
	}

	private void loadFile(File file) {
		try {
			logger.debug("load entity file:" + file);
			InputStream inputStream = new FileInputStream(file);
			
	        try {
	    		SAXReader reader = new SAXReader();
				Document doc = reader.read(inputStream);
				Element root = doc.getRootElement();
				
				loadRules(root);
					
			} catch (DocumentException e) {
				logger.error("can not load sql file: " + file);
				logger.error(e);
			} finally {
				try {
					inputStream.close();
				} catch (IOException e) {
				}
			}
		}
		catch (Exception e) {
			logger.error(e);
		}				
	}

	private void loadRules(Element root) throws Exception {
		Iterator<?> iterator = root.elementIterator("rule");
		
		while (iterator.hasNext()) {
			Element element = (Element) iterator.next();	
			loadOneRule(element);
		}		
	}

	private void loadOneRule(Element element) throws Exception {
		String name = element.attributeValue("name");
		
		//1.
		CodeRule codeRule = new CodeRule(name);
		add(name, codeRule);
		
		//2.
		Iterator<?> iterator = element.elementIterator("segment");
		
		while (iterator.hasNext()) {
			Element segmentElemnet = (Element) iterator.next();
			String segmentName = segmentElemnet.attributeValue("name").toLowerCase();
			String className = segmentElemnet.attributeValue("class");
			String field = segmentElemnet.attributeValue("field");
			
			CustomSegmentCreator creator = new CustomSegmentCreator(segmentName);
			creator.setClazz(className);
			creator.setField(field);
			
			codeRule.addSegmentDefination(segmentName, creator);
		}
		
		//3.
		Element valueElemnet = element.element("value");
		String value = valueElemnet.getTextTrim();
		codeRule.setValue(value);
	}
	
	@Override
	public boolean isActive() {
		return active;
	}

	@Override
	public void setActive(boolean active) {
		this.active = active;
	}
}
