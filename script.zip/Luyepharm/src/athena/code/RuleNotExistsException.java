package athena.code;

public class RuleNotExistsException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public RuleNotExistsException(String name) {
		super("rule not exists: " + name);
	}

}
