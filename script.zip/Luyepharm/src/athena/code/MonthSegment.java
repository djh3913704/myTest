package athena.code;

import java.util.Calendar;
import java.util.Date;

import foundation.data.Entity;
import foundation.util.Util;

public class MonthSegment extends SegmentCreator {

	private int size = 2;
	
	public MonthSegment() {
		super("month");
	}

	@Override
	public String getValue(Entity entity) throws Exception {
		Date date = null;
		
		if ("current.date".equalsIgnoreCase(field)) {
			date = new Date();
		}
		else {
			date = entity.getDate(field);
		}
		
		if (date == null) {
			return "[月]";
		}
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		
		int month = calendar.get(Calendar.MONTH) + 1;
		String result = String.valueOf(month);
	
		while (result.length() < size) {
			result = "0" + result;
		}
		
		return result;
	}

	@Override
	public SegmentCreator newInstance(String field) {
		SegmentCreator result = new MonthSegment();
		
		if (Util.isEmptyStr(field)) {
			result.field = this.field;
		}
		else {
			result.field = field;
		}
		
		return result;
	}

}
