package athena.code;

import foundation.data.Entity;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.util.Util;

public class TypeCodeSegment extends CustomSegmentCreator {

	
	public TypeCodeSegment() {
		super("typename");
	}

	@Override
	public String getValue(Entity entity) throws Exception {
		String typecode = entity.getString(field);
		
		NamedSQL namedSQL = NamedSQL.getInstance("getApplyTypeCode");
		namedSQL.setParam("value", typecode);
		String key = SQLRunner.getString(namedSQL);
		
		if (Util.isEmptyStr(key)) {
			key = "[类型]";
		}
		
		return key;
	}

}
