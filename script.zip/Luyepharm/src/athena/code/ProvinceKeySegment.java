package athena.code;

import foundation.data.Entity;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.util.Util;

public class ProvinceKeySegment extends CustomSegmentCreator {

	
	public ProvinceKeySegment() {
		super("province");
	}

	@Override
	public String getValue(Entity entity) throws Exception {
		String province = entity.getString(field);
		
		NamedSQL namedSQL = NamedSQL.getInstance("getProvinceKey");
		namedSQL.setParam("provinceName", province);
		String key = SQLRunner.getString(namedSQL);
		
		if (Util.isEmptyStr(key)) {
			key = "[省]";
		}
		
		return key;
	}

}
