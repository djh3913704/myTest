package athena.code;

import foundation.data.Entity;

public abstract class SegmentCreator {

	protected String name;
	protected String field;
	
	public SegmentCreator() {
		
	}
	
	public SegmentCreator(String name) {
		this.name = name;
	}
	
	public abstract String getValue(Entity entity) throws Exception ;

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public abstract SegmentCreator newInstance(String field) throws Exception;
}
