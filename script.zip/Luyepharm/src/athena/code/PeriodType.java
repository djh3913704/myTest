package athena.code;

public enum PeriodType {

	Year, Season, Month, Week, Day;
	
	public String toString() {
		int no = ordinal();
		
		if (no == 0) {
			return "Year";
		}
		else if (no == 1) {
			return "Season";
		}
		else if (no == 2) {
			return "Month";
		}		
		else if (no == 3) {
			return "Week";
		}
		else if (no == 4) {
			return "Day";
		}		
		
		return "Month";
	}
	
	public static PeriodType valueOfString(String value) {
		if (value == null) {
			return PeriodType.Month;
		}

		value = value.toLowerCase();

		if ("year".equals(value)) {
			return PeriodType.Year;
		} 
		else if ("season".equals(value)) {
			return PeriodType.Season;
		} 
		else if ("month".equals(value)) {
			return PeriodType.Month;
		} 
		else if ("week".equals(value)) {
			return PeriodType.Week;
		}
		else if ("day".equals(value)) {
			return PeriodType.Day;
		}
		else {
			return PeriodType.Month;
		}
	}
}
