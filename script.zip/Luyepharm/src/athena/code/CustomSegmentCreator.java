package athena.code;

import foundation.data.Entity;

public class CustomSegmentCreator extends SegmentCreator {

	private Class<SegmentCreator> clazz;

	public CustomSegmentCreator(String name) {
		super(name);
	}

	@SuppressWarnings("unchecked")
	public void setClazz(String className) throws ClassNotFoundException {
		Class<SegmentCreator> clazz = (Class<SegmentCreator>) Class.forName(className);
		this.clazz = clazz;
	}

	public Class<?> getClazz() {
		return clazz;
	}

	@Override
	public SegmentCreator newInstance(String field) throws Exception {
		SegmentCreator creator = clazz.newInstance();
		creator.setName(name);
		creator.setField(field);
		
		return creator;
	}

	@Override
	public String getValue(Entity entity) throws Exception {
		return null;
	}

}
