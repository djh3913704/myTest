package athena.code;

import foundation.data.Entity;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;
import foundation.util.Util;

public class PlatformCodeSegment extends CustomSegmentCreator {

	
	public PlatformCodeSegment() {
		super("platformcode");
	}

	@Override
	public String getValue(Entity entity) throws Exception {
		String platformid = entity.getString(field);
		String key = "00";
		if (!Util.isEmptyStr(platformid)) {
			NamedSQL namedSQL = NamedSQL.getInstance("getPlatformCode");
			namedSQL.setParam("platformCode", platformid);
			key = SQLRunner.getString(namedSQL);
		}
		
		if (Util.isEmptyStr(key)) {
			key = "00";
		}
		
		return key;
	}

}
