package athena.code;

import foundation.data.Entity;
import foundation.persist.sql.NamedSQL;
import foundation.persist.sql.SQLRunner;

public class NoSegment extends SegmentCreator {

	private int size = 4;
	
	public NoSegment() {
		super("no");
	}

	@Override
	public String getValue(Entity entity) throws Exception {
		String tablename = entity.getTableMeta().getName();
		tablename = tablename.toLowerCase();
		
		NamedSQL namedSQL = NamedSQL.getInstance("getSequenceMax");
		namedSQL.setParam("objectname", tablename);
		int max = SQLRunner.getInteger(namedSQL);
		
		int next = max + 1;
		
		NamedSQL setSQL = NamedSQL.getInstance("setSequenceMax");
		setSQL.setParam("objectname", tablename);
		setSQL.setParam("maxValue", next);
		SQLRunner.execSQL(setSQL);
		
		String result = String.valueOf(next);
	
		while (result.length() < size) {
			result = "0" + result;
		}
		
		return result;
	}
	
	@Override
	public SegmentCreator newInstance(String field) {
		SegmentCreator result = new NoSegment();
		return result;
	}

}
