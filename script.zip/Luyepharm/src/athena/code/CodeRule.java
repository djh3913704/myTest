package athena.code;

import java.util.HashMap;
import java.util.Map;

import foundation.data.Entity;
import foundation.variant.Expression;
import foundation.variant.VariantSegment;

public class CodeRule {

	private static CodeRuleContainer codeRuleContainer;
	private static Map<String, SegmentCreator> defaultCreatorMap;
	private String name;
	private Map<String, SegmentCreator> creatorMap; 
	private Expression segments;

	
	static {
		codeRuleContainer = CodeRuleContainer.getInstance();
		defaultCreatorMap = new HashMap<String, SegmentCreator>();
		
		defaultCreatorMap.put("year", new YearSegment());
		defaultCreatorMap.put("month", new MonthSegment());
		defaultCreatorMap.put("no", new NoSegment());
	}
	
	public CodeRule(String ruleName) {
		creatorMap = new HashMap<String, SegmentCreator>();
		this.name = ruleName;
	}
	
	public static String createCode(String name, Entity entity) throws Exception {
		CodeRule instance = codeRuleContainer.get(name);
		
		if (instance == null) {
			throw new RuleNotExistsException(name);
		}
		
		String code = instance.doCreateCode(entity);
		return code;
	}
	
	private String doCreateCode(Entity entity) throws Exception {
		segments.clearVariantValues();
		
		for (VariantSegment segment: segments) {
			String name = segment.getName();
			String value = getSegmentValue(name, entity);
			segment.setValue(value);
		}
		
		return segments.getString().replace(",","");
	}

	private String getSegmentValue(String segmentName, Entity entity) throws Exception {
		SegmentCreator creator = getSegmentCreator(segmentName);
		
		if (creator == null) {
			throw new SegmentorCreatorNotExistsException(segmentName);
		}
		
		String result = creator.getValue(entity);
		return result;
	}

	private SegmentCreator getSegmentCreator(String segmentName) throws Exception {
		SegmentCreator result = null;
		
		if (segmentName == null) {
			return null;
		}
		
		segmentName = segmentName.toLowerCase();
		String field = null;
		
		SegmentCreator creator = creatorMap.get(segmentName);
		
		if (creator == null) {
			int pos = segmentName.indexOf("(");
			
			if (pos > 0) {
				String realname = segmentName.substring(0, pos);
				field = segmentName.substring(pos + 1, segmentName.length() - 1);
				
				creator = defaultCreatorMap.get(realname);
				creator.setField(field);
			}
			else {
				creator = defaultCreatorMap.get(segmentName);
			}
		}
		
		if (creator != null) {
			field = creator.getField();
			result = creator.newInstance(field);
		}
		
		return result;
	}

	public void setValue(String value) throws Exception {
		segments = new Expression(value);
	}
	
	public void addSegmentDefination(String segmentName, SegmentCreator creator) {
		if (segmentName == null) {
			return;
		}
		
		segmentName = segmentName.toLowerCase();
		creatorMap.put(segmentName, creator);
	}
	
	public String getName() {
		return name;
	}

	public Expression getSegments() {
		return segments;
	}
}
