package athena.code;

import java.util.Calendar;
import java.util.Date;

import foundation.data.Entity;
import foundation.util.Util;

public class YearSegment extends SegmentCreator {

	public YearSegment() {
		super("year");
	}

	@Override
	public String getValue(Entity entity) throws Exception {
		Date date = null;
		
		if ("current.date".equalsIgnoreCase(field)) {
			date = new Date();
		}
		else {
			date = entity.getDate(field);
		}
		
		
		if (date == null) {
			return "[年]";
		}
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		
		int year = calendar.get(Calendar.YEAR);
		return String.valueOf(year);
	}
	
	@Override
	public SegmentCreator newInstance(String field) {
		SegmentCreator result = new YearSegment();
		
		if (Util.isEmptyStr(field)) {
			result.field = this.field;
		}
		else {
			result.field = field;
		}
		
		return result;
	}
}
