(function ($) {

	Combobox = $.fm.Combobox = Control.subClass({
		template: [
		    '<div class="combobox">',
		    	'<input id="input" type="text" readonly="true" class="combo_input"/>',
		    	'<div id="button" class="combo_triger"><div class="combo_triger_icon"></div></div>',
		    '</div>'
		],
		template_popupBox: [
		    '<div class="combo_select">',
				 '<div class="combo_select_inner">',
				      '<table class="combo_select_table" cellspacing="0" border="0"></table>',
				 '</div>',
			'</div>'
		],
		template_Line: [
		    '<tr>',
		    	'<td class="combo_check"><input id="check" type="checkbox" disabled="disabled"></td>',
		    	'<td id="cell"></td>',
		    '</tr>'
		],				
		init: function(options) {
			this.height = 22;
			this.opened = false;
			this.itemCount = 5;
			this.itemHeight = 22;
			this.popupBoxHeight = this.itemHeight * this.itemCount + 1;	
			this.buttonWidth = 20;
			this.itemAlign = 'left';
			this.realTime = false;
			this.itemRendered = false;
			this.items = [];
			this.mapping = {
				key: "key",
				value: "value"
			};
			
			Control.call(this, options);
			this.createElements();
		},
		
		createElements : function(element) {
			var me = this;
			
			var edit = this.edit = $(me.template.join(""));
			me.canvas.append(edit);
			
			var input = edit.input = $("#input", edit);
			var button = edit.button = $("#button", edit);
					
			button.hover(function () {
            		this.className = "combo_triger_hover";
				}, function () {
              		this.className = "combo_triger";
				}
			).click(function () {
				event.stopPropagation();
            	me.toggle();
            });
			
			if (me.width) {
				edit.width(me.width);
				input.width(me.width - me.buttonWidth - 2);
			}
			
			
			edit.click(function (event) {
				event.stopPropagation();				
				me.toggle();
        	});
			
			var popupBox = me.popupBox = $(me.template_popupBox.join(""));
			popupBox.width(me.width);
			popupBox.table = $('table', popupBox);
			RootParent.append(popupBox);
			
			RootParent.register(this);
		},
		
        renderItems: function() {
        	var me = this;
            
        	if (me.itemRendered) {
        		return;
        	}
        	me.itemRendered = true;
        	
        	me.clearPopupBox();
        	
        	if (me.beforeRenderItems) {
        		me.beforeRenderItems(this);
        	}
        	if (!me.data) {
        		return;
        	};
            
            var table = me.popupBox.table;
            var data = me.data;
            
            for (var i = 0; i < data.length; i++) {
            	record = data[i];
            	
            	var item = $(me.template_Line.join(""));
            	item.record = record;
            	me.items.push(item);
            	
            	me.parseItem(item, record);
            	
            	item.attr("name", i);
            	item.check = $("#check", item);
            	item.cell = $("#cell", item);
            	item.cell.html(item.value);
            	item.getText = function() {
            		return this.value;
            	}
            	
            	table.append(item);
            	
            	item.hover(function () {
                	$(this).addClass("l-over");
            	}, 
            	function () {
            		$(this).removeClass("l-over");
            	});
            	
            	item.click(function() {
    				event.stopPropagation();
    				
                	var index = parseInt($(this).attr('name'));
                	var item = me.items[index];
                	
                	me.toggleLine.call(me, item, item.record);
            	});
            };
        },
        
        parseItem: function(item, record) {
        	if (!record) { return; }
        	
        	var type = typeof record;
        	if ("string" == type || "number" == type || "boolean" == type) {
        		if (this.valueRender) {
        			item.value = this.valueRender(record);
        			item.key = record;
        			return;
        		}
        		
    			item.value = record;
    			item.key = record;
    			return;
        	}
        	else if ("object" == type) {
        		item.value = record[this.mapping.value];
        		item.key = record[this.mapping.key];
        		return;
        	}
        	else if ("function" == type) {
        		var value = record();
    			item.value = value;
    			item.key = value;
    			return;
        	}
        },
        
        onNotify: function() {
        	this.closeUp();
        },
        
		toggle: function() {
        	if (!this.opened) {
        		this.dropDown();
        	}
        	else {
        		this.closeUp();
        	}
		},
		
		toggleLine: function(item, record) {
			var checked = !item.check.attr("checked");
			
			if (checked) {
				item.check.attr("checked", "checked");
			}
			else {
				item.check.removeAttr("checked");
			}
		},
		
		dropDown : function() {
            if (this.onDropDown) {
            	this.onDropDown(this);
            }
            
			this.renderItems();
			
			this.setPopupBoxHeight();
            this.setPopupBoxPosition();
            this.popupBox.show();
            
            this.opened = true;
		},
		
		closeUp : function() {
			if (!this.opened) {
				return;
			} 
			
            this.popupBox.hide();
            this.opened = false;
            
            if (this.onCloseUp) {
            	var values = this.getSelected();
            	this.onCloseUp(values, this);
            }
            
            this.refreshEdit();
		},
		
        setPopupBoxHeight: function () {
			var cnt = this.items ? this.items.length : 0;
			cnt = Math.max(Math.min(cnt, this.itemCount), 1);
			this.popupBoxHeight = this.itemHeight * cnt + 1;
			
        	this.popupBox.height(this.popupBoxHeight);        	
        },
        
        setPopupBoxPosition: function () {
        	var offset = this.edit.offset();
        	
        	var left = offset.left - 1;
        	var top = offset.top + this.height;
        	
        	if (top + this.popupBoxHeight > RootParent.height()) {
        		if (offset.top > this.popupBoxHeight) {
            		top = offset.top - this.popupBoxHeight;
        		}
        	}
        	
            this.popupBox.css({ left: left, top: top});
        },
        
        refreshEdit: function() {
        	var text = "", selected = this.getSelected();
        	
        	if (selected.length == 0) {
        		text = "";
        	}
        	else if (selected.length == 1) {
        		text = selected[0].value;
        	}
        	else {
        		text = selected.length + "个" + (this.unit || "项目");
        	}
        	
        	this.edit.input.val(text);
        },
        
        clearPopupBox: function () {
            this.popupBox.table.html("");
        },
        
        setData: function(array) {
        	this.data = array;
        },
        
        getSelected: function() {
        	var values = [];
        	
			for (var i = 0; i < this.items.length; i ++) {
				var item = this.items[i];
				if (item.check.attr("checked")) {
					values.push(item);
				}
			}
			
			return values;
        },
        
        getSelectedKeys: function() {
        	var result = "";
        	var selected = this.getSelected();
        	for (var i = 0; i < selected.length; i++) {
        		if (i > 0) {
        			result = result + ", ";
        		}
        		result = result + selected[i].key;        		
        	}
        	return result;
        },
        
		clearSelected: function() {
			for (var i = 0; i < this.items.length; i ++) {
				var item = this.items[i];
				item.check.removeAttr("checked");
			}
			
			this.edit.input.val("");
		},
        
        toResult: function() {
        	var selected = this.getSelected();
        	if (selected.length == 0) {
        		return "";
        	}
        	
        	var result = " in (";
        	for (var i = 0; i < selected.length; i++) {
        		if (i > 0) {
        			result = result + ", ";
        		}
        		
        		result = result + '"' + selected[i].key + '"';
        	}
        	
        	result = result + ") ";
        	return result;
        },
        
        isEmpty: function() {
        	var selected = this.getSelected();
        	return selected.length == 0;
        }
	});

})(jQuery);