(function ($) {
	
	/*
	 * 使用案例：download = new $.fm.Export();
	 */
	
	$.fm.Export = Control.subClass({
		template: [
		    '<div style="display:none">',
			    '<iframe id="frm_export"></iframe>',
			'</div>'
		],
				
		init: function(options) {
    		Control.call(this, options);
    		this.createElements();
    	},
    	
    	createElements: function() {
    		var element = $(this.template.join(""));
    		this.canvas.append(element);
    		
    		this.frm_export = $("#frm_export", element);
    	},
    	
    	download: function (){
    		var me = this, params = arguments;
    		this.frm_export[0].contentWindow.document.body.innerHTML = "";
    		
    	    Dialog.confirm("信息提示", "将要导出数据？", function(result){
    	       	if (result) {
    	       		var url = me.url + "?", empty = true;
    	       		
    	       		for (var i = 0; i < params.length; i++) {
    	       			if (params[i]) {
    	       				if (!empty) {
    	       					url = url + "&";
    	       				}
    	       				url = url + params[i];
    	       				empty = false;
    	       			}
    	       		}
    	       		
    	       		me.frm_export.attr("src", url);
    	    	}
    		});
    	},
	});
	
	
	/*
	 * upload = new $.fm.Upload({grid: grid});
	 */
	
	$.fm.Upload = Control.subClass({
		template: [
		    '<div id="ul_mask" class="ul_mask"></div>',
			'<div id="ul_canvas" class="ul_canvas">',
				'<div class="ul_body">',
					'<div style="margin:25px; height:70%">',
						'<div style="display:none">',
							'<input type="file" id="file_selector"/>',
						'</div>',
						'<div style="font-weight:bold; font-size:20px; margin-bottom:5px;">数据文件：',
							'<input id="edt_date" type="month" style="display: none; width: 25%"/>',
						'</div>',
						'<div style="margin-bottom:25px">',
							'<input id="txt_path" type="text" disabled="disabled" style="width:82%"/><input type="button" id="btn_select" value="选择文件" style="width:15%">',
						'</div>',
						'<div style="width:25%; float:left; height: 20px">',
							'<input id="btn_upload" class="btn_upload" type="button" value="导入数据"/>',
						'</div>',
						'<div style="width:65%; float:left;">',
							'<div class="lbl_progress" id="lbl_progress">上传：0%</div>',
							'<div class="lbl_progress" id="lbl_progress2">解析：0%</div>',
						'</div>',
						'<div style="clear:both; border-bottom:2px dashed gray; margin-top:60px"></div>',
						'<div style="width:90%; margin-top: 13px">',
							'<label style="color:#008CBA; font-size:14px; font-weight:bold;">详情：</label>',
							'<label class="lbl_upload" id="lbl_upload">选择一个Excel文件</label>',
						'</div>',
					'</div>',
				'</div>',
				'<div align="right" style="margin-right:50px">',
					'<button id="btn_close" class="button btn_light" style="overflow:hidden">关闭</button>',
				'</div>',
			'</div>'
		],
				
		init: function(options) {
			this.showDate = false;
    		Control.call(this, options);
    		this.createElements();
    	},
    	
    	createElements: function() {
    		// 1.
    		var element = $(this.template.join(""));
    		this.canvas.append(element);
    		
    		// 2.
    		this.ul_mask = $("#ul_mask", this.canvas);
    		this.ul_canvas = $("#ul_canvas", this.canvas);
    		
    		this.file_selector = $("#file_selector", element);
    		this.txt_path = $("#txt_path", element);
    		this.btn_select = $("#btn_select", element);
    		this.btn_upload = $("#btn_upload", element);
    		this.lbl_upload = $("#lbl_upload", element);
    		this.lbl_progress = $("#lbl_progress", element);
    		this.lbl_progress2 = $("#lbl_progress2", element);
    		
    		this.btn_close = $("#btn_close", element);
    		
    		this.edt_date = $("#edt_date", element);
    		
    		if(this.showDate) {
    			this.showDateSelector();
    		}

    		// 3.
    		this.addListener();
    	},
    	
    	showDateSelector: function() {
    		var monthpoint = window.parent.curPeriod.monthpoint;
    		if(monthpoint) {
    			this.edt_date.val(monthpoint);
    			this.edt_date.show();
    			return;
    		}
    		var today = new Date();
			var year = today.getFullYear();
			var month = today.getMonth() + 1;
			
			if(month < 10) {
				month = "0" + month;
			}
			
			this.edt_date.val(year + "-" + month);
			this.edt_date.show();
    	},
    	
    	addListener: function() {
    		var me = this;
    		
    		this.btn_select.click(function() {
    			me.file_selector.val("");
    			me.file_selector.click();
    		});

    		this.file_selector.change(function() {
        		me.txt_path.val(me.file_selector.val());
    		});
    		
    		this.btn_upload.click(function() {
    			me.upload();
    		});
    		
    		this.btn_close.click(function() {
        		me.ul_canvas.fadeOut("fast");
        		me.ul_mask.fadeOut("fast");
        		
    			me.txt_path.val("");
				me.lbl_upload.html("选择一个excel文件");
				
				if($.isArray(me.grid)) {
					me.grid.forEach(function(item){
						item.refresh();
					});
					
					return;
				}
				
				me.grid.refresh();
    		});
    	},
    	
    	popup: function(ele) {
    		this.ul_mask.fadeIn("fast");
    		this.ul_canvas.fadeIn("fast");
    		this.lbl_progress.html("上传： 0%");
    		this.lbl_progress2.html("解析： 0%");
    		
    		if(this.showDate) {
    			this.showDateSelector();
    		}
    		
    		if(ele) {
    			this.fname = $(ele).attr("code");
    		}
    	},
    	
    	upload: function (){
    		this.lbl_upload.html("");
    		this.lbl_progress.html("上传： 0%");
    		this.lbl_progress2.html("解析： 0%");
    		
    		if(!this.txt_path.val()){
    			this.lbl_upload.html("请选择上传文件");
    			return;
    		}
    		
    		var file = this.file_selector[0].files[0];
    		var filename = file.name.toLowerCase();
    		
    		if (filename.indexOf('.xlsx') == -1 && filename.indexOf('.xls') == -1) {
    			this.lbl_upload.html("选择的不是Excel文件");
    	        return;
    	    }

    		this.doUpload(file);	
    	},
    	
    	doUpload: function (file){
    		var me = this;
    	    var pos = file.name.lastIndexOf("\\");
    	    var filename = file.name.substring(pos + 1);
    	    
    	    Dialog.confirm("信息提示", "确定上载[" + filename + "]中的数据？", function(result){
    	        if (result) {
    	        	var url = "root/file/uploaddata";
    	        	url = me.isLocking ? url + "/T" : url + "/F";
    	        	url = me.fname ? url + "/" + me.fname : url + "/empty";
    	        	url = me.showDate ? url + "/" + me.edt_date.val() : url + "/empty";
    	        	
    	        	me.timer = setInterval(function(){me.refresh();}, 2000);
	    	        Server.upload(url, file, 
	    	            function(event){
		    	        	me.btn_select.attr("disabled", true);
		    	        	me.lbl_upload.html("正在上载，请稍等...");
		    	        	me.lbl_progress.html("上传：" + (event.loaded * 100 / event.total).toFixed(0) + "%");
	    	            },            
	    	            function(result){
	    	            	me.btn_select.attr("disabled", false);
	    	            	
	    	            	if (me.timer) {
	    	            		clearInterval(me.timer);
	    	            	}
	    	            	
	    	            	if(result.success) {
	    	            		me.lbl_upload.html("上载成功");
	    	            		me.lbl_progress2.html("解析：100%");
	    	            	} 
	    	            	else{
	    	            		me.lbl_upload.html(result.errormessage);
	    	            		me.lbl_progress.html("上传： 0%");
	    	            		me.lbl_progress2.html("解析： 0%");
	    	            	}
	    	            }
    	            );
    	        }
    	    });
    	},
    	
    	refresh: function (){
    		var me = this;
        	Server.call("root/file/showprogress?silent=T", function(result) {
        		if(!result.integer) {
        			return;
        		}
        		me.lbl_progress2.html("解析：" + result.integer + "%");
			});
        },
    	
	});
})(jQuery);