(function ($) {

 	recommendList = {
			lines: [],
			element: null,
			create: function(elem) {
				this.element = $('#' + elem);
				var titleline = '<div class="title" class="recommand-line">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
				titleline +=  '<input id="scoretitle" type="text" class="recommand-line" style="border: none; width:45px; value="" readonly="readonly"/>';
				titleline +=  '<input id="customernametitle" type="text" class="recommand-line" style="border: none; width:280px; value="" readonly="readonly"/>';
				titleline +=  '<input id="propernametitle" type="text" class="recommand-line" style="border: none; width:150px; value="" readonly="readonly"/>';
				titleline +=  '<input id="provincetitle" type="text" class="recommand-line" style="border: none; width:110px; value="" readonly="readonly"/>';
				titleline +=  '<input id="citytitle" type="text" class="recommand-line" style="border: none; width:110px; value="" readonly="readonly"/>';
				titleline +=  '<input id="regiontitle" type="text" class="recommand-line" style="border: none; width:120px; value="" readonly="readonly"/>';
				titleline +=  '<input id="statustitle" type="text" class="recommand-line" style="border: none; width:50px; value="" readonly="readonly"/>';
				titleline +=  '</div>';
				this.element.append(titleline);	
				$("#scoretitle").val("分值");
				$("#customernametitle").val("客户名称");
				$("#propernametitle").val("专有名词");
				$("#provincetitle").val("省");
				$("#citytitle").val("市");
				$("#regiontitle").val("区/县");
				$("#statustitle").val("状态");				
            	for (var i = 1; i <= 4; i++) {
            		this.createLine(i);
            	}
	 		},
	 		createLine: function(lineNo) {
		 		var bgcolor = lineNo % 2 ? '#E8EEF7' : 'transparent';
				var linedata = '<div id="row'+lineNo+'" class = "recommand-line" style="position: relative; height: 23px; background-color:' + bgcolor + ';">';
				linedata += lineNo + '.&nbsp;&nbsp;&nbsp;&nbsp;';
				linedata += this.createCell('score', '分值', lineNo, 45, bgcolor);
				linedata += this.createCell('customername', '标准客户名称', lineNo, 280, bgcolor);
				linedata += this.createCell('propername', '专有名词', lineNo, 150, bgcolor);
				linedata += this.createCell('province', '省', lineNo, 110, bgcolor);
				linedata += this.createCell('city', '市', lineNo, 110, bgcolor);		
				linedata += this.createCell('region', '区/县', lineNo, 120, bgcolor);		
				linedata += this.createCell('status', '状态', lineNo, 50, bgcolor);
				linedata += '<div style="position: absolute; right: 108px; top: 0px; width: 150px; height: 100%;">';
				linedata += '<button id="recommend' + lineNo + '" class="btn_small">推荐</button>';
				linedata += '<button id="notrecommend' + lineNo + '" class="btn_small">不推荐</button>';
				linedata += '</div>';
				linedata += '</div>';

				var line = $(linedata);
				this.lines[lineNo - 1] = line;
				line.score = $('#score' + lineNo, line);
				line.customername = $('#customername' + lineNo, line);
				line.propername = $('#propername' + lineNo, line);
				line.province = $('#province' + lineNo, line);
				line.city = $('#city' + lineNo, line);
				line.region = $('#region' + lineNo, line);
				line.channel = $('#channel' + lineNo, line);				
				line.status = $('#status' + lineNo, line);	
				line.btn_recommend = $('#recommend' + lineNo, line);
				line.btn_notRecommend = $('#notrecommend' + lineNo, line);						
				this.element.append(line);

				line.btn_recommend.click(function() {
					recommendMappingEvent(line);
				});
				line.btn_notRecommend.click(function() {
					notRecommendMappingEvent(line);
				});
				
	 		},
	 		createCell: function(name, caption, index, width, color) {
	 			return '<input id="' + name + index + '" type="text" class="data" style="border: none; width:' + width + 'px; background-color: ' + color + '" value="" readonly="readonly"/>';
	 		},
			load: function(array) {
				this.clear();
				if (!array) {return;}
				
				var line, data;
				for (var i = 0; i < array.length; i++) {
					 line = this.lines[i];
					 data = array[i];

					 line.originalid = data.originalid;
					 line.stdid = data.stdid;						 
					 line.score.val(data.score ? data.score : '');
					 line.propername.val(data.idx_propername ? data.idx_propername: '');
					 line.customername.val(data.customername ? data.customername : '');
					 line.province.val(data.idx_province ? data.idx_province : '');
					 line.city.val(data.idx_city ? data.idx_city : '');
					 line.region.val(data.idx_county ? data.idx_county : '');
					 line.channel.val(data.idx_channel ? data.idx_channel : '');
					 line.status.val(data.status ? data.status : '');
				}
	 		},
	 		clear: function(columnName) {
		 		var line;
		 		if (!columnName) {
					for (var i = 0; i < 4; i++) {
						line = this.lines[i];
						line.score.val('');
						line.customername.val('');
						line.province.val('');
						line.city.val('');
						line.region.val('');
						line.channel.val('');
						line.status.val('');
						line.propername.val('');					
					}
		 		}
		 		else {
		 			for (var i = 0; i < 4; i++) {
					     line = this.lines[i];
					     line[columnName].val('');
		 			}
		 		}
	 		}
	 	};

})(jQuery);