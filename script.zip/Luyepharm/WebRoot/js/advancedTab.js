(function ($) {
	
	AdvancedTab = $.fm.AdvancedTab = Control.subClass({
		template_content: [
		    '<iframe class="tab-content"></iframe>'
		],
		template_nav: ['<nav></nav>'],
			
		init: function(options) {
			this.items = [];
			this.headers = [];
			this.activeIndex = 0;
			this.forceLoad = false;
			
			Control.call(this, options);
			
			this.collectItems();
			this.setActiveTab(this.activeIndex);
		},
		
		collectItems: function() {
			var me = this;
			
			//1.
			var items = [];
			this.container = this.getEl(this.content);

			for (var i = 0; i < this.items.length; i++) {
				var line = this.items[i];
				
				if (line.active === false) {
					continue;
				}
				
				var item = {"code": line.header, "url": line.url, "defination": line};
				item.header = this.createOneHeader(this.getEl(line.header), item);
				item.content = this.createOneContent(this.container);
				
				item.getData = function(name) {
					var datas = this.data;
					return datas ? datas[name] : null;
				}
				
				if (!this.nav) {
					this.createNav(item.header.parent());
				}
				
				items.push(item);
			}
			
			this.items = items;
			
			//2.
			if (this.beforeShow) {
				this.beforeShow(this);
			}
			
			for (var i = 0; i < this.items.length; i++) {
				var item = this.items[i];
				if (item.active === false) {
					item.header.hide();
				} 
			}
		},
		
		createNav: function(parent) {
			if ("nav" == parent) {
				this.nav = $(template_nav);
				this.nav.wrap($("a", parent));
			}
			else {
				this.nav = parent;
			}
			
			this.nav.addClass("tab-nav");
			return this.nav;
		},
		
		createOneHeader: function(header, item) {
			var me = this;
			header.addClass("tab-header");
			header.attr("href", "#");
			
			header.click(function() {
				me.setActiveTab(item);
			});
			
			return header;
		},
		
		createOneContent: function(container) {
			var content = $(this.template_content.join(""));
			content.hide();
			container.append(content);
			
			return content;
		},
		
		registerData: function(itemCode, datas) {
			var item = this.items.getItem("code", itemCode);
			
			if (item) {
				item.data = datas;
			}
		},
		
		setActiveTab: function(item) {
			if ($.isNumeric(item)) {
				item = this.getActiveItemByIndex(item);
			}
			
			if (!item || (item.active === false)) {
				return;
			}
			
			if (this.onTabChange) {
				this.onTabChange(item);
			}
			
			if (this.activeItem) {
				this.activeItem.content.hide();
				this.activeItem.header.removeClass("tab-selected");
			}
			
			item.header.addClass("tab-selected");
			
			var url = item.content.attr("src");
			if (this.forceLoad || url != item.url) {
				item.content.attr("src", item.url);
			}
			
			item.content.show();
			
			this.activeItem = item;
		},
		
		getActiveItem: function() {
			return this.activeItem;
		},
		
		getActiveItemByIndex: function(index) {
			var pos = 0;
			
			for (var i = 0; i < this.items.length; i++) {
				var item = this.items[i];
				
				if (item.active === false) {
					continue;
				}
				
				if (pos == index) {
					return item;
				}
				
				pos++;
			}
			
			return null;
		}
	
	});
	
})(jQuery);