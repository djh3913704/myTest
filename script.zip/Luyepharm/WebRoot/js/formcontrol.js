function createTr(tableName){
	var table = "";
	for(var i=0; i<tableName.length;i++){
		switch (tableName[i]){
			case  "leave_type":
				table+= '<tr>'+
							'<td>请假类型：</td>'+
							'<td>'+
							'<select id="leave_type" name="leaveType">'+
								'<option>公休</option>'+
								'<option>病假</option>'+
								'<option>调休</option>'+
								'<option>事假</option>'+
								'<option>婚假</option>'+
							'</select>'+
							'</td>'+
						'</tr>';
				break;
				
			case  "start_time":
				table+= '<tr>'+
							'<td>开始时间：</td>'+
							'<td><input type="date" id="start_time" name="start_time" ></td>'+
						'</tr>';
				break;
				
			case  "end_time":
				table+= '<tr>'+
							'<td>结束时间：</td>'+
							'<td><input type="date" id="end_time" name="end_time" ></td>'+
						'</tr>';
				break;
				
			case  "reason":
				table+= '<tr>'+
							'<td>原因：</td>'+
							'<td><textarea name="reason" id="reason"></textarea></td>'+
						'</tr>';
				break;
			default:
					
				break;
		}
	}
	return table;
	
}