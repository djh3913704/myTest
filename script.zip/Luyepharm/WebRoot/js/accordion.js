(function ($) {
	
	$.fm.Accordion = Control.subClass({
		type: 'Accordion',
		template: '<div class="accordion-panel"></div>',
		
    	init: function(options) {
    		this.itemIndex = 0,
    		this.groupTitleHeight = 25,
    		
			Control.call(this, options);
    		this.loadData();
    		
		},
		
		loadData: function() {
			if (this.url) {
				var me = this;
				Server.getData(this.url, function(data) {
					me.createItems(data);
				});					
			}
		},
		
		setURL: function(url) {
			this.url = url;
			this.loadData();
		},
    	
		createItems: function(records) {
			var me = this;
			
			var cnt = records.length;
    		me.boxHeight = me.element.height() - cnt * me.groupTitleHeight;  
			
			me.element.empty();
			me.itemIndex = 0;
			
			if (!me.mapping) {
				return;
			}
			
			var fieldName_title = me.mapping.title;
			var cnt = records ? records.length : 0;
	    	me.groups = new Array(cnt);
	    	
			var record;
			
			for (var i = 0; i < cnt; i++) {
				record = records[i];
				
				if (this.beforeCreateItem) {
					if (!this.beforeCreateItem(record)) {
						continue;
					}
				}
				
				var group = me.groups[i] = new $.fm.Accordion.Group({
					accordion: me,
					parent: me,
					title: record[fieldName_title],
					opened: i == me.itemIndex,
					index: i,
					record: record
				});
				
				if (this.afterCreateItem) {
					this.afterCreateItem(group.body, record, records);
				}
			}
		},
		
		open: function(index) {
			var me = this;
			
			if (index != me.itemIndex) {
				me.groups[me.itemIndex].close();
				me.groups[index].open();
			}
		},
		
		notifyStoreLoad: function(dataArray) {
			this.createItems(dataArray);
			this.renderChildren();
		}
	});
    
    
	$.fm.Accordion.Group = Control.subClass({
		type: 'Accordion.Group',
		template : [
		    [
				'<div class="accordion-header">',
					'<label id="lbl_title" ></label>',
					'<div class="accordion-toggle"></div>',
				'</div>'		     
		     ],
		     [
		      	'<div class="accordion-content"></div>'
		      ]
		],
	
		init: function(options) {
	    	this.headerHeight = 25;
	    	this.opened = false;
	    
	    	Control.call(this, options);
	    	
	    	this.createElement(this.parent.canvas);
	    	
			var accordion = this.accordion;
			if (accordion.afterGroupCreate) {
				accordion.afterGroupCreate(this, this.record);
			}
		},
		
		createElement: function(canvas) {
			var me = this;
			var accordion = me.accordion;
			
			var header = this.header = $(this.template[0].join(""));
			var title = $('#lbl_title', header);
			title.html(this.title);
			var toggle = this.toggle = $('.accordion-toggle', header);
		
			var body = this.body = $(this.template[1].join(""));
			body.css({height: accordion.boxHeight});
			
			if (me.opened) {
				toggle.addClass("accordion-toggle-open"); 
			}
			else {
				body.hide();
			}
		
			header.hover(function () {
            	$(this).addClass("accordion-header-over");
        	},
        	function () {
        		$(this).removeClass("accordion-header-over");
        	});
		
			toggle.hover(function () {
                if ($(me).opened) {
                    $(this).addClass("accordion-toggle-open-over");
                }
                else {
                    $(this).addClass("accordion-toggle-close-over");
                }
            }, 
            function () {
                if ($(me).opened) {
                    $(this).removeClass("accordion-toggle-open-over");
                }
                else {
                    $(this).removeClass("accordion-toggle-close-over");
                }
            });
		
			header.click(function () {
				var accordion = me.accordion;
				var index = me.index;
				
				accordion.open(index);
			});
			
			canvas.append(header);
			canvas.append(body);
		},
		
		close: function() {
			var toggle = this.toggle;
			toggle.removeClass("accordion-toggle-open accordion-toggle-open-over");
			toggle.addClass("accordion-toggle-close");
			
			var body = this.body;
			body.hide();
			
			this.opened = false;
			
			if (this.accordion.afterGroupClose) {
				this.accordion.afterGroupClose(this);
			}
		},
		
		open: function() {
			var toggle = this.toggle;		
			toggle.removeClass("accordion-toggle-close accordion-toggle-close-over");
			toggle.addClass("accordion-toggle-open");	
			
			var body = this.body;
			body.show();
			
			this.opened = true;			
			this.accordion.itemIndex = this.index;
			
			if (this.accordion.afterGroupOpen) {
				this.accordion.afterGroupOpen(this);
			}
		}
	});        

})(jQuery);