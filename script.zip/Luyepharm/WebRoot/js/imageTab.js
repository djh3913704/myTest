(function ($) {
	
	AdvancedTab = $.fm.AdvancedTab = Control.subClass({
		template_headerContainer: ['<div class="imagetab-headercontainer"></div>'],
		template_header: ['<div class="imagetab-header"><a id="text" class="imagetab-header-text" href="#"></a></div>'],
		template_content: [
		    '<iframe class="tab-content" frameborder=no></iframe>'
		],		
			
		init: function(options) {
			this.items = [];
			this.headers = [];
			this.activeIndex = 0;
			this.forceLoad = false;
			
			Control.call(this, options);
			
			this.createItems();
			this.setActiveTab(this.activeIndex);
		},
		
		createItems: function() {
			var me = this;
			
			//0.
			this.contentContainer = this.getEl(this.content);
			if (this.headerContainer) {
				this.headerContainer = this.getEl(this.headerContainer);
			}
			else {
				this.headerContainer = $(this.template_headerContainer.join(""));
				$("body").append(this.headerContainer);
			}
			
			
			//1.
			var items = [];
			
			for (var i = 0; i < this.items.length; i++) {
				var line = this.items[i];
				
				if (line.active === false) {
					continue;
				}
				
				var item = {"code": line.code, "url": line.url, "defination": line};
				item.header = this.createOneHeader(item);
				item.content = this.createOneContent();
				
				item.getData = function(name) {
					var datas = this.data;
					return datas ? datas[name] : null;
				}
				
				items.push(item);
			}
			
			this.items = items;
			
			//2.
			if (this.beforeShow) {
				this.beforeShow(this);
			}
			
			for (var i = 0; i < this.items.length; i++) {
				var item = this.items[i];
				if (item.active === false) {
					item.header.hide();
				} 
			}
		},
		
		createOneHeader: function(item) {
			var me = this;
			var header = $(this.template_header.join(""));
			header.text = $("#text", header);
			header.text.html(item.defination.name);
			
			header.click(function() {
				me.setActiveTab(item);
			});
			
			this.headerContainer.append(header);
			return header;
		},
		
		createOneContent: function() {
			var content = $(this.template_content.join(""));
			content.hide();
			this.contentContainer.append(content);
			
			return content;
		},
		
		registerData: function(itemCode, datas) {
			var item = this.items.getItem("code", itemCode);
			
			if (item) {
				item.data = datas;
			}
		},
		
		setActiveTab: function(item) {
			if ($.isNumeric(item)) {
				item = this.getActiveItemByIndex(item);
			}
			
			if (!item || (item.active === false)) {
				return;
			}
			
			if (this.onTabChange) {
				this.onTabChange(item);
			}
			
			if (this.activeItem) {
				this.activeItem.content.hide();
				this.activeItem.header.removeClass("imagetab-selected");
			}
			
			item.header.addClass("imagetab-selected");
			
			var url = item.content.attr("src");
			if (this.forceLoad || url != item.url) {
				item.content.attr("src", item.url);
			}
			
			item.content.show();
			
			this.activeItem = item;
		},
		
		getActiveItem: function() {
			return this.activeItem;
		},
		
		getActiveItemByIndex: function(index) {
			var pos = 0;
			
			for (var i = 0; i < this.items.length; i++) {
				var item = this.items[i];
				
				if (item.active === false) {
					continue;
				}
				
				if (pos == index) {
					return item;
				}
				
				pos++;
			}
			
			return null;
		}
	
	});
	
})(jQuery);