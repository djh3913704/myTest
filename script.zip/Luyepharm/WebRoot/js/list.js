(function ($) {
	
	$.fm.List = Control.subClass({
		template: '<ul class="list"></<ul>',
		
		init: function(options) {
			Control.call(this, options);
			this.autoSize = false;
			this.renderItems();
		},
	
		renderItems: function(element) {
			var itemRecords = this.data;
			if (!itemRecords) {
				return;
			}
			
			var me = this;
			
			var cnt = itemRecords.length;
			me.items = new Array(cnt);
			this.li = new Array(cnt);
			
			if (!me.mapping) {
				return;
			}
			
			var fieldName_caption = me.mapping.caption;
			var record;
			var li;
			
			for (var i = 0; i < cnt; i++) {
				record = itemRecords[i];
				var item = {'record': record, 'index': i};
				me.items[i] = item;
				
				li = $('<li class="list-item">' + record[fieldName_caption] + '</li>');
				li.attr('index', i);
				
				this.li[i] = li;
				this.element.append(li);
				
				li.click(item, function(event) {
					var index = $(this).attr('index');
					var active = me.items[index]; 
					
					if (me.onItemClick) {
						me.onItemClick(active);
					}
				}); 
				
				li.hover(function () {
        			$(this).addClass("list-item-selected");
				}, function () {
        			$(this).removeClass("list-item-selected");
				});
			}
		}
	});    	
	
})(jQuery);