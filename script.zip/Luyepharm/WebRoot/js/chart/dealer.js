$(document).ready(function() {
	
	//4柱状折线混合图
	$('#fourth').highcharts({
			title : {
				text : "非法数据文件",
			},
			 chart: {
	            zoomType: 'xy'
	        },
			tooltip : {
				//pointFormat: '{series.name}: <b>{point.percentage:.0f}%</b>'
				shared: true
			},
			/* legend : {
				//right :'right',
				align: 'left',
				//	orient: 'vertical'
				layout: 'vertical',
			}, */
			xAxis : [{
				 categories: [ "一月", "二月", "三月", "四月", "五月", "六月" ],
				 crosshair: true
			}],
			
			yAxis : [{ // Primary yAxis
	            labels: {
	                style: {
	                    color: Highcharts.getOptions().colors[0]
	                }
	            },
	            title: {
	                text: '销量',
	                style: {
	                    color: Highcharts.getOptions().colors[0]
	                }
	            }
	       	 }],
			 series: [{
		            name: '销量',
		            type: 'column',
		            data : [ 5, 20, 36, 6, 43, 67]
		          
		        }, {
		            name: '指标',
		            type: 'spline',
		            data : [ 5, 20, 36, 6, 43, 67]
		        }]
		      }); 
		      
		      
		      
	//1 饼图
		$("#first").highcharts({
			chart: {
	            type: 'pie',
	            options3d: {
	                enabled: true,
	                alpha: 45,
	                beta: 0
	            }
	        },
		    title : {
		        text: "直连客户端状态",
		    },
	      	tooltip : {
		    	pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
		    }, 
		    plotOptions: {
	            pie: {
	            	depth: 25,
	                allowPointSelect: true,//分离
	                cursor: 'pointer',
	                dataLabels: {
	                    enabled: true,
	                    color: '#000',
	                    //connectorColor: '#fff',
				   		distance: 30,
	                    //format: '<b>{point.name}</b>: {point.percentage:.1f} %',
	                    format: ' {point.percentage:.1f} %',
		                borderRadius: 5,
		                backgroundColor: 'rgba(252, 255, 197, 0.7)',
		                borderWidth: 1,
		                borderColor: '#AAA'
	                },
					showInLegend:  true
	            }
	        },
		     legend: {
                layout: 'vertical',
                align: 'left',
                verticalAlign: 'top',
                borderWidth: 0,
              labelFormatter: function() {
                    return this.name+'&nbsp';
                },
                useHTML:true
            },
		    series : [{
	    		 type: 'pie',
    			 name: '的占比',
		    	 data: [
					{name: "活跃", y: 69.51 , color: '#039452',selected:true,sliced:true},//默认选中并分离出来
					{name: "一般", y: 13.92 , color:'#f3990c'},
					{name: "消极", y: 10.51 , color: '#8cbf3e'},
					{name: "死亡", y: 6.06  , color: '#f71818'}
            	]
		    }]
		});
		

		//2和3位置为仪表图
		option = {
		    backgroundColor: '#1b1b1b',
		    title : {
				text : "数据文件到达情况",
				x:"center"
			},
		    tooltip : {
		        formatter: "{a} <br/>{c} {b}"
		    },
		    
		     series : [{
	            name:'速度',//3.1
	            type:'gauge',
	            min:0,
	            max:220,
	            splitNumber:11,
	            radius: '50%',
	            axisLine: {            // 坐标轴线
	                lineStyle: {       // 属性lineStyle控制线条样式
	                    color: [[0.09, 'lime'],[0.82, '#1e90ff'],[1, '#ff4500']],
	                    width: 3,
	                    shadowColor : '#fff', //默认透明
	                    shadowBlur: 10
	                }
	            },
	            axisLabel: {            // 坐标轴小标记   刻度标签
	                textStyle: {       // 属性lineStyle控制线条样式
	                    fontWeight: 'bolder',
	                    color: '#000',//刻度颜色
	                    shadowColor : '#fff', //默认透明
	                    shadowBlur: 10
	                }
	            },
	            
	            axisTick: {            // 坐标轴小标记  刻度样式。
	                length :15,        // 属性length控制线长
	                lineStyle: {       // 属性lineStyle控制线条样式
	                    color: 'auto',//线的颜色
	                    shadowColor : '#fff', //默认透明
	                    shadowBlur: 10
	                }
	            },
	            
	            splitLine: {           // 分隔线
	                length :25,         // 属性length控制线长
	                lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
	                    width:3,
	                    color: '#000',
	                    shadowColor : '#fff', //默认透明
	                    shadowBlur: 10
	                }
	            },
	            pointer: {           // 分隔线
	                shadowColor : '#fff', //默认透明
	                shadowBlur: 5
	            },
	            title : {//刻度标题
	                textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
	                    fontWeight: 'bolder',
	                    fontSize: 20,
	                    fontStyle: 'italic',
	                    color: '#000',
	                    shadowColor : '#fff', //默认透明
	                    shadowBlur: 10,
	                }
	                 
	            },
	            detail : {
	                backgroundColor: 'rgba(30,144,255,0.8)',
	                borderWidth: 1,
	                borderColor: '#fff',
	                shadowColor : '#fff', //默认透明
	                shadowBlur: 5,
	                offsetCenter: [0, '50%'],       // x, y，单位px
	                textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
	                    fontWeight: 'bolder',
	                    color: '#fff'
	                }
	            },
	            data:[{value: 4, name: 'T'}]
	        },
         	{
		            name:'转速',//3.2
		            type:'gauge',
		            center : ['20%', '55%'],    // 默认全局居中
		            radius : '30%',
		            min:0,
		            max:7,
		            startAngle:270,
		            endAngle:45,
		            splitNumber:7,
		            axisLine: {            // 坐标轴线
		                lineStyle: {       // 属性lineStyle控制线条样式
		                    color: [[0.29, 'lime'],[0.86, '#1e90ff'],[1, '#ff4500']],
		                    width: 2,
		                    shadowColor : '#fff', //默认透明
		                    shadowBlur: 1
		                }
		            },
		            axisLabel: {            // 坐标轴小标记
		                textStyle: {       // 属性lineStyle控制线条样式
		                    fontWeight: 'bolder',
		                    color: '#000',
		                    shadowColor : '#fff', //默认透明
		                    shadowBlur: 10
		                }
		            },
		            axisTick: {            // 坐标轴小标记
		                length :12,        // 属性length控制线长
		                lineStyle: {       // 属性lineStyle控制线条样式
		                    color: 'auto',
		                    shadowColor : '#fff', //默认透明
		                    shadowBlur: 10
		                }
		            },
		            splitLine: {           // 分隔线
		                length :20,         // 属性length控制线长
		                lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
		                    width:3,
		                    color: '#000',
		                    shadowColor : '#fff', //默认透明
		                    shadowBlur: 10
		                }
		            },
		            pointer: {
		                width:5,
		                shadowColor : '#fff', //默认透明
		                shadowBlur: 5
		            },
		            title : {
		                offsetCenter: [0, '-30%'],       // x, y，单位px
		                textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
		                    fontWeight: 'bolder',
		                    fontStyle: 'italic',
		                    color: '#000',
		                    shadowColor : '#fff', //默认透明
		                    shadowBlur: 10
		                }
		            },
		            detail : {
		                //backgroundColor: 'rgba(30,144,255,0.8)',
		               // borderWidth: 1,
		                borderColor: '#fff',
		                shadowColor : '#fff', //默认透明
		                shadowBlur: 5,
		                width: 80,
		                height:30,
		                offsetCenter: [20, '20%'],       // x, y，单位px
		                textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
		                    fontWeight: 'bolder',
		                    color: '#fff'
		                }
		            },
		            data:[{value: 1.5, name: 'L'}]
	            },
         		{
		            name:'水表',//3.3
		            type:'gauge',
		            center : ['80%', '50%'],    // 默认全局居中
		            radius : '30%',
		            min:0,
		            max:7,
		            startAngle:135,
		            endAngle:-90,
		            splitNumber:7,
		            axisLine: {            // 坐标轴线
		                lineStyle: {       // 属性lineStyle控制线条样式
		                    color: [[0.29, 'lime'],[0.86, '#1e90ff'],[1, '#ff4500']],
		                    width: 2,
		                    shadowColor : '#fff', //默认透明
		                    shadowBlur: 10
		                }
		            },
		            axisLabel: {            // 坐标轴小标记
		                textStyle: {       // 属性lineStyle控制线条样式
		                    fontWeight: 'bolder',
		                    color: '#000',
		                    shadowColor : '#fff', //默认透明
		                    shadowBlur: 10
		                }
		            },
		            axisTick: {            // 坐标轴小标记
		                length :12,        // 属性length控制线长
		                lineStyle: {       // 属性lineStyle控制线条样式
		                    color: 'auto',
		                    shadowColor : '#fff', //默认透明
		                    shadowBlur: 10
		                }
		            },
		            splitLine: {           // 分隔线
		                length :20,         // 属性length控制线长
		                lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
		                    width:3,
		                    color: '#000',
		                    shadowColor : '#fff', //默认透明
		                    shadowBlur: 10
		                }
		            },
		            pointer: {
		                width:5,
		                shadowColor : '#fff', //默认透明
		                shadowBlur: 5
		            },
		            title : {
		                offsetCenter: [0, '-30%'],       // x, y，单位px
		                textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
		                    fontWeight: 'bolder',
		                    fontStyle: 'italic',
		                    color: '#000',
		                    shadowColor : '#fff', //默认透明
		                    shadowBlur: 10
		                }
		            },
		            detail : {
		                shadowBlur: 5,
		                width: 80,
		                height:30,
		                offsetCenter: [-15, '20%'],       // x, y，单位px
		                textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
		                    fontWeight: 'bolder',
		                    color: '#fff'
		                }
		            },
		            data:[{value: 1.5, name: 'S'}]
	            }],
		        backgroundColor: {color:'rgba(128, 128, 128, 0.5)'}
		};
		
		var second = echarts.init(document.getElementById("second"));
		setInterval(function (){
		    option.series[0].data[0].value = (Math.random()*100).toFixed(2) - 0;
		    option.series[1].data[0].value = (Math.random()*10).toFixed(2) - 0;
		    option.series[2].data[0].value = (Math.random()*10).toFixed(2) - 0;
		   // option.series[3].data[0].value = (Math.random()*100).toFixed(2) - 0;
		   option.title.text = "数据文件到达情况";
		   second.setOption(option);
		},2000);
		
		var third = echarts.init(document.getElementById("third"));
		setInterval(function (){
		    option.series[0].data[0].value = (Math.random()*100).toFixed(2) - 0;
		    option.series[1].data[0].value = (Math.random()*10).toFixed(2) - 0;
		    option.series[2].data[0].value = (Math.random()*10).toFixed(2) - 0;
		   // option.series[3].data[0].value = (Math.random()*100).toFixed(2) - 0;
		   option.title.text = "数据文件到达情况";
		    third.setOption(option);
		},2000);
		
});