$(function(){
	$('.medate').each(function(){
		$(this).ionDatePicker({
			lang: 'zh-cn',
			format: 'YYYY-MM-DD',
			years: "30",
			onChange: function() {
				if (card.onValueChange) {
					card.onValueChange();
				}
			}
		});
	});
});