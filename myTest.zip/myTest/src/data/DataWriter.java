package data;

import excel.writer.ExcelXlsxWriter;

public class DataWriter {

    /**
     * @param args
     * @throws  
     */
    public static void main(String[] args)  {
        ExcelXlsxWriter excelWriter = new ExcelXlsxWriter();
        try {
            excelWriter.Write();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
